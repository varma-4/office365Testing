//
//  SettingTableViewCell.swift
//  Simplify OR swift
//
//  Created by CHDSEZ301972DADM on 16/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class SettingTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
  
    @IBOutlet weak var imageAttached: UIImageView!
    @IBOutlet weak var hospitalNames: UILabel!
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
