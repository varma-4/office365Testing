//
//  ConsumptionTableViewCell.swift
//  Simplify OR swift
//
//  Created by CHDSEZ301972DADM on 07/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class ConsumptionTableViewCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var tab: UIButton!
    
    @IBOutlet weak var immmediateCountLabel: UILabel!
    @IBOutlet weak var thisWeekCountLbl: UILabel!
    @IBOutlet weak var nextWeekLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
