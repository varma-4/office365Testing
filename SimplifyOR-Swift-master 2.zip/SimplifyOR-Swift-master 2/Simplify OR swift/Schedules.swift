//
//  Schedules.swift
//  Simplify OR swift
//
//  Created by Sharanya Puppala on 27/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class Schedules: NSObject {
    // MARK: Var Properties Declaration
    var doctorId: String?
    var patientId: String?
    var startTime: String?
    var surgeryType: String?
    var statusCode: String?
    var scheduleId: String?
    var contractExpiryDate: String?
    var vendorId: String?
}
