//
//  CommonManager.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/2/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

var inprogressRequests = [NSURLSession]()
var inProgressTasks = [NSURLSessionDataTask]()

class CommonManager: NSObject {
    
    // MARK: Constants Declaration
    let alertViewObject = Utility()
    
    // MARK: User-Defined Functions
    func login(username:String,password:String, callback: (NSData, String, Int ,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            let userNameEdited:NSString = username.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!
            let passwordEdited:NSString = password.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!
            
            let postString = "username=\(userNameEdited)&password=\(passwordEdited)"
            let url = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/dologin?" + postString
            let request = NSMutableURLRequest(URL: NSURL(string: url)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    let fields = responsecode.allHeaderFields as? [String : String]
                    
                    if statuscode == 200 {
                        let cookies = NSHTTPCookie.cookiesWithResponseHeaderFields(fields!, forURL: response!.URL!)
                        NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookies(cookies, forURL: response!.URL!, mainDocumentURL: nil)
                        for cookie in cookies {
                            var cookieProperties = [String: AnyObject]()
                            cookieProperties[NSHTTPCookieName] = cookie.name
                            cookieProperties[NSHTTPCookieValue] = cookie.value
                            cookieProperties[NSHTTPCookieDomain] = cookie.domain
                            cookieProperties[NSHTTPCookiePath] = cookie.path
                            cookieProperties[NSHTTPCookieVersion] = NSNumber(integer: cookie.version)
                            cookieProperties[NSHTTPCookieExpires] = NSDate().dateByAddingTimeInterval(31536000)
                            NSUserDefaults.standardUserDefaults().setObject(cookie.properties, forKey:Constants.kCookie)
                            NSUserDefaults.standardUserDefaults().synchronize()
                        }
                        
                        callback(data!,"", statuscode,true)
                    }
                    else {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else {
                    if data != nil {
                        callback(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else {
            callback(NSData(),"Error",0,false)
        }
        
    }
    
    func updatePreferences(loggedInOrgId:String, callback: (NSData, String, Int , Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/session/{id}"
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body = ["loggedInOrgId": loggedInOrgId]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    let fields = responsecode.allHeaderFields as? [String : String]
                    
                    if statuscode == 200 {
                        let cookies = NSHTTPCookie.cookiesWithResponseHeaderFields(fields!, forURL: response!.URL!)
                        NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookies(cookies, forURL: response!.URL!, mainDocumentURL: nil)
                        callback(data!,"", statuscode,true)
                    }
                    else {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else {
                    if data != nil {
                        callback(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else {
            callback(NSData(),"Error", 0,false)
        }
        
    }
    
    func confirmSchedule(scheduleId:String,statusCode:String, callback: (NSData, String, Int, Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(scheduleId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/schedule/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body = ["statusCode": "\(statusCode)"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200 {
                        callback(data!,"", statuscode,true)
                    }
                    else {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else {
                    if data != nil {
                        callback(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else {
            callback(NSData(),"Error",0,false)
        }
        
    }
    
    func getAssociatedOrgs(userId:String, callbackOrgs: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(userId)/orgs?companyType=HOSPITAL"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/user/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200 {
                        callbackOrgs(data!,"", statuscode,true)
                    }
                    else {
                        if data != nil {
                            callbackOrgs(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else {
                    if data != nil {
                        callbackOrgs(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else {
            callbackOrgs(NSData(),"Error", 0,false)
        }
        
    }
    
    func getSummaryList(main:String,callbackSummary: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = main
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            if session.configuration.HTTPCookieStorage?.cookies?.count == 0 {
               NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie()) 
            }
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            inprogressRequests.append(session)
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200 {
                        callbackSummary(data!,"", statuscode,true)
                    }
                    else if statuscode == 403 {
                        callbackSummary(NSData(),"Error", statuscode,true)
                    }
                    else {
                        if data != nil {
                            callbackSummary(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else {
                    if data != nil {
                        callbackSummary(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else {
            callbackSummary(NSData(),"Error", 0,false)
        }
    }
    
    func createConsumption(postString:String, consumptionTime:String, scheduleId:String, orgId:String, vendorId:String,callback2: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "POST"
            let body = ["consumptionTime": consumptionTime,"scheduleId":scheduleId,"orgId":orgId,"vendorId":vendorId]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200 {
                        callback2(data!,"", statuscode,true)
                    }
                    else
                    {
                        if data != nil {
                            callback2(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callback2(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else {
            callback2(NSData(),"Error", 0,false)
        }
    }
    
    func getConsumptionDetail(main:String,callbackDetail: (NSData, String, Int,Bool) -> Void) {
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = main
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200 {
                        callbackDetail(data!,"", statuscode,true)
                    }
                    else
                    {
                        if data != nil {
                            callbackDetail(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackDetail(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else{
            callbackDetail(NSData(),"Error", 0,false)
        }
    }
    
    func getSingleConsumptionDetail(consumptionId:String,callback: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = consumptionId
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200 {
                        callback(data!,"", statuscode,true)
                    }
                    else
                    {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {   if data != nil {
                    callback(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else {
            callback(NSData(),"Error", 0,false)
        }
    }
    
    func addLineItem(consumptionId:String,itemNo:String,lotNumber:String,dateCode:String,consumedQty:String,scrappedQty:String,isItemValid:NSNumber, isConsumedQtyValid:NSNumber, isDateCodeValid:NSNumber, isScrappedQtyValid:NSNumber, isLotValid:NSNumber, callbackAdd: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let subBody = [["consumedQty":consumedQty,"dateCode":dateCode,"itemNo":itemNo,"lotNumber":lotNumber,"scrappedQty":scrappedQty,"isItemValid":isItemValid,"isConsumedQtyValid":isConsumedQtyValid,"isDateCodeValid":isDateCodeValid,"isScrappedQtyValid":isScrappedQtyValid,"isLotValid":isLotValid]]
            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackAdd(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackAdd(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackAdd(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
        else {
            callbackAdd(NSData(),"Error", 0,false)
        }
    }
    
    //MARK:UNUSED FUNCTION
    func updateLineItem(consumptionId:String,itemNo:String,lotNumber:String,dateCode:String,consumedQty:String,scrappedQty:String,itemId:String, callbackUpdate: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let subBody = [["consumedQty":consumedQty,"dateCode":dateCode,"itemNo":itemNo,"lotNumber":lotNumber,"scrappedQty":scrappedQty,"id":itemId]]
            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackUpdate(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackUpdate(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackUpdate(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackUpdate(NSData(),"Error", 0,false)
        }
        
    }
    
    func updateLineItemWithStatus(consumptionId:String,itemNo:String,lotNumber:String,dateCode:String,consumedQty:String,scrappedQty:String,itemId:String,isItemValid:NSNumber, isConsumedQtyValid:NSNumber, isDateCodeValid:NSNumber, isScrappedQtyValid:NSNumber, isLotValid:NSNumber, callbackUpdate: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let subBody = [["consumedQty":consumedQty,"dateCode":dateCode,"itemNo":itemNo,"lotNumber":lotNumber,"scrappedQty":scrappedQty,"id":itemId,"isItemValid":isItemValid,"isConsumedQtyValid":isConsumedQtyValid,"isDateCodeValid":isDateCodeValid,"isScrappedQtyValid":isScrappedQtyValid,"isLotValid":isLotValid]]
            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackUpdate(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackUpdate(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackUpdate(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackUpdate(NSData(),"Error", 0,false)
        }
        
    }
    
    
    
    func submitForReview(consumptionId:String, callbackSubmit: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body = ["notes":"test insert","statusCode":"REVIEW_PENDING"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackSubmit(data!,"", statuscode,true
                        )
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackSubmit(data!,"Connection interrupted", statuscode,true
                            )
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackSubmit(data!,error!.localizedDescription, 0,true
                        )
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackSubmit(NSData(),"Error", 0,false)
        }
        
    }
    
    func getCompletedList(main:String,callbackCompleted: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com//services/data/v1.0/consumption?"+main
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackCompleted(data!,"", statuscode,true)
                    }
                    else if statuscode == 403 {
                        callbackCompleted(NSData(),"Error", statuscode,true)
                    }
                    else
                    {
                        if data != nil {
                            callbackCompleted(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callbackCompleted(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackCompleted(NSData(),"Error", 0,false)
        }
    }
    
    func rejectLineItem(consumptionId:String, isItemValid:Int, isConsumedQtyValid:Int, isDateCodeValid:Int, isScrappedQtyValid:Int, isLotValid:Int,itemId:String, callbackReject: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let subBody = [["isItemValid":isItemValid,"isConsumedQtyValid":isConsumedQtyValid,"isDateCodeValid":isDateCodeValid,"isScrappedQtyValid":isScrappedQtyValid,"isLotValid":isLotValid,"id":itemId]]
            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            }
            catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackReject(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackReject(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackReject(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackReject(NSData(),"Error", 0,false)
        }
        
    }
    
    func approveConsumption(consumptionId:String, callbackApprove: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body = ["notes":"test insert","statusCode":"APPROVED"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackApprove(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackApprove(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackApprove(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else{
            callbackApprove(NSData(),"Error", 0,false)
        }
        
    }
    
    func rejectConsumption(consumptionId:String,reason1:Int, reason2:Int, otherReason:Int, callbackReject: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body = ["isRejectedForReason1":reason1,"isRejectedForReason2":reason2,"isRejectedForOthers": otherReason,"notes":"test insert","statusCode":"REJECTED"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            //
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackReject(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackReject(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackReject(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else {
            callbackReject(NSData(),"Error", 0,false)
        }
        
    }
    
    func addMultipleLineItems(consumptionId:String,lineItems:[[String:AnyObject]], callbackAddMultiple: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body:[String:AnyObject] = ["details":lineItems,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: NSJSONWritingOptions.PrettyPrinted)
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackAddMultiple(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackAddMultiple(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil  {
                        callbackAddMultiple(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            task.resume()
        }
        else{
            callbackAddMultiple(NSData(),"Error", 0,false)
        }
        
    }
    
    func getCookie () -> NSHTTPCookie
    {
        var cookie: NSHTTPCookie? = nil
        if NSUserDefaults.standardUserDefaults().objectForKey(Constants.kCookie) != nil{
            cookie = NSHTTPCookie(properties: NSUserDefaults.standardUserDefaults().objectForKey(Constants.kCookie) as! [String : AnyObject])
        }
        return cookie!
    }
    
    func setCookie (cookie:NSHTTPCookie)
    {
        NSUserDefaults.standardUserDefaults().setObject(cookie.properties, forKey: Constants.kCookie)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    func deleteLineItem(consumptionId:String,itemId:String, callbackDelete: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let subBody = [["id":itemId]]
            let body = ["details":subBody,"statusCode":"DELETE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackDelete(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackDelete(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackDelete(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackDelete(NSData(),"Error", 0,false)
        }
        
    }
    
    func deleteLineItems(consumptionId:String,deltedlineItems:[[String:AnyObject]], callbackDelete: (NSData, String, Int,Bool) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(getCookie())
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            request.HTTPMethod = "PATCH"
            let body = ["details":deltedlineItems,"statusCode":"DELETE_LINE_ITEMS"]
            let jsonBody: NSData
            
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: NSJSONWritingOptions.PrettyPrinted)
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request) {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        callbackDelete(data!,"", statuscode,true)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackDelete(data!,"Connection interrupted", statuscode,true)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackDelete(data!,error!.localizedDescription, 0,true)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            callbackDelete(NSData(),"Error", 0,false)
        }
        
    }
    
}
