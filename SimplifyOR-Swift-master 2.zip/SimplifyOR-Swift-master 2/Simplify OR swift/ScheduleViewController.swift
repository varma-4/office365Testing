//
//  ScheduleViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/10/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import CoreData

var is403Status = false

class ScheduleViewController: UIViewController, UITableViewDelegate, UITableViewDataSource ,UIPopoverPresentationControllerDelegate, CurrencySelectedDelegate, UpdatePrefDelegate {
    
    // MARK: Constants Declaration
    let value = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
    let alertViewObject = Utility()
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var ConsumptionTableView: UITableView!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var remainingTableView: UITableView!
    @IBOutlet weak var thisWeekTableView: UITableView!
    @IBOutlet weak var immediateTableView: UITableView!
    @IBOutlet weak var consumptionView: UIView!
    @IBOutlet weak var status: UISegmentedControl!
    
    // MARK: Var Properties Declaration
    var selectedTableView: UITableView?
    var immediateheight : NSLayoutConstraint?
    var thisweekheight : NSLayoutConstraint?
    var remainingheight : NSLayoutConstraint?
    var selectedTableViewHeight : CGFloat?
    var arrowChange:Int = 0
    var selectrow : NSInteger? = -1
    var result = [Schedules]()
    var statusCode: String?
    var timeFormatter: NSDateFormatter?
    var dateformatter: NSDateFormatter?
    var records = [Schedules]()
    var recordsNew = [Schedules]()
    let utility = Utility()
    let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
    
    //API Call sets this Variable
    var completedRecords = [Schedules]()
    var immediateCount : String!
    var thisWeekCount : String!
    var nextWeekCount : String!
    var comsumptionResult = [Schedules]()
    var records1 = [Schedules]()
    var immediateDateToBeUsed:String?
    var thisWeekStartDateToBeUsed:String?
    var thisWeekEndDateToBeUsed:String?
    var nextWeekStartDateToBeUsed:String?
    var nextWeekEndDateToBeUsed:String?
    var thisWeekResult = [Schedules]()
    var nextWeekResult = [Schedules]()
    let itemsPerBatch = 10
    var objSchedules = [Schedules]()
    var objSchedulesThisWeek = [Schedules]()
    var objSchedulesRemainWeek = [Schedules]()
    var fromConsumptionTab:Bool = true
    var contractExpDat: String?
    
    // Where to start fetching items (database OFFSET)
    var offset = 0
    var offsetThisWeek = 0
    var offsetRemainWeek = 0
    var offsetCompleted = 0
    var offsetConsumptions = 0
    
    // a flag for when all database items have already been loaded
    var reachedEndOfItems = false
    var reachedThisWeekEndOfItems = false
    var reachedRemainWeekEndOfItems = false
    var reachedEndOfCompletedItems = false
    var reachedEndOfConsumptionItems = false
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.ConsumptionTableView.hidden = false
        self.consumptionView.hidden = true
        timeFormatter = NSDateFormatter()
        dateformatter = NSDateFormatter()
        timeFormatter!.dateFormat = Constants.timeFormat
        dateformatter!.dateFormat = Constants.dateFormat
        ConsumptionTableView.tableFooterView = UIView()
        
        if value == Constants.kNurse {
            status.selectedSegmentIndex = 2
        }
        else {
            status.selectedSegmentIndex = 0
            changeHeight()
        }
        
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        for constraint in immediateTableView.constraints as [NSLayoutConstraint]  {
            if constraint.identifier == "immediateheight" {
                let screenHeight = screenSize.height;
                immediateheight = constraint
                if screenHeight == Constants.IPHONE_5{
                    selectedTableViewHeight = 345
                }
                else  if screenHeight == Constants.IPHONE_6 {
                    selectedTableViewHeight = 445
                }
                else  if screenHeight == Constants.IPHONE_6P {
                    selectedTableViewHeight = 517
                }
                else {
                    selectedTableViewHeight = 270
                }
            }
        }
        immediateheight?.constant = selectedTableViewHeight!
        
        for constraint in thisWeekTableView.constraints as [NSLayoutConstraint]  {
            if constraint.identifier == "thisweekheight" {
                thisweekheight = constraint
            }
        }
        
        for constraint in remainingTableView.constraints as [NSLayoutConstraint]  {
            if constraint.identifier == "remainingheight" {
                remainingheight = constraint
            }
        }
        
        let (immediateDate,thisWeekStartDate,thisWeekEndDate,nextWeekStartDate,nextWeekEndDate) = self.getDate()
        
        immediateDateToBeUsed = immediateDate
        thisWeekStartDateToBeUsed = thisWeekStartDate
        thisWeekEndDateToBeUsed = thisWeekEndDate
        nextWeekStartDateToBeUsed = nextWeekStartDate
        nextWeekEndDateToBeUsed = nextWeekEndDate
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        comsumptionResult = [Schedules]()
        records1 = [Schedules]()
        thisWeekResult = [Schedules]()
        nextWeekResult = [Schedules]()
        objSchedules = [Schedules]()
        objSchedulesThisWeek = [Schedules]()
        objSchedulesRemainWeek = [Schedules]()
        completedRecords = [Schedules]()
        records = [Schedules]()
        recordsNew = [Schedules]()

        //Should have API call to fetch records
        reachedEndOfItems = false
        reachedThisWeekEndOfItems = false
        reachedRemainWeekEndOfItems = false
        reachedEndOfCompletedItems = false
        reachedEndOfConsumptionItems = false
    
        if status.selectedSegmentIndex == 0 {
            reachedEndOfItems = false
            reachedThisWeekEndOfItems = false
            reachedRemainWeekEndOfItems = false
            offset = 0
            offsetThisWeek = 0
            offsetRemainWeek = 0
            self.getSummaryCount()
            self.getImmediateSchedules()
            self.getThisWeekSchedules()
            self.getNextWeekSchedules()
            records1 =  self.comsumptionResult
        }
        else if status.selectedSegmentIndex == 1 {
            self.reachedEndOfConsumptionItems = false
            offsetConsumptions = 0
            self.getConsumptions()
            recordsNew =  result
        }
        else if status.selectedSegmentIndex == 2 {
            self.reachedEndOfCompletedItems = false
            offsetCompleted = 0
            self.getCompletedList()
            records =  completedRecords
        }
        
        makeTableViewReadOnly()
        ConsumptionTableView.reloadData()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source&Delegate Methods
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if status.selectedSegmentIndex == 0 {
            return 70
        }
        else {
            return 85
        }
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if status.selectedSegmentIndex == 0 {
            return Constants.standardCellHeight
        }
        else {
            return 0
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if status.selectedSegmentIndex == 0 && tableView != ConsumptionTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("headerCell") as! ConsumptionTableViewCell
            if (self.thisWeekCount != nil){
                cell.immmediateCountLabel?.text = "(\(self.immediateCount))"
                cell.thisWeekCountLbl?.text = "(\(self.thisWeekCount))"
                cell.nextWeekLable?.text = "(\(self.nextWeekCount))"
            }
            if arrowChange == 1 {
                if cell.label.text == "Immediate"
                {
                    cell.contentView.backgroundColor = UIColor.darkGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
                }
                else if cell.label.text == "This week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "Next week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
            }
            else if arrowChange == 2 {
                if cell.label.text == "Immediate"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "This week"
                {
                    cell.contentView.backgroundColor = UIColor.darkGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
                }
                else if cell.label.text == "Next week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
            }
            else if arrowChange == 3 {
                if cell.label.text == "Immediate"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "This week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "Next week"
                {
                    cell.contentView.backgroundColor = UIColor.darkGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
                }
            }
            cell.tab.addTarget(self, action: #selector(ScheduleViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
            return cell.contentView
        }
        else {
            return nil
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var rows = 0
        
        if status.selectedSegmentIndex == 0 {
            
            if tableView == immediateTableView {
                rows = self.comsumptionResult.count
            }
            
            if tableView == thisWeekTableView {
                rows = self.thisWeekResult.count
            }
            
            if tableView == remainingTableView {
                rows = self.nextWeekResult.count
            }
            
        }
        else if status.selectedSegmentIndex == 1 {
            rows = recordsNew.count
        }
        else if status.selectedSegmentIndex == 2{
            rows = records.count
        }
        
        return rows
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if status.selectedSegmentIndex == 0 {
            let cell = tableView.dequeueReusableCellWithIdentifier("scheduleCell") as! ScheduleTableViewCell
            var sch = Schedules()
            if tableView == immediateTableView {
                
                if (self.comsumptionResult.count != 0){
                    sch = comsumptionResult[indexPath.row]
                    let utility = Utility()
                    let date = sch.startTime
                    cell.time.text = utility.getTime(date!)
                    cell.date.text = utility.getDate(date!)
                    let scheduleType = sch.surgeryType
                    if scheduleType == nil {
                        cell.surgeryName.text = "No Value"
                    }
                    else{
                        cell.surgeryName.text = sch.surgeryType
                    }
                    cell.doctorName.text = sch.doctorId
                    cell.status.text = " "
                    cell.statusImage.hidden = true
                    contractExpDat = sch.contractExpiryDate
                }
                
                if arrowChange == 1 {
                    if (self.comsumptionResult.count != 0){
                        
                        sch = comsumptionResult[indexPath.row]
                        let utility = Utility()
                        let date = sch.startTime
                        cell.time.text = utility.getTime(date!)
                        cell.date.text = utility.getDate(date!)
                        let scheduleType = sch.surgeryType
                        if scheduleType == nil {
                            cell.surgeryName.text = "No Value"
                        }
                        else{
                            cell.surgeryName.text = sch.surgeryType
                        }
                        cell.doctorName.text = sch.doctorId
                        cell.status.text = " "
                        cell.statusImage.hidden = true
                        contractExpDat = sch.contractExpiryDate
                    }
                }
            }
            if tableView == thisWeekTableView {
                if arrowChange == 2 {
                    if (self.thisWeekResult.count != 0) {
                        sch = thisWeekResult[indexPath.row]
                        let utility = Utility()
                        let date = sch.startTime
                        cell.time.text = utility.getTime(date!)
                        cell.date.text = utility.getDate(date!)
                        let scheduleType = sch.surgeryType
                        
                        if scheduleType == nil {
                            cell.surgeryName.text = "No Value"
                        }
                        else {
                            cell.surgeryName.text = sch.surgeryType
                        }
                        cell.doctorName.text = sch.doctorId
                        cell.status.text = " "
                        cell.statusImage.hidden = true
                        contractExpDat = sch.contractExpiryDate
                    }
                }
            }
            
            if tableView == remainingTableView {
                if arrowChange == 3 {
                    if (self.nextWeekResult.count != 0){
                        sch = self.nextWeekResult[indexPath.row]
                        let utility = Utility()
                        let date = sch.startTime
                        cell.time.text = utility.getTime(date!)
                        cell.date.text = utility.getDate(date!)
                        let scheduleType = sch.surgeryType
                        
                        if scheduleType == nil
                        {
                            cell.surgeryName.text = "No Value"
                            
                        }
                        else{
                            cell.surgeryName.text = sch.surgeryType
                        }
                        cell.doctorName.text = sch.doctorId
                        cell.status.text = " "
                        cell.statusImage.hidden = true
                        contractExpDat = sch.contractExpiryDate
                    }
                }
            }
            return cell
        }
        else  {
            let cell = tableView.dequeueReusableCellWithIdentifier("scheduleCell") as! ScheduleTableViewCell
            cell.statusImage.hidden = false
            var sch = Schedules()
            
            if status.selectedSegmentIndex == 1 {
                sch = self.recordsNew[indexPath.row]
            }
            else if status.selectedSegmentIndex == 2 {
                sch = self.records[indexPath.row]
            }
            
            let utility = Utility()
            let date = sch.startTime
            cell.time.text = utility.getTime(date!)
            cell.date.text = utility.getDate(date!)
            let scheduleType = sch.surgeryType
            
            if scheduleType == nil {
                cell.surgeryName.text = "No Value"
            }
            else{
                cell.surgeryName.text = sch.surgeryType
            }
            cell.doctorName.text = sch.doctorId
            cell.status.text = sch.statusCode
            
            if sch.statusCode == Constants.kRejected {
                cell.statusImage.image = UIImage(named: "alert red")
                return cell
            }
            else{
                
                cell.statusImage.image = nil
                return cell
            }
            
        }
    }
    
    // adding Editing Styles here.
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let confirm = UITableViewRowAction(style: .Normal, title: "Confirm as\nNormal") { action, index in
            self.confirmSchedule("CONFIRMED", tableView: tableView, indexPath: indexPath)
        }
        
        let confirm_Revisoned = UITableViewRowAction(style: .Normal, title: "Confirm as\nRevisioned") { action, index in
            self.confirmSchedule("CONFIRMED_REVISIONED",tableView: tableView,indexPath: indexPath)
        }
        
        confirm.backgroundColor = Constants.greenColor
        confirm_Revisoned.backgroundColor = UIColor.lightGrayColor()
        return [confirm_Revisoned,confirm]
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // the cells you would like the actions to appear needs to be editable
        if status.selectedSegmentIndex == 0 {
            return true
        }
        else{
            return false
        }
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if status.selectedSegmentIndex == 0 {
            if value == Constants.kVendor {
                performSegueWithIdentifier("toMail", sender: selectedTableView!.cellForRowAtIndexPath(indexPath))
            }
        }
        else if status.selectedSegmentIndex == 1 {
            fromConsumptionTab = true
            performSegueWithIdentifier("toConsumptionItems", sender: tableView.cellForRowAtIndexPath(indexPath))
        }
        else if status.selectedSegmentIndex == 2 {
                let status = records[indexPath.row].statusCode
                if status == Constants.kRejected {
                    fromConsumptionTab = false
                    recordsNew = records
                    performSegueWithIdentifier("toConsumptionItems", sender: tableView.cellForRowAtIndexPath(indexPath))
                }
                else {
                    performSegueWithIdentifier("toApprove", sender: tableView.cellForRowAtIndexPath(indexPath))
            }
        }

    }
    
    // MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if sender != nil {
        let cell = sender as! ScheduleTableViewCell
        if segue.identifier == "toConsumptionItems"  && fromConsumptionTab == true {
            let indexpath = ConsumptionTableView.indexPathForCell(cell)
            let surgeryController = segue.destinationViewController as! SurgeryDetailsViewController
            surgeryController.status = cell.status.text
            let utility = Utility()
            
            let date = recordsNew[(indexpath?.row)!].startTime
            let aScheduleId = recordsNew[(indexpath?.row)!].scheduleId
            surgeryController.scheduleID = aScheduleId
            surgeryController.patientID = recordsNew[(indexpath?.row)!].patientId
            surgeryController.doctor = recordsNew[(indexpath?.row)!].doctorId
            surgeryController.date = utility.getDate(date!)
            surgeryController.time = utility.getTime(date!)
            surgeryController.surgery = recordsNew[(indexpath?.row)!].surgeryType
            surgeryController.contractExpDate = recordsNew[(indexpath?.row)!].contractExpiryDate
            surgeryController.vendorID = recordsNew[(indexpath?.row)!].vendorId
            
        }
        else if segue.identifier == "toConsumptionItems" && fromConsumptionTab == false {
            let indexpath = ConsumptionTableView.indexPathForCell(cell)
            let surgeryController = segue.destinationViewController as! SurgeryDetailsViewController
            surgeryController.status = cell.status.text
            let utility = Utility()
            
            let date = records[(indexpath?.row)!].startTime
            let aScheduleId = records[(indexpath?.row)!].scheduleId
            surgeryController.scheduleID = aScheduleId
            surgeryController.patientID = records[(indexpath?.row)!].patientId
            surgeryController.doctor = records[(indexpath?.row)!].doctorId
            surgeryController.date = utility.getDate(date!)
            surgeryController.time = utility.getTime(date!)
            surgeryController.surgery = records[(indexpath?.row)!].surgeryType
            surgeryController.contractExpDate = records[(indexpath?.row)!].contractExpiryDate
            surgeryController.vendorID = recordsNew[(indexpath?.row)!].vendorId
            
        }
        else if segue.identifier == "toMail" {
            let mailController = segue.destinationViewController as! MailViewController
            //            mailController.patientID = cell.patientID.text
            mailController.doctor = cell.doctorName.text
            mailController.date = cell.date.text
            mailController.time = cell.time.text
            mailController.surgery = cell.surgeryName.text
            mailController.contractExpiryDate = contractExpDat
        }
        else if segue.identifier == "toApprove" {
            let indexpath = ConsumptionTableView.indexPathForCell(cell)
            let surgeryController = segue.destinationViewController as! NurseSurgeryDetailsViewController
            surgeryController.status = cell.status.text
            let utility = Utility()
            let date = records[(indexpath?.row)!].startTime
            surgeryController.consumptionID = records[(indexpath?.row)!].scheduleId
            surgeryController.patientID = records[(indexpath?.row)!].patientId
            surgeryController.doctor = records[(indexpath?.row)!].doctorId
            surgeryController.date = utility.getDate(date!)
            surgeryController.time = utility.getTime(date!)
            surgeryController.surgery = records[(indexpath?.row)!].surgeryType
            surgeryController.contractExpDate = records[(indexpath?.row)!].contractExpiryDate
        }
     }
    }
    
    // MARK: User-Defined Functions
    private func getImmediateSchedules() {
        comsumptionResult.removeAll()
        self.objSchedules.removeAll()
        let obj = CommonManager()
        obj.getSummaryList("schedule?Main=SCHEDULES&EndTime=\(immediateDateToBeUsed!)&offset=\(0)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                
                self.spinner.stopAnimating();
                self.spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200
                    {
                        //self.objSchedules = [Schedules]()
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            sch.contractExpiryDate = obj["contractExpiryDate"] as? String
                            self.objSchedules.append(sch)
                        }
                        
                        self.comsumptionResult = self.objSchedules
                        self.immediateTableView.reloadData()
                    }
                    else if statusSummary == 403 {
                        let alertController = UIAlertController(title: "Session expired", message:
                            "please login again", preferredStyle: UIAlertControllerStyle.Alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                            is403Status = true
                            for request in inprogressRequests
                            {
                                request.invalidateAndCancel()
                            }
                            is403Status = false
                            self.showLogin()
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else{
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    private func getThisWeekSchedules() {
        thisWeekResult.removeAll()
        objSchedulesThisWeek.removeAll()
        let obj = CommonManager()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        
        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(thisWeekStartDateToBeUsed!)&EndTime=\(thisWeekEndDateToBeUsed!)&offset=0&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                self.spinner.stopAnimating();
                self.spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200
                    {
                        self.objSchedulesThisWeek = [Schedules]()
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            sch.contractExpiryDate = obj["contractExpiryDate"] as? String
                            self.objSchedulesThisWeek.append(sch)
                        }
                        self.thisWeekResult = self.objSchedulesThisWeek
                        self.thisWeekTableView.reloadData()
                    }
                    else if statusSummary == 403 {
                        let alertController = UIAlertController(title: "Session expired", message:
                            "please login again", preferredStyle: UIAlertControllerStyle.Alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                            is403Status = true
                            for request in inprogressRequests
                            {
                                request.invalidateAndCancel()
                            }
                            is403Status = false
                            self.showLogin()
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else{
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    private func getNextWeekSchedules() {
        nextWeekResult.removeAll()
        objSchedulesRemainWeek.removeAll()
        let obj = CommonManager()
        self.spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        
        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(nextWeekStartDateToBeUsed!)&EndTime=\(nextWeekEndDateToBeUsed!)&offset=0&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                self.spinner.stopAnimating();
                self.spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200
                    {
                        self.objSchedulesRemainWeek = [Schedules]()
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            sch.contractExpiryDate = obj["contractExpiryDate"] as? String
                            self.objSchedulesRemainWeek.append(sch)
                        }
                        
                        self.nextWeekResult = self.objSchedulesRemainWeek
                        self.remainingTableView.reloadData()
                    }
                    else if statusSummary == 403 {
                        let alertController = UIAlertController(title: "Session expired", message:
                            "please login again", preferredStyle: UIAlertControllerStyle.Alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                            is403Status = true
                            for request in inprogressRequests
                            {
                                request.invalidateAndCancel()
                            }
                            is403Status = false
                            self.showLogin()
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else{
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    func makeTableViewReadOnly(){
        
        if value == Constants.kNurse {
            immediateTableView.allowsSelection = false
            thisWeekTableView.allowsSelection = false
            remainingTableView.allowsSelection = false
        }
        
    }
    
    func confirmSchedule(scheduleType:String,tableView: UITableView,indexPath: NSIndexPath) {
        var consumptionObjectSelected:String?
        var consumptionResultToBeAccessed:[Schedules]?
        
        if tableView == self.immediateTableView {
            consumptionObjectSelected = self.comsumptionResult[indexPath.row].scheduleId
            consumptionResultToBeAccessed = self.comsumptionResult
        }
        else if tableView == self.thisWeekTableView {
            consumptionObjectSelected = self.thisWeekResult[indexPath.row].scheduleId
            consumptionResultToBeAccessed = self.thisWeekResult
        }
        else if tableView == self.remainingTableView {
            consumptionObjectSelected = self.nextWeekResult[indexPath.row].scheduleId
            consumptionResultToBeAccessed = self.nextWeekResult
        }
        
        if tableView != self.ConsumptionTableView {
            if consumptionResultToBeAccessed != nil && consumptionResultToBeAccessed?.count > 0 {
                let obj = CommonManager()
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = self.view.center
                self.view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.confirmSchedule(consumptionObjectSelected!,statusCode: scheduleType, callback: {(data,error,status, connectivityFlag) in
                    dispatch_async(dispatch_get_main_queue(), {
                        spinner.stopAnimating();
                        spinner.removeFromSuperview()
                        UIApplication.sharedApplication().endIgnoringInteractionEvents()
                        
                        do{
                            if connectivityFlag == false {
                                self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: "Cannot Confirm a Schedule without Internet", delegate: self)
                                
                            }
                            else if status == 200 {
                                if tableView == self.immediateTableView {
                                    self.comsumptionResult.removeAtIndex(indexPath.row)
                                }
                                else if tableView == self.thisWeekTableView {
                                    self.thisWeekResult.removeAtIndex(indexPath.row)
                                }
                                else if tableView == self.remainingTableView {
                                    self.nextWeekResult.removeAtIndex(indexPath.row)
                                }
                                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation:UITableViewRowAnimation.Left)
                                self.getSummaryCount()
                                self.getConsumptions()
                            }
                            else {
                                let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                let parseJSON = json
                                let  error = parseJSON["error"]
                                self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                            }
                        }
                        catch{
                            let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                        }
                    })
                })
            }
        }
    }
    
    func expandOrCollapse (sender:UIButton) {
        
        selectedTableView = sender.superview?.superview as? UITableView
        immediateheight?.constant = Constants.standardCellHeight
        thisweekheight?.constant = Constants.standardCellHeight
        remainingheight?.constant = Constants.standardCellHeight
        
        if selectedTableView == immediateTableView {
            arrowChange = 1;
            immediateheight?.constant = selectedTableViewHeight!
            reloadTables()
        }
        else if selectedTableView == thisWeekTableView {
            arrowChange = 2;
            thisweekheight?.constant = selectedTableViewHeight!
            reloadTables()
        }
        else if selectedTableView == remainingTableView {
            arrowChange = 3;
            remainingheight?.constant = selectedTableViewHeight!
            reloadTables()
        }
        
    }
    
    @IBAction func settingButtonClicked(sender: AnyObject) {
        
        let vc = storyboard?.instantiateViewControllerWithIdentifier("settingsSegue") as! SettingTableViewController
        vc.delegate = self
        vc.prefUpdateDelegate = self
        let navController = UINavigationController(rootViewController: vc)
        navController.modalPresentationStyle = UIModalPresentationStyle.Popover
        navController.popoverPresentationController?.sourceView = self.view
        navController.popoverPresentationController?.sourceRect = CGRectMake(13, 20, 50, 30)
        let popover = navController.popoverPresentationController
        popover?.delegate = self
        popover?.barButtonItem = sender as? UIBarButtonItem
        vc.selectedIndex = self.selectrow
        self.presentViewController(navController, animated: true, completion: nil)
        
    }
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }
    
    private func changeHeight() {
        
        if status.selectedSegmentIndex == 0 {
            self.ConsumptionTableView.hidden = true
            self.consumptionView.hidden = false
            thisWeekTableView.hidden = false
            immediateTableView.hidden = false
            remainingTableView.hidden = false
            selectedTableView = immediateTableView
        }
        else {
            self.ConsumptionTableView.hidden = false
            self.consumptionView.hidden = true
        }
        
    }
    
    
    @IBAction func changedSegementControllerValue(sender: AnyObject) {
        
        if status.selectedSegmentIndex == 0 {
            self.ConsumptionTableView.hidden = true
            reachedEndOfItems = false
            reachedThisWeekEndOfItems = false
            reachedRemainWeekEndOfItems = false
            offset = 0
            offsetThisWeek = 0
            offsetRemainWeek = 0

            self.getSummaryCount()
            self.getImmediateSchedules()
            self.getThisWeekSchedules()
            self.getNextWeekSchedules()
            changeHeight()
            self.immediateTableView.reloadData()
            self.thisWeekTableView.reloadData()
            self.remainingTableView.reloadData()
        }
        else if status.selectedSegmentIndex == 1 {
            self.reachedEndOfConsumptionItems = false
            offsetConsumptions = 0
            self.consumptionView.hidden = true
            self.getConsumptions()
            recordsNew = result
            changeHeight()
            ConsumptionTableView.reloadData()
        }
        else if status.selectedSegmentIndex == 2 {
            self.consumptionView.hidden = true
            self.reachedEndOfCompletedItems = false
            offsetCompleted = 0
            self.getCompletedList()
            records = completedRecords
            changeHeight()
            ConsumptionTableView.reloadData()
        }
        else {
            self.consumptionView.hidden = true
            changeHeight()
            ConsumptionTableView.reloadData()
        }
        
    }
    
    private func rangeOfPeriod(period: NSCalendarUnit) -> (NSDate, NSDate) {
        
        let date = NSDate()
        let calendar = NSCalendar.currentCalendar()
        var startDate: NSDate? = nil
        calendar.rangeOfUnit(period, startDate: &startDate, interval: nil, forDate: date)
        let endDate = calendar.dateByAddingUnit(period, value: 1, toDate: startDate!, options: [])
        return (startDate!, endDate!)
        
    }
    
    private func getDate() -> (String, String, String, String, String) {
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let startOfDay = NSCalendar.currentCalendar().startOfDayForDate(NSDate())
        let calendar = NSCalendar.currentCalendar()
        let aDayFromNow = calendar.dateByAddingUnit(.Day, value: 1, toDate: startOfDay, options: [])
        let comps = calendar.components([.Year, .Month, .Day, .Hour, .Minute, .Second], fromDate:aDayFromNow!)
        comps.hour = 23
        comps.minute = 59
        comps.second = 59
        let midnightOfToday = calendar.dateFromComponents(comps)!
        let tomrwDate = dateFormatter.stringFromDate(midnightOfToday)
        let (startOfWeek, endOfWeek) = rangeOfPeriod(.WeekOfYear)
        _ = dateFormatter.stringFromDate(startOfWeek)
        let nextWeekStartDay = dateFormatter.stringFromDate(endOfWeek)
        let nextWeekEnd = calendar.dateByAddingUnit(.Day, value: 6, toDate: endOfWeek, options: [])
        let nextWeekEndDay = dateFormatter.stringFromDate(nextWeekEnd!)
        
        
        // This Week Start&End Day
        var beginningOfWeek: NSDate?
        var weekDuration = NSTimeInterval()
        var thisWeekStartDay:String?
        var thisWeekEndDay:String?
        
        if getDayOfWeek() == 7 {
            thisWeekStartDay = nextWeekStartDay
            thisWeekEndDay = nextWeekEndDay
        }
        else {
            if calendar.rangeOfUnit(.WeekOfYear, startDate: &beginningOfWeek, interval: &weekDuration, forDate: NSDate()) {
                let endOfWeek = beginningOfWeek?.dateByAddingTimeInterval(weekDuration)
                thisWeekStartDay = dateFormatter.stringFromDate(beginningOfWeek!)
                thisWeekEndDay =  dateFormatter.stringFromDate(endOfWeek!)
            }
        }
        
        return (tomrwDate,thisWeekStartDay!,thisWeekEndDay!,nextWeekStartDay,nextWeekEndDay)
    }
    
    func getDayOfWeek() -> Int {
        let myCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)!
        let myComponents = myCalendar.components(.Weekday, fromDate: NSDate())
        let weekDay = myComponents.weekday
        return weekDay
    }
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        // UITableView only moves in one direction, y axis
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        // Change 10.0 to adjust the distance from bottom
        if maximumOffset - currentOffset <= 10.0 {
            if scrollView == immediateTableView {
                self.loadMoreItems()
            }
            if scrollView == thisWeekTableView {
                self.loadThisWeekMoreItems()
            }
            if scrollView == remainingTableView {
                self.loadMoreRemainWeekItems()
            }
            if scrollView == ConsumptionTableView && status.selectedSegmentIndex == 1 {
                self.loadMoreConsumptionItems()
            }
            if scrollView == ConsumptionTableView && status.selectedSegmentIndex == 2 {
                self.loadMoreCompletedItems()
            }
        }
    }
    private func loadMoreCompletedItems() {
        guard !self.reachedEndOfCompletedItems else {
            self.offsetCompleted = 0
            return
        }
        var thisBatchOfCompleteditems = [Schedules]()
        let endCompleted = self.offsetCompleted + self.itemsPerBatch
        do {
            thisBatchOfCompleteditems = self.aPageofItemsCompleted(endCompleted)
        }
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItems = [Schedules]()
            if  self.records == thisBatchOfCompleteditems {
            }
            else {
                newItems = thisBatchOfCompleteditems
                self.records.appendContentsOf(newItems)
                self.ConsumptionTableView.reloadData()
                
                if newItems.count < self.itemsPerBatch {
                    self.reachedEndOfCompletedItems = true
                }
            }
            self.offsetCompleted += self.itemsPerBatch
        })
    }
    
    private func loadMoreConsumptionItems() {
        guard !self.reachedEndOfConsumptionItems else {
            self.offsetConsumptions = 0
            return
        }
        var thisBatchOfConsumptionItems = [Schedules]()
        let endConsumptions = self.offsetConsumptions + self.itemsPerBatch
        do {
            thisBatchOfConsumptionItems = self.aPageofItemsConsumptions(endConsumptions)
        }
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItems = [Schedules]()
            if  self.recordsNew == thisBatchOfConsumptionItems {
            }
            else {
                newItems = thisBatchOfConsumptionItems
                self.recordsNew.appendContentsOf(newItems)
                self.ConsumptionTableView.reloadData()
                
                if newItems.count < self.itemsPerBatch {
                    self.reachedEndOfConsumptionItems = true
                }
            }
            self.offsetConsumptions += self.itemsPerBatch
        })
    }
    
    private func loadMoreItems() {
        
        guard !self.reachedEndOfItems else {
            self.offset = 0
            return
        }
        
        // determine the range of data items to fetch
        var thisBatchOfItems = [Schedules]()
        let end = self.offset + self.itemsPerBatch
        
        // query the database
        do {
            thisBatchOfItems = self.aPageofItems(end, dateFilter: immediateDateToBeUsed!)
        }
        
        // update UITableView with new batch of items on main thread after query finishes
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItems = [Schedules]()
            if  self.comsumptionResult == thisBatchOfItems {
            }
            else {
                newItems = thisBatchOfItems
                
                // append the new items to the data source for the table view
                self.comsumptionResult.appendContentsOf(newItems)
                
                // reload the table view
                self.immediateTableView.reloadData()
                
                // check if this was the last of the data
                if newItems.count < self.itemsPerBatch {
                    self.reachedEndOfItems = true
                }
            }
            self.offset += self.itemsPerBatch
        })
    }
    
    private func loadThisWeekMoreItems() {
        
        guard !self.reachedThisWeekEndOfItems else {
            self.offsetThisWeek = 0
            return
        }
        
        var thisBatchOfItemsThisWeek = [Schedules]()
        let endThisWeek = self.offsetThisWeek + self.itemsPerBatch
        
        do {
            thisBatchOfItemsThisWeek = self.aPageofItemsThisWeek(endThisWeek, dateFilter1: thisWeekStartDateToBeUsed! ,dateFilter2: thisWeekEndDateToBeUsed!)
        }
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItems = [Schedules]()
            if  self.thisWeekResult == thisBatchOfItemsThisWeek {
                
            }
            else {
                newItems = thisBatchOfItemsThisWeek
                self.thisWeekResult.appendContentsOf(newItems)
                self.thisWeekTableView.reloadData()
                
                if newItems.count < self.itemsPerBatch {
                    self.reachedThisWeekEndOfItems = true
                }
                
            }
            self.offsetThisWeek += self.itemsPerBatch
        })
    }
    
    private func loadMoreRemainWeekItems() {
        
        guard !self.reachedRemainWeekEndOfItems else {
            self.offsetRemainWeek = 0
            return
        }
        
        var thisBatchOfItemsRemainWeek = [Schedules]()
        let endRemainWeek = self.offsetRemainWeek + self.itemsPerBatch
        
        do {
            thisBatchOfItemsRemainWeek = self.aPageofItemsRemainWeek(endRemainWeek, dateFilter1: nextWeekStartDateToBeUsed!,dateFilter2: nextWeekEndDateToBeUsed!)
        }
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItemsRemainWeek = [Schedules]()
            if  self.nextWeekResult == thisBatchOfItemsRemainWeek {
                
            }
            else {
                newItemsRemainWeek = thisBatchOfItemsRemainWeek
                self.nextWeekResult.appendContentsOf(newItemsRemainWeek)
                self.remainingTableView.reloadData()
                
                if newItemsRemainWeek.count < self.itemsPerBatch {
                    self.reachedRemainWeekEndOfItems = true
                }
                
            }
            self.offsetRemainWeek += self.itemsPerBatch
        })
    }
    
    private func aPageofItems(start: Int,dateFilter: String) -> [Schedules] {
        
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getSummaryList("schedule?Main=SCHEDULES&EndTime=\(dateFilter)&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do {
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        self.objSchedules = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            self.objSchedules.append(sch)
                        }
                    }
                    else {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch {
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        return objSchedules
    }
    
    private func aPageofItemsThisWeek(start: Int,dateFilter1: String,dateFilter2:String) -> [Schedules]{
        
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(dateFilter1)&EndTime=\(dateFilter2)&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200 {
                        self.objSchedulesThisWeek = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON {
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            self.objSchedulesThisWeek.append(sch)
                        }
                        
                    }
                    else{
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        return objSchedulesThisWeek
    }
    
    private func aPageofItemsRemainWeek(start: Int,dateFilter1: String,dateFilter2:String) -> [Schedules] {
        
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(dateFilter1)&EndTime=\(dateFilter2)&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200 {
                        self.objSchedulesRemainWeek = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            
                            self.objSchedulesRemainWeek.append(sch)
                        }
                        
                    }
                    else {
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        return objSchedulesRemainWeek
    }
    
    private func getConsumptions()  {
        self.result.removeAll()
        self.recordsNew.removeAll()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        
        obj.getSummaryList("schedule?Main=CONSUMPTIONS&offset=0&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do {
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200 {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        self.result = [Schedules]()
                        self.recordsNew = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            sch.contractExpiryDate = obj["contractExpiryDate"] as? String
                            sch.vendorId = obj["vendorID"] as? String
                            self.result.append(sch)
                        }
                        self.recordsNew = self.result
                        self.ConsumptionTableView.reloadData()
                    }
                    else if statusSummary == 403 {
                        let alertController = UIAlertController(title: "Session expired", message:
                            "please login again", preferredStyle: UIAlertControllerStyle.Alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                            is403Status = true
                            for request in inprogressRequests
                            {
                                request.invalidateAndCancel()
                            }
                            is403Status = false
                            self.showLogin()
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    func currencySelected(currName: NSInteger, hospitalName: NSString) {
        selectrow = currName
        NSUserDefaults.standardUserDefaults().setObject(hospitalName, forKey: Constants.KDHospital)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    func updateLoggedinSession() {
        self.viewWillAppear(true)
    }
    
    private func getSummaryCount()  {
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        
        obj.getSummaryList("schedulesummary?Main=SCHEDULES", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200 {
                        let jsonn = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSONN = jsonn
                        if let immediate = parseJSONN["immediate"] as? NSNumber{
                            self.immediateCount = immediate.stringValue
                        }
                        
                        if let thisWeek = parseJSONN["thisWeek"] as? NSNumber{
                            self.thisWeekCount = thisWeek.stringValue
                        }
                        
                        if let nextWeek = parseJSONN["nextWeek"] as? NSNumber{
                            self.nextWeekCount = nextWeek.stringValue
                        }
                        
                        self.immediateTableView.reloadData()
                        self.thisWeekTableView.reloadData()
                        self.remainingTableView.reloadData()
                    }
                    else if statusSummary == 403 {
                        let alertController = UIAlertController(title: "Session expired", message:
                            "please login again", preferredStyle: UIAlertControllerStyle.Alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                            is403Status = true
                            for request in inprogressRequests
                            {
                                request.invalidateAndCancel()
                            }
                            is403Status = false
                            self.showLogin()
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else{
                        let jsonn = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSONN = jsonn
                        let  error = parseJSONN["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        
    }
    
    private func getCompletedList()  {
        self.completedRecords.removeAll()
        self.records.removeAll()
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getCompletedList("offset=0&limit=10", callbackCompleted: {(dataCompleted,errorCompleted,statusCompleted,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusCompleted == 200 {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataCompleted, options:[])
                        var parseJSON = json
                        parseJSON = parseJSON as! NSArray
                        
                        for aSch in parseJSON as! [AnyObject] {
                            let schedule = aSch["schedule"]
                            let statusCode = aSch["statusCode"]
                            let id = aSch["id"]
                            let  sch = Schedules()
                            if let doctorDetails = schedule!!["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = schedule!!["startTime"] as? String
                            sch.surgeryType = schedule!!["subject"] as? String
                            sch.statusCode = statusCode as? String
                            sch.patientId = schedule!!["patientID"] as? String
                            sch.scheduleId = id as? String
                            self.completedRecords.append(sch)
                        }
                        
                        self.records = self.completedRecords
                        self.ConsumptionTableView.reloadData()
                    }
                    else if statusCompleted == 403 {
                        let alertController = UIAlertController(title: "Session expired", message:
                            "please login again", preferredStyle: UIAlertControllerStyle.Alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                            is403Status = true
                            for request in inprogressRequests
                            {
                                request.invalidateAndCancel()
                            }
                            is403Status = false
                            self.showLogin()
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else{
                        let json = try NSJSONSerialization.JSONObjectWithData(dataCompleted, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataCompleted, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    private func reloadTables() {
        immediateTableView.reloadData()
        thisWeekTableView.reloadData()
        remainingTableView.reloadData()
    }
    
    private func aPageofItemsCompleted(start: Int) -> [Schedules]{
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getCompletedList("offset=\(start)&limit=10", callbackCompleted: {(dataCompleted,errorCompleted,statusCompleted,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusCompleted == 200 {
                        self.completedRecords = [Schedules]()
                        
                        let json = try NSJSONSerialization.JSONObjectWithData(dataCompleted, options:[])
                        var parseJSON = json
                        parseJSON = parseJSON as! NSArray
                        
                        for aSch in parseJSON as! [AnyObject] {
                            let schedule = aSch["schedule"]
                            let statusCode = aSch["statusCode"]
                            let id = aSch["id"]
                            let  sch = Schedules()
                            if let doctorDetails = schedule!!["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = schedule!!["startTime"] as? String
                            sch.surgeryType = schedule!!["subject"] as? String
                            sch.statusCode = statusCode as? String
                            sch.patientId = schedule!!["patientID"] as? String
                            sch.scheduleId = id as? String
                            self.completedRecords.append(sch)
                        }
                        
                        self.ConsumptionTableView.reloadData()
                    }
                    else{
                        let json = try NSJSONSerialization.JSONObjectWithData(dataCompleted, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataCompleted, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        return self.completedRecords
        
    }
    
    private func aPageofItemsConsumptions(start: Int) -> [Schedules] {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        
        obj.getSummaryList("schedule?Main=CONSUMPTIONS&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do {
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusSummary == 200 {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        self.result = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            if let doctorDetails = obj["doctor"] as? NSDictionary {
                                if let doctorInfo = doctorDetails.valueForKey("person") as? NSDictionary  {
                                    if let firstName = doctorInfo.valueForKey("firstName") as? String  {
                                        sch.doctorId = firstName
                                    }
                                    if let lastName = doctorInfo.valueForKey("lastName") as? String {
                                        sch.doctorId = sch.doctorId! + " " + lastName
                                    }
                                }
                            }
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["subject"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            sch.contractExpiryDate = obj["contractExpiryDate"] as? String
                            sch.vendorId = obj["vendorID"] as? String
                            self.result.append(sch)
                        }
                        self.ConsumptionTableView.reloadData()
                    }
                    else {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        return self.result
    }
    
    func showLogin() {
        let storage = NSHTTPCookieStorage.sharedHTTPCookieStorage()
        storage.removeCookiesSinceDate(NSDate())
        for cookie in storage.cookies! {
            storage.deleteCookie(cookie)
        }
        NSUserDefaults.standardUserDefaults().setObject(nil, forKey: Constants.kCookie)
        NSUserDefaults.standardUserDefaults().synchronize()
        
        if is403Status {
            is403Status = false
            for request in inprogressRequests
            {
                request.invalidateAndCancel()
            }
        }


        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let loginPage = storyboard.instantiateViewControllerWithIdentifier("loginVC")
        let appDelegate  = UIApplication.sharedApplication().delegate as! AppDelegate
        appDelegate.window?.rootViewController = loginPage
    }
    
}
