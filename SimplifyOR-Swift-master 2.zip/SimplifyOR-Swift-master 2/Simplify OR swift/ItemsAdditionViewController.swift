//
//  ItemsAdditionViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/16/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import AVFoundation
import CoreData

var didTapSaveButton = false
var didTapUpdateButton = false



class ItemsAdditionViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate, UITextFieldDelegate {
    
    // MARK: Constants Declaration
    let alertViewObject = Utility()
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var itemScan: UIButton!
    @IBOutlet weak var dateScan: UIButton!
    @IBOutlet weak var lotScan: UIButton!
    @IBOutlet weak var wastedSwitchLabel: UILabel!
    @IBOutlet weak var usedSwitchLabel: UILabel!
    @IBOutlet weak var quantityOne: UILabel!
    @IBOutlet weak var wastedSwitch: UISwitch!
    @IBOutlet weak var usedSwitch: UISwitch!
    @IBOutlet weak var wastedValue: UITextField!
    @IBOutlet weak var wastedNumber: UILabel!
    @IBOutlet weak var usedValue: UITextField!
    @IBOutlet weak var usedNumber: UILabel!
    @IBOutlet weak var quantityLabel: UILabel!
    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var reset: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var dateCode: UITextField!
    @IBOutlet weak var lotNumber: UITextField!
    @IBOutlet weak var itemNumber: UITextField!
    @IBOutlet weak var dataEntryDetailslabel: UILabel!
    
    // MARK: Var Properties Declaration
    var captureSession : AVCaptureSession!
    var videoPreviewLayer : AVCaptureVideoPreviewLayer!
    var input:AVCaptureDeviceInput?
    var barCodeFrameView:UIView?
    var scannerLabel:UILabel?
    var tag:Int?
    var consumptionID: String?
    var record:AnyObject?
    var cQty:String?
    var sQty:String?
    var itemId:String?
    var operationQueue: NSOperationQueue?
    var networkReachability: Reachability?
    let tempRecord = Item()
    var connectionState = "Connected"
    let connectedState = "Connected"
    let notConnectedState = "notConnected"
    var newResult = [AnyObject]()
    var newResult1 = [AnyObject]()
    var isItemNoValid: NSNumber? 
    var isDateCodeValid: NSNumber?
    var isLotNoValid: NSNumber?
    var isConsumedQtyValid: NSNumber?
    var isScrappedQtyValid: NSNumber?
    var captureDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
    var captureMetadataOutput = AVCaptureMetadataOutput()

    //var aRecord = ConsumptionItem()
    var oldRecord = Item()

    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        
        super.viewDidLoad()
        updateButton.layer.cornerRadius = 5.0
        updateButton.layer.masksToBounds = true
        reset.layer.cornerRadius = 5.0
        reset.layer.masksToBounds = true
        save.layer.cornerRadius = 5.0
        save.layer.masksToBounds = true
        navigationController?.navigationItem.hidesBackButton = true
        
        self.itemNumber.autocapitalizationType = UITextAutocapitalizationType.AllCharacters
        self.lotNumber.autocapitalizationType = UITextAutocapitalizationType.AllCharacters
        self.dateCode.autocapitalizationType = UITextAutocapitalizationType.AllCharacters
        
        if ((record) != nil) {
            let aRecord = record as! ConsumptionItem
            updateView(true)
            itemNumber.userInteractionEnabled = false
            itemId = record?.itemId
            itemNumber.text = aRecord.chargeNo
            
            if aRecord.isLotValid == 0 {
                if aRecord.lotNo != nil {
                    let attributedString = NSMutableAttributedString(string:aRecord.lotNo!)
                    attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.redColor(), range: NSMakeRange(0, attributedString.length))
                    lotNumber.attributedText = attributedString
                }
                else {
                    lotNumber.text = "";
                }
            }
            else {
              lotNumber.text = aRecord.lotNo
            }
            
            if aRecord.isDateValid == 0 {
                if aRecord.dateCode != nil {
                let attributedString = NSMutableAttributedString(string:aRecord.dateCode!)
                attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.redColor(), range: NSMakeRange(0, attributedString.length))
                dateCode.attributedText = attributedString
                }
                else {
                    dateCode.text = "";
                }
            }
            else {
                dateCode.text = aRecord.dateCode
            }
            
            if aRecord.isConsumedQtyValid == 0 {
                let attributedString = NSMutableAttributedString(string:(aRecord.consumedQty?.stringValue)!)
                attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.redColor(), range: NSMakeRange(0, attributedString.length))
                usedValue.attributedText = attributedString
            }
            else{
                usedValue.text = aRecord.consumedQty?.stringValue
            }
            
            if aRecord.isRequiredQtyValid == 0 {
                let attributedString = NSMutableAttributedString(string:(aRecord.requiredQty?.stringValue)!)
                attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.redColor(), range: NSMakeRange(0, attributedString.length))
                wastedValue.attributedText = attributedString
            }
            else{
                wastedValue.text = aRecord.requiredQty?.stringValue
            }
            
            isItemNoValid = aRecord.isChargeNoValid
            isDateCodeValid = aRecord.isDateValid
            isLotNoValid = aRecord.isLotValid
            isConsumedQtyValid = aRecord.isConsumedQtyValid
            isScrappedQtyValid = aRecord.isRequiredQtyValid
            
            oldRecord.itemNo = aRecord.chargeNo
            oldRecord.lotNumber = aRecord.lotNo
            oldRecord.dateCode = aRecord.dateCode
            oldRecord.used = aRecord.consumedQty
            oldRecord.wasted = aRecord.requiredQty

            save.setTitle("Update", forState: .Normal)
        }
        
        changeLabelStatus()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.networkChange(_:)), name:ReachabilityChangedNotification, object: networkReachability)
        
          do {
            networkReachability = try Reachability.reachabilityForInternetConnection()
            try networkReachability?.startNotifier()
        }
          catch {
            print("Network rechability try failed")
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: User-Defined Functions
    private func changeLabelStatus() {
        dataEntryDetailslabel.numberOfLines = 2
        if itemNumber.text?.characters.count == 0 && lotNumber.text?.characters.count == 0 && dateCode.text?.characters.count == 0 && usedValue.text?.characters.count == 0 && wastedValue.text?.characters.count == 0 {
            dataEntryDetailslabel.text = "Start typing or \'tap Camera\' icon to capture barcodes..."
        }
        else if itemNumber.text?.characters.count == 0 || dateCode.text?.characters.count == 0 || lotNumber.text?.characters.count == 0 {
            dataEntryDetailslabel.text = "Information missing! Scan or Add again."
        }
    }
    
    private func scanBarcode(sender:UIButton) {
        
        let cameraMediaType = AVMediaTypeVideo
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatusForMediaType(cameraMediaType)
        
        switch cameraAuthorizationStatus {
        case .Denied:
            self.alertViewObject.showAlertView("Camera access denied", alertMessage: "Please provide access to camera to scan bar code", delegate: self)
            break
        case .Authorized:
            popCamera()
            break
        case .Restricted:
            self.alertViewObject.showAlertView("Camera access Restricted", alertMessage: "Please provide access to camera to scan bar code", delegate: self)
            break
        case .NotDetermined:
            // Prompting user for the permission to use the camera.
            AVCaptureDevice.requestAccessForMediaType(cameraMediaType) { granted in
                if granted {
                    self.popCamera()
                } else {
                    self.alertViewObject.showAlertView("Camera access denied", alertMessage: "Please provide access to camera to scan bar code", delegate: self)
                }
            }
        }
        
    }
    
    private func popCamera() {
        self.view.userInteractionEnabled = false
        do {
            input = try AVCaptureDeviceInput(device: captureDevice) as AVCaptureDeviceInput
        } catch _ as NSError {
        }
        
        captureSession = AVCaptureSession()
        captureSession.addInput(input! as AVCaptureInput)
        captureMetadataOutput = AVCaptureMetadataOutput()
        self.captureSession?.addOutput(captureMetadataOutput)
        
        captureMetadataOutput.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
        captureMetadataOutput.metadataObjectTypes = captureMetadataOutput.availableMetadataObjectTypes
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session:captureSession)
        videoPreviewLayer?.frame = view.layer.bounds
        videoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        view.layer.addSublayer(videoPreviewLayer)
        
        // Initialize bar Code Frame to highlight the bar code
        barCodeFrameView = UIView()
        barCodeFrameView?.frame = CGRectMake(0, self.view.frame.height/2, self.view.frame.width, 50)
        scannerLabel = UILabel()
        scannerLabel?.frame = CGRectMake((self.view.frame.width/4), self.view.frame.height - 100, (self.view.frame.width/2), 50)
        scannerLabel?.textColor = UIColor.blackColor()
        scannerLabel?.font = UIFont.boldSystemFontOfSize(16.0)
        scannerLabel?.numberOfLines = 2
        scannerLabel?.textAlignment = NSTextAlignment.Center
        scannerLabel?.text = "Scan Barcodes using the rectangular area"
        
        customizeBorder(UIColor.redColor())
        view.addSubview(barCodeFrameView!)
        view.addSubview(scannerLabel!)
        view.bringSubviewToFront(barCodeFrameView!)
        view.bringSubviewToFront(scannerLabel!)
        captureSession.startRunning();
        
    }
    
    func customizeBorder(colorPassed : UIColor) {
        barCodeFrameView?.addBorderTopLeftEdge1(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderTopLeftEdge2(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderBottomLeftEdge1(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderBottomLeftEdge2(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderBottomRightEdge2(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderTopRightEdge2(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderTopRightEdge1(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderBottomRightEdge1(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderTopSubParts(size: 4.0, color: colorPassed)
        barCodeFrameView?.addBorderBottomSubParts(size: 4.0, color: colorPassed)
    }
    
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!) {
        if let barcodeDate = metadataObjects.first {
            barCodeFrameView?.layer.borderColor = UIColor.greenColor().CGColor
            if let vb = barcodeDate as? AVMetadataMachineReadableCodeObject {
                let barcodeReadable = vb
                barcodeDetected(barcodeReadable.stringValue)
                captureSession.stopRunning()
                captureSession = nil
            }
        }
    }
    
    private func barcodeDetected(code: String) {
        if tag == 11 {
            itemNumber.text = code
        }
        else if tag == 12 {
            lotNumber.text = code
        }
        else if tag == 13 {
            dateCode.text = code
        }
        customizeBorder(UIColor.greenColor())
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC)))
        dispatch_after(time, dispatch_get_main_queue(), { [weak self] in
            self?.barCodeFrameView?.removeFromSuperview()
            self?.scannerLabel?.removeFromSuperview()
            self?.videoPreviewLayer.removeFromSuperlayer()
            self?.view.userInteractionEnabled = true
            })
        
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        updateView(true)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func resetFields(sender: AnyObject) {
        if ((record) != nil) {
            view.endEditing(true)
            itemNumber.userInteractionEnabled = false
            lotNumber.text = ""
            dateCode.text = ""
            usedValue.text = ""
            wastedValue.text = ""
            updateView(true)
        }
        else {
            view.endEditing(true)
            lotNumber.text = ""
            itemNumber.text = ""
            dateCode.text = ""
            usedValue.text = ""
            wastedValue.text = ""
            updateView(false)
        }
    }
    
    @IBAction func saveDetails(sender: AnyObject) {
        

        didTapSaveButton = true
        let utility = Utility()
        gconnectionState = "Connected"
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        // Create Entity
        let entity = NSEntityDescription.entityForName("ConsumptionItem", inManagedObjectContext: appDelegate.managedObjectContext)
        
        if (record != nil){
            let aRecord = record as! ConsumptionItem
            aRecord.itemId = itemId
            aRecord.chargeNo = itemNumber.text
            aRecord.lotNo = lotNumber.text
            aRecord.dateCode = dateCode.text
            cQty = usedValue.text!
            aRecord.consumedQty = Int(usedValue.text!)
            sQty = wastedValue.text!
            aRecord.requiredQty = Int(wastedValue.text!)
            //Temp Record
            tempRecord.itemId = itemId
            tempRecord.itemNo = itemNumber.text
            tempRecord.lotNumber = lotNumber.text
            tempRecord.dateCode = dateCode.text
            tempRecord.used = Int(usedValue.text!)
            tempRecord.wasted = Int(wastedValue.text!)
        }
        else {
            //Temp Record
            tempRecord.itemId = itemId
            tempRecord.itemNo = itemNumber.text
            tempRecord.lotNumber = lotNumber.text
            tempRecord.dateCode = dateCode.text
            tempRecord.used = Int(usedValue.text!)
            tempRecord.wasted = Int(wastedValue.text!)
            
            if (wastedSwitch.hidden == true) && (usedValue.text?.characters.count == 0 || wastedValue.text?.characters.count == 0 || dateCode.text?.characters.count == 0 || lotNumber.text?.characters.count == 0 ) {
                alertViewObject.showAlertView("Fields mandatory", alertMessage: "Information missing!", delegate: self)
                dataEntryDetailslabel.text = "Information missing!!"
            }
            else {
            // Initialize Record
            let consumptionItem = ConsumptionItem(entity: entity!, insertIntoManagedObjectContext: appDelegate.managedObjectContext)
            //record 1
            consumptionItem.consumptionId = consumptionID
            consumptionItem.itemId = itemId
            consumptionItem.lotNo = lotNumber.text
            consumptionItem.dateCode = dateCode.text
            consumptionItem.chargeNo = itemNumber.text
            consumptionItem.isChargeNoValid = 1
            consumptionItem.isLotValid = 1
            consumptionItem.isDateValid = 1
            consumptionItem.isConsumedQtyValid = 1
            consumptionItem.isRequiredQtyValid = 1


            if usedValue.text?.characters.count > 0 {
                consumptionItem.consumedQty = Int(usedValue.text!)
                cQty = consumptionItem.consumedQty?.stringValue
            }
            else {
                if usedSwitch.on == true  {
                    consumptionItem.consumedQty = 1
                    cQty = consumptionItem.consumedQty?.stringValue
                }
                else {
                    consumptionItem.consumedQty = 0
                    cQty = consumptionItem.consumedQty?.stringValue
                    
                }
            }
            
            if wastedValue.text?.characters.count > 0 {
                consumptionItem.requiredQty = Int(wastedValue.text!)
                sQty = consumptionItem.requiredQty?.stringValue
            }
            else {
                if wastedSwitch.on == true  {
                    consumptionItem.requiredQty = 1
                    sQty = consumptionItem.requiredQty?.stringValue
                }
                else {
                    consumptionItem.requiredQty = 0
                    sQty = consumptionItem.requiredQty?.stringValue
                }
            }
            
            self.insertConsumption()
            }
        }
        
        let isSaved = utility.addOrUpdateCoreData(appDelegate.managedObjectContext)
        if isSaved {
            if save.titleLabel?.text == "Update" {
                didTapUpdateButton = true
                
                if itemId != nil{
                let predicate2 = NSPredicate(format: "itemId == %@", itemId!)
                if itemNumber.text != "" && lotNumber.text != "" && dateCode.text != "" && usedValue.text != "" && wastedValue.text != "" {
                    let (_,_) = utility.updateCoreData(predicate2, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext, itemId: itemId!, itemNumber:itemNumber.text!, lotNumber: lotNumber.text!, dateCode: dateCode.text!, used: Int(usedValue.text!)!, wasted: Int(wastedValue.text!)!,isItemValid:isItemNoValid!, isConsumedQtyValid:isConsumedQtyValid!, isDateCodeValid:isDateCodeValid!, isScrappedQtyValid:isScrappedQtyValid!, isLotValid:isLotNoValid!)
                    }

                } else {
                    alertViewObject.showAlertView(Constants.errorTitle, alertMessage: "All fields are mandatory", delegate: self)
                }
                let connectivityStatus = utility.hasConnectivity()
                
                if connectivityStatus {
                    self.updateConsumption()
                }
                else {
                    self.navigationController?.popViewControllerAnimated(true)
                }
            }
            else {
                //resetFields(reset)
            }
        }
        
    }
    
    func networkChange(notification: NSNotification) {
        
        if let reachability = notification.object as? Reachability {
            let remoteHostStatus: Int = (reachability.currentReachabilityStatus.hashValue)
                
                if  remoteHostStatus != 0 && connectionState == connectedState {
                    connectionState = notConnectedState
                    if didTapSaveButton == true && didTapUpdateButton == false {
                        insertConsumption()
                    }
                    else if didTapSaveButton == true && didTapUpdateButton == true {
                        updateConsumption()
                    }
                } else if remoteHostStatus == 0  && connectionState == notConnectedState {
                    connectionState = connectedState
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
            }
        }
        
    }
    
    @IBAction func updateCompleted(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func scanData(sender: UIButton) {
        updateView(false)
        tag = sender.tag
        scanBarcode(sender)
    }
    
    private func updateView(isHidden:Bool) {
        
        weak var weakSelf = self
        UIView.animateWithDuration(0.5, delay: 1.0, options: .TransitionCrossDissolve, animations: { () -> Void in
            weakSelf?.usedNumber.hidden = !isHidden
            weakSelf?.usedValue.hidden = !isHidden
            weakSelf?.wastedValue.hidden = !isHidden
            weakSelf?.wastedNumber.hidden = !isHidden
            weakSelf?.usedSwitch.hidden = isHidden
            weakSelf?.wastedSwitch.hidden = isHidden
            weakSelf?.wastedSwitchLabel.hidden = isHidden
            weakSelf?.usedSwitchLabel.hidden = isHidden
            weakSelf?.quantityOne.hidden = isHidden
            weakSelf?.quantityLabel.hidden = isHidden
            weakSelf?.itemScan.enabled = !isHidden
            weakSelf?.lotScan.enabled = !isHidden
            weakSelf?.dateScan.enabled = !isHidden
            
            if isHidden {
                weakSelf?.itemScan.setImage(UIImage(named: "barcode disabled"), forState: .Normal)
                weakSelf?.lotScan.setImage(UIImage(named: "barcode disabled"), forState: .Normal)
                weakSelf?.dateScan.setImage(UIImage(named: "barcode disabled"), forState: .Normal)
            } else {
                weakSelf?.itemScan.setImage(UIImage(named: "barcode enabled"), forState: .Normal)
                weakSelf?.lotScan.setImage(UIImage(named: "barcode enabled"), forState: .Normal)
                weakSelf?.dateScan.setImage(UIImage(named: "barcode enabled"), forState: .Normal)
            }
            }, completion: nil)
        
    }
    
    private func insertConsumption() {
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        let obj = CommonManager()
        if tempRecord.itemNo != nil && tempRecord.lotNumber != nil && tempRecord.dateCode != nil && cQty != nil && sQty != nil {
            spinner.startAnimating()
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
            obj.addLineItem(self.consumptionID!, itemNo: tempRecord.itemNo!, lotNumber: tempRecord.lotNumber!, dateCode: tempRecord.dateCode!, consumedQty: self.cQty!, scrappedQty: self.sQty!,isItemValid: 1,isConsumedQtyValid: 1,isDateCodeValid: 1,isScrappedQtyValid: 1,isLotValid: 1, callbackAdd: {(data,error,status,connectivityFlag) in
                dispatch_async(dispatch_get_main_queue(), {
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.noInternetMessage, alertMessage: "Consumption is saved offline, will be pushed to server  when Internet Connectivity is available", delegate: self)
                        }
                        else if status == 200
                        {
                            self.dataEntryDetailslabel.text = "Item added to consumption list. Add more.."
                            self.resetFields(self.reset)
                            didTapSaveButton = false
                        }
                        else
                        {
                            didTapSaveButton = false
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                    }
                    catch {
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                })
            })
        }
        
    }
    
    func getCompletedFlagItems() {
        if record != nil {
            if (isItemNoValid == 0) && (oldRecord.itemNo != tempRecord.itemNo) {
                isItemNoValid = 2
            }
            if (isDateCodeValid == 0) && (oldRecord.dateCode != tempRecord.dateCode) {
                isDateCodeValid = 2
            }
            if (isLotNoValid == 0) && (oldRecord.lotNumber != tempRecord.lotNumber) {
                isLotNoValid = 2
            }
            if (isConsumedQtyValid == 0) && (oldRecord.used != tempRecord.used) {
                isConsumedQtyValid = 2
            }
            if (isScrappedQtyValid == 0) && (oldRecord.wasted != tempRecord.wasted) {
                isScrappedQtyValid =  2
            }
        }
    }
    
    private func updateConsumption() {
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        let obj = CommonManager()
        getCompletedFlagItems()
        if tempRecord.itemNo != "" && tempRecord.lotNumber != "" && tempRecord.dateCode != "" && cQty != "" && sQty != "" {
            spinner.startAnimating()

            obj.updateLineItemWithStatus(consumptionID!, itemNo: tempRecord.itemNo!, lotNumber: tempRecord.lotNumber!, dateCode: tempRecord.dateCode!, consumedQty: cQty!, scrappedQty: sQty!,itemId:itemId! ,isItemValid: isItemNoValid!, isConsumedQtyValid: isConsumedQtyValid!, isDateCodeValid: isDateCodeValid!, isScrappedQtyValid: isScrappedQtyValid! , isLotValid: isLotNoValid!, callbackUpdate: {(data,error,status,connectivityFlag) in
                dispatch_async(dispatch_get_main_queue(), {
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.noInternetMessage, alertMessage: "Consumption got updated & saved offline, will be pushed to server  when Internet Connectivity is available", delegate: self)
                        }
                        else if status == 200
                        {
                            self.dataEntryDetailslabel.text = "Update successful"
                            didTapUpdateButton = false
                            self.navigationController?.popViewControllerAnimated(true)
                        }
                        else
                        {
                            didTapUpdateButton = false
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                    }
                    catch {
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                })
            })
        }
        else {
            alertViewObject.showAlertView(Constants.errorTitle, alertMessage: "All fields are mandatory", delegate: self)
        }
    }

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if captureSession == nil {
            view.endEditing(true)
        }
    }
    
    @IBAction func usedSwicthChanged(sender: UISwitch) {
        wastedSwitch.on = !sender.on
    }
    
    @IBAction func wastedSwicthChanged(sender: UISwitch) {
        usedSwitch.on = !sender.on
    }
    
    
    // MARK: - TextField Delegate Methods
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if textField.text?.characters.count != 0 {
            textField.text = textField.text?.uppercaseString
        }
        return true
    }
    
    // MARK: - Navigation
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    private func checkStatus(valueBeforeUpdate:String , valueAfterUpdate:String) -> NSNumber {
        var validityStatus : NSNumber = 1
        
        if !(valueBeforeUpdate == valueAfterUpdate) {
            validityStatus = 1
        }
        return validityStatus
    }
    
    private func checkValueChange(valueBeforeUpdate:String , valueAfterUpdate:String) -> Bool {
        
        if (valueBeforeUpdate == valueAfterUpdate) {
            return true
        }
        else {
            return false
        }
    }
    
    private func isValidityNil(isValidityField:NSNumber?) -> NSNumber{
        var validityStatus : NSNumber = 1
        if (isValidityField == nil) {
            validityStatus = 1;
        }
        return validityStatus

    }

}

extension UIView {
    //TOP SUBPARTS
    func addBorderTopSubParts(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: (frame.width / 4) + 10, y: 0, width: frame.width / 20, height: size, color: color)
        addBorderUtility(x: frame.width - (frame.width / 4) - 10, y: 0, width: -(frame.width / 20), height: size, color: color)
        let valChangeX = (frame.width / 4) + 20 + frame.width / 20
        addBorderUtility(x: valChangeX, y: 0, width: frame.width / 20, height: size, color: color)
        addBorderUtility(x: frame.width - valChangeX, y: 0, width: -(frame.width / 20), height: size, color: color)
    }
    
    //Bottom SUBPARTS
    func addBorderBottomSubParts(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: (frame.width / 4) + 10, y: frame.height - size, width: frame.width / 20, height: size, color: color)
        addBorderUtility(x: frame.width - (frame.width / 4) - 10, y: frame.height - size, width: -(frame.width / 20), height: size, color: color)
        let valChangeX = (frame.width / 4) + 20 + frame.width / 20
        addBorderUtility(x: valChangeX, y: frame.height - size, width: frame.width / 20, height: size, color: color)
        addBorderUtility(x: frame.width - valChangeX, y: frame.height - size, width: -(frame.width / 20), height: size, color: color)
    }
    
    // Top - LEFT- Edge 1
    func addBorderTopLeftEdge1(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: 0, y: 0, width: frame.width / 4, height: size, color: color)
    }
    // Bottom - left - Edge 1
    func addBorderBottomLeftEdge1(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: 0, y: frame.height - size, width: frame.width / 4, height: size, color: color)
    }
    
    // Bottom - left - Edge 2
    func addBorderBottomLeftEdge2(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: 0, y: frame.height - size, width: size, height: -(frame.height / 4), color: color)
    }
    
    // Top - LEFT- Edge 2
    func addBorderTopLeftEdge2(size size: CGFloat, color: UIColor) {
        //        addBorderUtility(x: 0, y: 0, width: size, height: frame.height / 4, color: color)
        addBorderUtility(x: 0, y: 0, width: size, height: frame.height / 4, color: color)
    }
    
    // Top-RIGHT-EDGE1
    func addBorderTopRightEdge1(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: frame.width, y: 0, width: -(frame.width / 4), height: size, color: color)
    }
    
    // Top right Edge 2
    func addBorderTopRightEdge2(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: frame.width - size, y: 0, width: size, height: frame.height / 4, color: color)
    }
    
    // Bottom -RIGHT- EDGE 1
    func addBorderBottomRightEdge1(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: frame.width, y: frame.height - size, width: -(frame.width / 4), height: size, color: color)
    }
    
    // Bottom - Right Edge 2
    func addBorderBottomRightEdge2(size size: CGFloat, color: UIColor) {
        addBorderUtility(x: frame.width - size, y: frame.height - size, width: size, height: -(frame.height / 4), color: color)
    }
    
    private func addBorderUtility(x x: CGFloat, y: CGFloat, width: CGFloat, height: CGFloat, color: UIColor) {
        let border = CALayer()
        border.backgroundColor = color.CGColor
        border.frame = CGRect(x: x, y: y, width: width, height: height)
        layer.addSublayer(border)
    }
}

