//
//  DetailsTableViewCell.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/17/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var doctor: UILabel!
    @IBOutlet weak var patientID: UILabel!
    @IBOutlet weak var contractExp: UILabel!
    @IBOutlet weak var contractExpDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
