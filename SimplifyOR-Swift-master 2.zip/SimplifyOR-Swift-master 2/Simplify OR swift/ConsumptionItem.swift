//
//  ConsumptionItem.swift
//  Simplify OR swift
//
//  Created by Arunava Sanyal on 17/08/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import Foundation
import CoreData


class ConsumptionItem: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}

extension ConsumptionItem {
    
    @NSManaged var chargeNo: String?
    @NSManaged var consumedQty: NSNumber?
    @NSManaged var consumptionId: String?
    @NSManaged var createdTime: NSDate?
    @NSManaged var dateCode: String?
    @NSManaged var itemId: String?
    @NSManaged var lotNo: String?
    @NSManaged var modifiedTime: String?
    @NSManaged var requiredQty: NSNumber?
    @NSManaged var consumptionItems: Consumption?
    @NSManaged var isChargeNoValid: NSNumber?
    @NSManaged var isDateValid: NSNumber?
    @NSManaged var isLotValid: NSNumber?
    @NSManaged var isConsumedQtyValid: NSNumber?
    @NSManaged var isRequiredQtyValid: NSNumber?
    @NSManaged var isItemDeleted: String?

}
