//
//  NurseSurgeryDetailsViewController.swift
//  Simplify OR swift
//
//  Created by manikanta on 09/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class NurseSurgeryDetailsViewController: UIViewController,UITableViewDelegate ,UITableViewDataSource ,flagStatusDelegate {
    
    // MARK: Constants Declaration
    let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let utility = Utility()
    let statusValue = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
    let userValue = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
    let alertViewObject = Utility()
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var listTableView: UITableView!
    @IBOutlet weak var detailsTableView: UITableView!
    
    // MARK: Var Properties Declaration
    var objectsSetForItems = [String]()
    var allDictionaryObjects = [NSDictionary]()
    var updateFlagEnabled:Bool = false
    var value: String?
    var isExpanded:Bool = false;
    var constraint : NSLayoutConstraint?
    var status: String?
    var consumptionID: String?
    var result = [Item]()
    var patientID: String?
    var doctor: String?
    var date: String?
    var time: String?
    var surgery:String?
    var itemsNotInContract = [String]()
    var flag:Bool?
    var itemsArray = [Item]()
    var contractExpDate: String?
    var isItemValid: NSNumber?
    var rejectFlagChecked = false
    var correctedFlagChecked = false

    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        
        super.viewDidLoad()
        backButton.layer.cornerRadius = 5.0
        backButton.layer.masksToBounds = true
        approveButton.layer.cornerRadius = 5.0
        approveButton.layer.masksToBounds = true
        rejectButton.layer.cornerRadius = 5.0
        rejectButton.layer.masksToBounds = true
        listTableView.tableFooterView = UIView()
        navigationController?.navigationItem.hidesBackButton = true
        
        for tabelConstraint in view.constraints as [NSLayoutConstraint]  {
            if tabelConstraint.identifier == "$ListTableConstraintIdentifier$" {
                constraint = tabelConstraint
            }
        }
        
        if userValue == Constants.kVendor {
            backButton.hidden = false
            rejectButton.hidden = true
            approveButton.hidden = true
        }
        else {
            backButton.hidden = true
            rejectButton.hidden = false
            approveButton.hidden = false
        }
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(NurseSurgeryDetailsViewController.refreshList(_:)), name:"refresh", object: nil)
    }
    
    override func viewWillAppear (animated: Bool) {
        
        super.viewWillAppear(animated)
        itemsArray = [Item]()
        if objectsSetForItems.count == 0 {
            // When View Appears for the First Time
            let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
            spinner.center = view.center
            view.addSubview(spinner)
            spinner.color = UIColor.blackColor()
            spinner.startAnimating()
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
            let obj = CommonManager()
            obj.getSingleConsumptionDetail("consumption/\(consumptionID!)", callback: {(data,error,status,connectivityFlag) in
                dispatch_async(dispatch_get_main_queue(), {
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    do{
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        }
                        else if status == 200
                        {
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let details = parseJSON["details"]
                            let JSON = details as! NSArray
                            for aSchedule in JSON {
                                let obj = aSchedule as! NSDictionary
                                let  aItem = Item()
                                
                                aItem.itemNo = obj["itemNo"] as? String
                                aItem.dateCode = obj["dateCode"] as? String
                                aItem.lotNumber = obj["lotNumber"] as? String
                                aItem.itemId = obj["id"] as? String
                                aItem.used = obj["consumedQty"] as? NSNumber
                                aItem.wasted = obj["scrappedQty"] as? NSNumber
                                aItem.itemDescription = obj["itemDescription"] as? String
                                aItem.isDateCodeValid = obj["isDateCodeValid"] as? NSNumber
                                aItem.isLotValid = obj["isLotValid"] as? NSNumber
                                aItem.isConsumedQtyValid = obj["isConsumedQtyValid"] as? NSNumber
                                aItem.isScrappedQtyValid = obj["isScrappedQtyValid"] as? NSNumber
                                aItem.isItemValid = obj["isItemValid"] as? NSNumber
                                
                                self.itemsArray.append(aItem)
                            }
                            self.result = self.itemsArray
                            self.listTableView.reloadData()
                            //Update the Buttons Status
                            self.updateButtons()
                        }
                        else
                        {
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["error"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                    }
                    catch {
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                })
            })
        }
        else {
            updateButtons()
            updateFlagEnabled = true
            listTableView.reloadData()
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source&Delegate Methods
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if tableView == detailsTableView {
            return Constants.expandedCellHeight
        }
        else {
            return Constants.standardCellHeight
        }
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == detailsTableView {
            return Constants.standardCellHeight
        }
        else {
            return 40;
        }
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if tableView == listTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("sectionHeader")! as UITableViewCell
            return cell.contentView
        }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier("expandHeader")! as! HeaderTableViewCell
            cell.surgeryDate.text = date
            cell.surgeryTime.text = time
            if surgery == nil{
                cell.surgerlyName.text = "No Value"
            }
            else{
                cell.surgerlyName.text =  surgery
            }
            if isExpanded {
                cell.toggle.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
            }
            else {
                cell.toggle.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
            }
            cell.toggle.addTarget(self, action: #selector(SurgeryDetailsViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
            return cell.contentView
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == listTableView {
            return result.count
        }
        else {
            if isExpanded {
                return 1
            }
            else {
                return 0
            }
        }
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        if tableView == listTableView {
            return true
        }
        else {
            return false
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if(updateFlagEnabled == false) {
        if tableView == listTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("SurgeyTableViewCell") as! SurgeryTableViewCell
            if result[indexPath.row].isItemValid == 0 || result[indexPath.row].isItemValid == 2 {
                var colorToBeUsed = UIColor.blackColor()
                if result[indexPath.row].isItemValid == 0 {
                    colorToBeUsed = UIColor.redColor()
                }else if result[indexPath.row].isItemValid == 1 {
                    colorToBeUsed = UIColor.blackColor()
                }else if result[indexPath.row].isItemValid == 2 {
                    colorToBeUsed = Constants.blueColor
                }
                let attributedString = NSMutableAttributedString(string:result[indexPath.row].itemNo!)
                attributedString.addAttribute(NSForegroundColorAttributeName, value: colorToBeUsed, range: NSMakeRange(0, attributedString.length))
                cell.itemName.attributedText = attributedString
                approveButton.enabled = false
                rejectButton.enabled = true
                approveButton.backgroundColor = UIColor.lightGrayColor()
                isItemValid = result[indexPath.row].isItemValid
            }
            else {
                cell.itemName.text = result[indexPath.row].itemNo
            }
           
            let usedColor = self.getUsedColor(result[indexPath.row].isConsumedQtyValid)
            let wastedColor = self.getUsedColor(result[indexPath.row].isScrappedQtyValid)
            let separatorLineColor = UIColor.blackColor()
            
            let separatorString = "|"
            let separatorAttributedString = NSMutableAttributedString(string:separatorString)
            separatorAttributedString.addAttribute(NSForegroundColorAttributeName, value: separatorLineColor, range: NSMakeRange(0, separatorAttributedString.length))

            var usedQuantity:String?
            var usedAttributedString:NSMutableAttributedString?
            if (result[indexPath.row].used)?.stringValue == nil || (result[indexPath.row].used)?.stringValue == "" {
                usedQuantity = "-"
                usedAttributedString = NSMutableAttributedString(string:usedQuantity!)
                usedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: usedColor, range: NSMakeRange(0, usedAttributedString!.length))
            }
            else {
                usedQuantity = (result[indexPath.row].used)?.stringValue
                usedAttributedString = NSMutableAttributedString(string:usedQuantity!)
                usedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: usedColor, range: NSMakeRange(0, usedAttributedString!.length))
            }

            var wastedQuantity:String?
            var wastedAttributedString:NSMutableAttributedString?
            if (result[indexPath.row].wasted)?.stringValue == nil || (result[indexPath.row].wasted)?.stringValue == "" {
                wastedQuantity = "-"
                wastedAttributedString = NSMutableAttributedString(string:wastedQuantity!)
                wastedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: wastedColor, range: NSMakeRange(0, wastedAttributedString!.length))
            }
            else {
                wastedQuantity = (result[indexPath.row].wasted)?.stringValue
                wastedAttributedString = NSMutableAttributedString(string:wastedQuantity!)
                wastedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: wastedColor, range: NSMakeRange(0, wastedAttributedString!.length))
            }

            usedAttributedString?.appendAttributedString(separatorAttributedString)
            usedAttributedString?.appendAttributedString(wastedAttributedString!)
            
            cell.quantityValue.attributedText = usedAttributedString
            // for Dcode
            if result[indexPath.row].dateCode == "" || result[indexPath.row].dateCode == nil {
                cell.dateStatus.image = UIImage(named:"tick dash")
            }
            else if result[indexPath.row].isDateCodeValid == 1 {
                cell.dateStatus.image = UIImage(named:"tick green")
                
            }
            else if result[indexPath.row].isDateCodeValid == 0 {
                cell.dateStatus.image = UIImage(named:"tick red")
            }
            else if result[indexPath.row].isDateCodeValid == 2 {
                cell.dateStatus.image = UIImage(named:"tick blue")
            }
            else {
                cell.dateStatus.image = UIImage(named:"tick green")
            }
            
            // Lot Code
            if result[indexPath.row].lotNumber == "" || result[indexPath.row].lotNumber == nil {
                cell.lotStatus.image = UIImage(named: "tick dash")
            }
            else if result[indexPath.row].isLotValid == 1 {
                cell.lotStatus.image = UIImage(named: "tick green")
            }
            else if result[indexPath.row].isLotValid == 0 {
                cell.lotStatus.image = UIImage(named: "tick red")
            }
            else if result[indexPath.row].isLotValid == 2 {
                cell.lotStatus.image = UIImage(named: "tick blue")
            }
            else {
                cell.lotStatus.image = UIImage(named: "tick green")
            }
            
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier("detailsCell") as! DetailsTableViewCell
            cell.doctor.text = doctor
            cell.patientID.text = surgery
            if (contractExpDate != nil) {
                cell.contractExp.text = contractExpDate
            }
            return cell
            }
        }
        else{
            let cell = tableView.dequeueReusableCellWithIdentifier("detailsCell") as! DetailsTableViewCell
            return cell
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        self.performSegueWithIdentifier("toItemRejectView", sender: indexPath)
    }

    // MARK: User-Defined Functions
    func getUsedColor(isValidField:NSNumber?) -> UIColor {
        if isValidField != nil {
            if isValidField == 0 {
                return UIColor.redColor()
            }
            else if isValidField == 2 {
                return Constants.blueColor
            }
            else {
                return UIColor.blackColor()
            }
        }
        else {
            return UIColor.blackColor()
        }
    }
    
    func refreshList(notification: NSNotification) {
        self.view.subviews.last?.removeFromSuperview()
        let messaged = "Consumption Rejected"
        let alertController = UIAlertController(title: "Report Sent", message:
            messaged, preferredStyle: UIAlertControllerStyle.Alert)
        // Create & Add action
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
            UIAlertAction in
            self.navigationController?.popViewControllerAnimated(true)
        }
        alertController.addAction(okAction)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    private func updateButtons() {
        if result.count == 0 || status == Constants.kApproved {
            approveButton.enabled = false
            rejectButton.enabled = false
            approveButton.backgroundColor = UIColor.lightGrayColor()
            rejectButton.backgroundColor = UIColor.lightGrayColor()
        }
        
        if statusValue == Constants.kNurse {
            if status == Constants.kApproved  || status == Constants.kRejected {
                approveButton.enabled = false
                approveButton.backgroundColor = UIColor.lightGrayColor()
                rejectButton.enabled = false
                rejectButton.backgroundColor = UIColor.lightGrayColor()
            }
            else {
                for item in result {
                    if (item.isItemValid == 0 || item.isDateCodeValid == 0 || item.isLotValid == 0 || item.isConsumedQtyValid == 0 || item.isScrappedQtyValid == 0) {
                        rejectFlagChecked = true
                        break
                        }
                    }
                // Check for Completed Flag
                for item in result {
                    if (item.isItemValid == 2 || item.isDateCodeValid == 2 || item.isLotValid == 2 || item.isConsumedQtyValid == 2 || item.isScrappedQtyValid == 2) {
                        correctedFlagChecked = true
                        break
                    }
                }
                
                if rejectFlagChecked == false && correctedFlagChecked == false {
                    correctedFlagChecked = false
                    approveButton.enabled = true
                    approveButton.backgroundColor = Constants.greenColor
                    rejectButton.enabled = false
                    rejectButton.backgroundColor = UIColor.lightGrayColor()
                }
                else if rejectFlagChecked == false && correctedFlagChecked == true {
                    correctedFlagChecked = false
                    approveButton.enabled = true
                    approveButton.backgroundColor = Constants.greenColor
                    rejectButton.enabled = true
                    rejectButton.backgroundColor = Constants.orangeColor
                }
                else if rejectFlagChecked == true && correctedFlagChecked == false {
                    rejectFlagChecked = false
                    approveButton.enabled = false
                    approveButton.backgroundColor = UIColor.lightGrayColor()
                    rejectButton.enabled = true
                    rejectButton.backgroundColor = Constants.orangeColor
                }
                else if rejectFlagChecked == true && correctedFlagChecked == true {
                    rejectFlagChecked = false
                    approveButton.enabled = false
                    approveButton.backgroundColor = UIColor.lightGrayColor()
                    rejectButton.enabled = true
                    rejectButton.backgroundColor = Constants.orangeColor
                }
            }
        }
        
    }
    
    func expandOrCollapse (sender:UIButton) {
        
        if isExpanded {
            isExpanded = false
            constraint?.constant = Constants.collapsedViewHeight
        }
        else {
            isExpanded = true
            constraint?.constant = Constants.expandViewHeight
        }
        UIView.transitionWithView(detailsTableView, duration: 0.8, options: .TransitionFlipFromTop, animations: {self.detailsTableView.reloadData()
            }, completion: nil)
    }
    
    
    @IBAction func approveButtonClicked(sender: AnyObject) {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        obj.approveConsumption(consumptionID!, callbackApprove: {(dataApprove,errorApprove,statusApprove,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
            spinner.stopAnimating();
            spinner.removeFromSuperview()
            UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusApprove == 200
                    {
                        //Create an AlertBox and return to Dashboard
                        let messaged = "\nSchedule Completed\n \n This Schedule Can be reviewed in Completed Tab"
                        let alertController = UIAlertController(title: "CONSUMPTION \n APPROVED", message:
                            messaged, preferredStyle: UIAlertControllerStyle.Alert)
                        // Create & Add action
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                            UIAlertAction in
                        self.navigationController?.popViewControllerAnimated(true)
                        }
                        alertController.addAction(okAction)
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataApprove, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataApprove, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    
    
    
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    
    @IBAction func rejectButtonClicked(sender: AnyObject) {
        
        let popOverVc = UIStoryboard(name: "Main",bundle: nil).instantiateViewControllerWithIdentifier("PopUpViewID") as! RejectPopUpViewController
        popOverVc.consumptionID = consumptionID
        self.addChildViewController(popOverVc)
        popOverVc.view.frame = self.view.frame
        self.view.addSubview(popOverVc.view)
        popOverVc.didMoveToParentViewController(self)
    }
    
    @IBAction func unwindFromSecondary(segue: UIStoryboardSegue) {
        
        self.view.subviews.last?.removeFromSuperview()
        var unWindFlag:Bool = true
        guard  let str:String = segue.sourceViewController.restorationIdentifier! else{
            unWindFlag = false
        }
        
        if(unWindFlag == true && str == "popupviewreject"){
            if flag == true{
                //Creating an alert to inform user
                let messaged = "Consumption Rejected \n \n This Schedule Can be reviewed in Consumption Tab"
                let alertController = UIAlertController(title: "Report Sent", message:
                    messaged, preferredStyle: UIAlertControllerStyle.Alert)
                // Create & Add action
                let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                    UIAlertAction in
                    self.saveRejectReportStatus()
                }
                alertController.addAction(okAction)
                self.presentViewController(alertController, animated: true, completion: nil)
            }
        }        
    }
    
    private func saveRejectReportStatus() {
        let predicate = NSPredicate(format: "consumptionId == %@", self.consumptionID!)
        let (results,_) = self.utility.fetchFromCoreData(predicate, entityName2: "Consumption", moc: self.appDelegate.managedObjectContext)
        let result = results as! [Consumption]
        for i in 0...(result.count-1){
            if result[i].consumptionId == self.consumptionID{
                result[i].statusCode = Constants.kRejected
                break
            }
        }
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    // MARK: - Navigation
    @IBAction func backButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if (segue.identifier == "toItemRejectView"){
            let indexVal = sender as? NSIndexPath
            
            let destinationVC = segue.destinationViewController as! NurseItemDetailsViewController
            destinationVC.delegate = self
            destinationVC.objectsCreatedForItems = objectsSetForItems
            destinationVC.status = status
            destinationVC.dictionaryObjectsOfCells = allDictionaryObjects
            destinationVC.consumptionID = consumptionID
            destinationVC.consumptionItem = result[(indexVal?.row)!]
            
            if isItemValid == 0{
                destinationVC.itemNtInContractFlag = true
            } else{
                destinationVC.itemNtInContractFlag = false
            }
            
        }
    }
    
    //MARK: Delegate Method 
    // from ItemdetailsReject ViewController
    func flagsInformation(flagDictionary: NSDictionary, itemsToBeChanged: [String], allDictionaryItems: [NSDictionary]) {
        
        allDictionaryObjects = allDictionaryItems
        objectsSetForItems = itemsToBeChanged
    }
    
    
}
