//
//  InventoryListTableViewCell.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/30/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class InventoryListTableViewCell: UITableViewCell {

    @IBOutlet weak var serialNumber: UILabel!
    
    @IBOutlet weak var allocatedQuantity: UILabel!
    @IBOutlet weak var requiredQuantity: UILabel!
    @IBOutlet weak var itemNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
