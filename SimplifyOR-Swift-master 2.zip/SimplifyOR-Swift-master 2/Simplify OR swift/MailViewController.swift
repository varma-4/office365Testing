//
//  MailViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 9/14/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import MessageUI

class MailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var detailsTableView: UITableView!
    
    // MARK: Var Properties Declaration
    var isExpanded:Bool = false;
    var patientID: String?
    var doctor: String?
    var date: String?
    var time: String?
    var surgery:String?
    var contractExpiryDate: String?
    let mailComposer = MFMailComposeViewController()
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        sendMail()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source&Delegate Methods
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return Constants.expandedCellHeight
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return Constants.standardCellHeight
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("expandHeader")! as! HeaderTableViewCell
        if date == nil {
           cell.surgeryDate.text = ""
        }
        else {
           cell.surgeryDate.text = date
        }
        if time == nil {
            cell.surgeryTime.text = ""
        }
        else {
            cell.surgeryTime.text = time
        }
        if surgery == nil {
           cell.surgerlyName.text =  ""
        }
        else{
            cell.surgerlyName.text =  surgery!
        }
        
        
        if isExpanded {
            cell.toggle.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
        }
        else {
            cell.toggle.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
        }
        cell.toggle.addTarget(self, action: #selector(MailViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
        return cell.contentView
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isExpanded {
            return 1
        }
        else {
            return 0
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("detailsCell") as! DetailsTableViewCell
        if doctor == nil {
            doctor = ""
        }
        if surgery == nil {
            surgery = ""
        }
        cell.doctor.text = doctor
        cell.patientID.text = surgery
        if contractExpiryDate != nil {
            cell.contractExpDate?.text = contractExpiryDate
        }

        return cell
    }
    
    // MARK: User-Defined Functions
    @objc private func expandOrCollapse (sender:UIButton) {
        
        var frame = CGRectMake(0, 110, view.frame.size.width, 500)
        
        if isExpanded {
            isExpanded = false
            frame.origin.y = 110
        }
        else {
            isExpanded = true
            frame.origin.y = 170
        }
        
        if MFMailComposeViewController.canSendMail() {
        mailComposer.view.frame = frame
        }
        UIView.transitionWithView(detailsTableView, duration: 0.8, options: .TransitionFlipFromTop, animations: {self.detailsTableView.reloadData()
            }, completion: nil)
    }
    
    
    
    @IBAction func homeButtonPressed(sender: UIButton) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backButtonPressed(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    private func sendMail() {
        
        if MFMailComposeViewController.canSendMail() {
            var hospitalName:String?
            if date == nil {
                date = " "
            }
            if doctor == nil {
                doctor = " "
            }
            if time == nil {
                time = " "
            }
            if surgery == nil {
                surgery = " "
            }
            if NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital) == nil {
                hospitalName = " "
            }
            else {
                hospitalName = (NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital) as! String)
            }
            let messageBody = "-----Please do not delete the below header information……….. \n" + "Schedule Date: " + date! + "\n Hospital Name: " + hospitalName! + "\n Doctor: " + doctor!
            let message = messageBody + "\n--------End of Header information ------------------------------------"
            let emailTitle = (NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital) as! String) + "-\(surgery!)-\(date!)-\(time!)"
            mailComposer.mailComposeDelegate = self;
            mailComposer.setSubject(emailTitle)
            mailComposer.setMessageBody(message, isHTML: true)
            self.addChildViewController(mailComposer)
            mailComposer.navigationBar.barTintColor = Constants.orangeColor
            mailComposer.navigationBar.tintColor = UIColor.darkGrayColor()
            mailComposer.view.frame = CGRectMake(0, 110, view.frame.size.width, 500)
            view.addSubview(mailComposer.view)
        }
        
    }
    
    // MARK: - MailComposerDelegate Methods
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        switch (result.rawValue)
        {
        case MFMailComposeResult.Cancelled.rawValue:
            self.navigationController?.popViewControllerAnimated(true)
            break;
        case MFMailComposeResult.Saved.rawValue:
            self.navigationController?.popViewControllerAnimated(true)
            break;
        case MFMailComposeResult.Sent.rawValue:
            let alertController = UIAlertController(title: "EMAIL SENT TO DISTRIBUTOR", message:
                "\n This schedule can be reviewed in \"Consumption\" tab", preferredStyle: UIAlertControllerStyle.Alert)
            // Create & Add  actions
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                UIAlertAction in
                self.navigationController?.popViewControllerAnimated(true)
            }
            alertController.addAction(okAction)
            self.presentViewController(alertController, animated: true, completion: nil)
            break;
        case MFMailComposeResult.Failed.rawValue:
            self.navigationController?.popViewControllerAnimated(true)
            break;
        default:
            self.navigationController?.popViewControllerAnimated(true)
            break;
        }
    }
}

