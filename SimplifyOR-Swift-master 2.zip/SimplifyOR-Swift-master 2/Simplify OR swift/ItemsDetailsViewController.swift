//
//  ItemsDetailsViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/29/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class ItemsDetailsViewController: UIViewController {
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var contractPrice: UILabel!
    @IBOutlet weak var wastedValue: UILabel!
    @IBOutlet weak var usedValue: UILabel!
    @IBOutlet weak var dateCode: UILabel!
    @IBOutlet weak var lotNumber: UILabel!
    @IBOutlet weak var itemDescription: UILabel!
    @IBOutlet weak var itemNumber: UILabel!
    
    // MARK: Var Properties Declaration
    var consumptionItem : ConsumptionItem?
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        
        super.viewDidLoad()
        backButton.layer.cornerRadius = 5.0
        backButton.layer.masksToBounds = true
        
        itemNumber.text = consumptionItem?.itemId
        if consumptionItem?.lotNo?.characters.count > 0 {
            lotNumber.text = consumptionItem?.lotNo
        } else {
            lotNumber.text = "NA"
        }
        
        if consumptionItem?.dateCode?.characters.count > 0 {
            dateCode.text = consumptionItem?.dateCode
        } else {
            lotNumber.text = "NA"
        }
        wastedValue.text = consumptionItem?.requiredQty?.stringValue
        usedValue.text = consumptionItem?.consumedQty?.stringValue
        navigationController?.navigationItem.hidesBackButton = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Navigation
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func backButtonPressed(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
}
