//
//  LoginViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 7/20/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {
    
    // MARK: Constants Declaration
    let alertViewObject = Utility()
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        username.delegate = self
        password.delegate = self
        username.autocorrectionType = UITextAutocorrectionType.No
        loginButton.layer.cornerRadius = 5.0
        loginButton.layer.masksToBounds = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: User-Defined Functions
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        view.endEditing(true)
        return true
    }
    
    @IBAction func login(sender: AnyObject) {
        
        view.endEditing(true)
        // Validate the text fields
        if username.text!.characters.count == 0 && password.text!.characters.count == 0{
            self.alertViewObject.showAlertView("Invalid", alertMessage: "Please enter username and password", delegate: self)
        } else if username.text!.characters.count == 0 {
            self.alertViewObject.showAlertView("Invalid", alertMessage: "Please enter username", delegate: self)
        } else if password.text!.characters.count == 0 {
            self.alertViewObject.showAlertView("Invalid", alertMessage: "Please enter password", delegate: self)
        } else {
            let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
            spinner.center = view.center
            view.addSubview(spinner)
            spinner.startAnimating()
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                let obj = CommonManager()
                obj.login(username.text!, password: password.text!, callback: {(data,error,status,connectivityFlag) in
                    dispatch_async(dispatch_get_main_queue(), {
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                        do {
                            if connectivityFlag == false {
                                self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                            }
                            else if status == 200
                            {
                                let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                let parseJSON = json
                                let user = parseJSON["user"]
                                let role = user!!["role"]
                                let loggedInOrgName = parseJSON["loggedInOrgName"]
                                let loggedInOrgId = parseJSON["loggedInOrgId"]
                                let userId = parseJSON["userId"]
                                let employee = user!!["employee"]
                                let orgId = employee!!["orgId"]
                                let idSession = parseJSON["id"]

                                NSUserDefaults.standardUserDefaults().setObject(role, forKey: Constants.kUser)
                                NSUserDefaults.standardUserDefaults().synchronize()
                                NSUserDefaults.standardUserDefaults().setObject(loggedInOrgName, forKey: Constants.KDHospital)
                                NSUserDefaults.standardUserDefaults().setObject(userId, forKey: Constants.KUserId)
                                NSUserDefaults.standardUserDefaults().setObject(loggedInOrgId, forKey: Constants.KLoggedInOrgId)
                                NSUserDefaults.standardUserDefaults().setObject(orgId, forKey: Constants.KOrgId)
                                NSUserDefaults.standardUserDefaults().setObject(idSession, forKey: "id")
                                NSUserDefaults.standardUserDefaults().synchronize()
                                
                                let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("Home") as! UINavigationController
                                self.presentViewController(viewController, animated: true, completion: nil)
                            }
                            else {
                                let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                let parseJSON = json
                                let  error = parseJSON["error"]
                                self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                            }
                        }
                        catch {
                            let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                        }
                    })
                })
            }
        }
}
