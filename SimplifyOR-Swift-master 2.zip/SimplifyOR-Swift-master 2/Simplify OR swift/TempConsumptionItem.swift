//
//  TempConsumptionItem.swift
//  Simplify OR swift
//
//  Created by Sharanya Puppala on 06/12/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class TempConsumptionItem: AnyObject {
     var chargeNo: String?
     var consumedQty: NSNumber?
     var consumptionId: String?
     var createdTime: NSDate?
     var dateCode: String?
     var itemId: String?
     var lotNo: String?
     var modifiedTime: String?
     var requiredQty: NSNumber?
     var consumptionItems: Consumption?
     var isChargeNoValid: NSNumber?
     var isDateValid: NSNumber?
     var isLotValid: NSNumber?
     var isConsumedQtyValid: NSNumber?
     var isRequiredQtyValid: NSNumber?
}
