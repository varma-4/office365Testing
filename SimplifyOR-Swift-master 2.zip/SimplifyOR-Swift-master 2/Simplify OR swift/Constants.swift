//
//  Constants.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/22/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class Constants {
    
    // MARK: Constants Declaration
    static let IPHONE_5:CGFloat = 568.0
    static let IPHONE_6:CGFloat = 667.0
    static let IPHONE_6P:CGFloat = 736.0
    static let collapsedViewHeight:CGFloat = 51.0
    static let expandedCellHeight:CGFloat = 60.0
    static let expandViewHeight:CGFloat = 110.0
    static let standardCellHeight:CGFloat = 44.0
    static let size : CGSize = UIScreen.mainScreen().bounds.size
    static let iphone4Frame = CGRectMake(size.width - 113, size.height - 227 , 25, 25)
    static let iphone5Frame = CGRectMake(size.width - 113, size.height - 275 , 25, 25)
    static let iPhone6Frame = CGRectMake(size.width - 140, size.height - 325 , 25, 25)
    static let iPhone6PlusFrame = CGRectMake(size.width - 158, size.height - 355 , 25, 25)
    static let dateFormat = "MMM dd yyyy"
    static let timeFormat = "hh:mm a"
    static let kRejected = "REJECTED"
    static let kApproved = "APPROVED"
    static let kInventoryConfirmed = "Inventory Confirmed"
    static let KPending = "REVIEW_PENDING"
    static let kUser = "user"
    static let kVendor = "VENDOR"
    static let kNurse = "HOSPITAL"
    static let KDHospital = "hospital"
    static let KUserId = "userId"
    static let KLoggedInOrgId = "loggedInOrgId"
    static let KOrgId = "orgId"
    static let greenColor = UIColor(red: 22.0/255, green: 194.0/255, blue: 159.0/255, alpha: 1.0)
    static let orangeColor = UIColor(red: 245.0/255, green: 150.0/255, blue: 6.0/255, alpha: 1.0)
    static let blueColor = UIColor(red: 10.0/255, green: 91.0/255, blue: 254.0/255, alpha: 1.0)
    static let errorTitle = "error"
    static let noInternetMessage = "No internet connectivity"
    static let kCookie = "APP_COOKIES_STORE"

}
