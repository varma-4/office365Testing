//
//  RejectPopUpViewController.swift
//  Simplify OR swift
//
//  Created by manikanta on 09/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class RejectPopUpViewController: UIViewController {
    
    // MARK: Constants Declaration
    let alertViewObject = Utility()

    // MARK: IBOutlets Declaration
    @IBOutlet weak var othersButton: CustomCheckBoxButton!
    @IBOutlet weak var missingDataButton: CustomCheckBoxButton!
    @IBOutlet weak var itemsNotInContractButton: CustomCheckBoxButton!
    @IBOutlet weak var PopupviewAddes: UIView!
    @IBOutlet weak var remarkTextView: UITextView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var sendReport: UIButton!
    
    // MARK: Var Properties Declaration
    var consumptionID:String?
    private var sendButtonClicked:Bool!
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Calling the POPUPView Animation Function
        self.showAnimate()
        sendButtonClicked = false
        buttonDesingForTheView()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(RejectPopUpViewController
            .keyboardWillShow(_:)), name:UIKeyboardWillShowNotification, object: nil);
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(RejectPopUpViewController.keyboardWillHide(_:)), name:UIKeyboardWillHideNotification, object: nil);
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(RejectPopUpViewController.hideKeyboard))
        tapGesture.cancelsTouchesInView = true
        view.addGestureRecognizer(tapGesture)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: User-Defined Functions
    func hideKeyboard() {
        remarkTextView.endEditing(true)
    }
    
    func keyboardWillShow(notification: NSNotification) {
        if remarkTextView.editable{
            self.view.window?.frame.origin.y = -1 * (getKeyboardheight(notification) - 80)
        }
    }
    
    func keyboardWillHide(notification: NSNotification) {
        if self.view.window?.frame.origin.y != 0 {
            self.view.window?.frame.origin.y += 1 * (getKeyboardheight(notification) - 80)
        }
    }

    func getKeyboardheight(notification : NSNotification) -> CGFloat {
        let userInfo:NSDictionary = notification.userInfo!
        let keyboardFrame:NSValue = userInfo.valueForKey(UIKeyboardFrameEndUserInfoKey) as! NSValue
        let keyboardRectangle = keyboardFrame.CGRectValue()
        let keyboardHeight = keyboardRectangle.height
        return keyboardHeight
    }
    
    private func showAnimate() {
        weak var weakSelf = self
        weakSelf!.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        weakSelf!.view.alpha = 0.0
        UIView.animateWithDuration(0.25, animations: {
            weakSelf!.view.alpha = 1.0
            weakSelf!.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        })
    }
    
    private func removeAnimate() {
        UIView.animateWithDuration(0.25, animations: {
            self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
            self.view.alpha = 0.0
            }, completion: {(finished:Bool) in
                if(finished){
                    self.view.removeFromSuperview()
                }
        })
    }
 
    //Adding Shadow to the PopView and Textview with Border color and Width
    private func buttonDesingForTheView() {
        
        self.view.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        remarkTextView.layer.borderWidth = 0.4
        remarkTextView.layer.borderColor = UIColor.darkGrayColor().CGColor
        remarkTextView.clipsToBounds = true
        
        PopupviewAddes.layer.borderWidth = 0.3
        PopupviewAddes.layer.borderColor = UIColor.grayColor().CGColor
        PopupviewAddes.clipsToBounds = true
        
        backButton.layer.borderWidth = 0.4
        backButton.layer.borderColor = UIColor.darkGrayColor().CGColor
        
        sendReport.layer.borderWidth = 0.4
        sendReport.layer.borderColor = UIColor.darkGrayColor().CGColor
        
    }
    
    @IBAction func closePopUp(sender: AnyObject) {
        self.removeAnimate()
    }

    @IBAction func SendReportButtonAction(sender: AnyObject) {
        //Save Individual Buttons Clicked Status and TextView Report Data to API
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        obj.rejectConsumption(consumptionID!, reason1: (itemsNotInContractButton.isChecked ? 0 : 1), reason2: (missingDataButton.isChecked ? 0 : 1), otherReason: (othersButton.isChecked ? 0 : 1), callbackReject: {(dataReject,errorReject,statusReject,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
            spinner.stopAnimating();
            spinner.removeFromSuperview()
            UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do {
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusReject == 200
                    {
                        NSNotificationCenter.defaultCenter().postNotificationName("refresh", object: nil)
                    }
                    else
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataReject, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch {
                    let jsonStr = NSString(data: dataReject, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    
    
    // MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // write the code for setting the flag button in the previous view controller
        let vc = segue.destinationViewController as? NurseSurgeryDetailsViewController
        if(sendButtonClicked == true){
            vc?.flag = true
        } else {
            vc?.flag = false
        }
    }
}
