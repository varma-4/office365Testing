//
//  ItemsAdditionViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/16/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import AVFoundation
import CoreData

var didTapSaveButton = false
var didTapUpdateButton = false


class ItemsAdditionViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var itemScan: UIButton!
    @IBOutlet weak var dateScan: UIButton!
    @IBOutlet weak var lotScan: UIButton!
    @IBOutlet weak var wastedSwitchLabel: UILabel!
    @IBOutlet weak var usedSwitchLabel: UILabel!
    @IBOutlet weak var quantityOne: UILabel!
    @IBOutlet weak var wastedSwitch: UISwitch!
    @IBOutlet weak var usedSwitch: UISwitch!
    @IBOutlet weak var wastedValue: UITextField!
    @IBOutlet weak var wastedNumber: UILabel!
    @IBOutlet weak var usedValue: UITextField!
    @IBOutlet weak var usedNumber: UILabel!
    @IBOutlet weak var quantityLabel: UILabel!
    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var reset: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var dateCode: UITextField!
    @IBOutlet weak var lotNumber: UITextField!
    @IBOutlet weak var itemNumber: UITextField!
    
    var captureSession : AVCaptureSession!
    var videoPreviewLayer : AVCaptureVideoPreviewLayer!
    var input:AVCaptureDeviceInput?
    var barCodeFrameView:UIView?
    var tag:Int?
    var consumptionID: String?
    var record:AnyObject?
    var cQty:String?
    var sQty:String?
    var itemId:String?
    var operationQueue: NSOperationQueue?
    var networkReachability: Reachability?
    let tempRecord = Item()
    var connectionState = "Connected"
    let connectedState = "Connected"
    let notConnectedState = "notConnected"
    var newResult = [AnyObject]()
    var newResult1 = [AnyObject]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        updateButton.layer.cornerRadius = 5.0
        updateButton.layer.masksToBounds = true
        reset.layer.cornerRadius = 5.0
        reset.layer.masksToBounds = true
        save.layer.cornerRadius = 5.0
        save.layer.masksToBounds = true
        
        navigationController?.navigationItem.hidesBackButton = true
        
        if ((record) != nil) {
            
                let aRecord = record as! ConsumptionItem
                
                updateView(true)
                itemId = record?.itemId
                lotNumber.text = aRecord.lotNo
                itemNumber.text = aRecord.chargeNo
                dateCode.text = aRecord.dateCode
                usedValue.text = aRecord.consumedQty?.stringValue
                wastedValue.text = aRecord.requiredQty?.stringValue
                save.setTitle("Update", forState: .Normal)

        }
        

        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.networkChange(_:)), name:ReachabilityChangedNotification, object: networkReachability)
          do {
            networkReachability = try Reachability.reachabilityForInternetConnection()

            try networkReachability?.startNotifier()
        }
          catch {
            //print("Network rechability try failed")
        }
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func scanBarcode(sender:UIButton) {
        let cameraMediaType = AVMediaTypeVideo
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatusForMediaType(cameraMediaType)
        
        switch cameraAuthorizationStatus {
        case .Denied:
            self.showAlert("Camera access denied", alertMessage: "Please provide access to camera to scan bar code")
            break
        case .Authorized:
            popCamera()
            break
        case .Restricted:
            self.showAlert("Camera access denied", alertMessage: "Please provide access to camera to scan bar code")
            break
        case .NotDetermined:
            // Prompting user for the permission to use the camera.
            AVCaptureDevice.requestAccessForMediaType(cameraMediaType) { granted in
                if granted {
                    self.popCamera()
                    
                } else {
                    self.showAlert("Camera access denied", alertMessage: "Please provide access to camera to scan bar code")
                }
            }
        }
    }
    
    func showAlert(alertTitle:String, alertMessage:String ) {
        
        let alertController = UIAlertController(title:alertTitle, message:
            alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        // Create the actions
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default)  { (result : UIAlertAction) -> Void in
        }
        // Add the actions
        alertController.addAction(okAction)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    func popCamera() {
        let captureDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        
        do {
            input = try AVCaptureDeviceInput(device: captureDevice) as AVCaptureDeviceInput
        } catch _ as NSError {
        }
        
        captureSession = AVCaptureSession()
        captureSession.addInput(input! as AVCaptureInput)
        
        let captureMetadataOutput = AVCaptureMetadataOutput()
        self.captureSession?.addOutput(captureMetadataOutput)
        
        captureMetadataOutput.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
        captureMetadataOutput.metadataObjectTypes = captureMetadataOutput.availableMetadataObjectTypes
        
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session:captureSession)
        videoPreviewLayer?.frame = view.layer.bounds
        videoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        view.layer.addSublayer(videoPreviewLayer)
        
        // Initialize bar Code Frame to highlight the bar code
        barCodeFrameView = UIView()
        barCodeFrameView?.layer.borderColor = UIColor.greenColor().CGColor
        barCodeFrameView?.layer.borderWidth = 2
        view.addSubview(barCodeFrameView!)
        view.bringSubviewToFront(barCodeFrameView!)
        
        captureSession.startRunning();

    }
    
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!) {
        
        if let barcodeDate = metadataObjects.first {
            
            let barCodeObject = videoPreviewLayer?.transformedMetadataObjectForMetadataObject(barcodeDate as! AVMetadataMachineReadableCodeObject) as! AVMetadataMachineReadableCodeObject
            barCodeFrameView?.frame = barCodeObject.bounds;
            let barcodeReadable = barcodeDate as? AVMetadataMachineReadableCodeObject
            
            if let readableCode = barcodeReadable {
                barcodeDetected(readableCode.stringValue)
            }
            captureSession.stopRunning()
        }
    }
    
    func barcodeDetected(code: String) {
        if tag == 11 {
            itemNumber.text = code
        }
        else if tag == 12 {
            lotNumber.text = code
        }
        else if tag == 13 {
            dateCode.text = code
        }
        
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC)))
        dispatch_after(time, dispatch_get_main_queue(), { [weak self] in
            self?.barCodeFrameView?.removeFromSuperview()
            self?.videoPreviewLayer.removeFromSuperlayer()
            })
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        updateView(true)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func resetFields(sender: AnyObject) {
        view.endEditing(true)
        lotNumber.text = ""
        itemNumber.text = ""
        dateCode.text = ""
        usedValue.text = ""
        wastedValue.text = ""
        updateView(false)
    }
    
    @IBAction func saveDetails(sender: AnyObject) {
        didTapSaveButton = true
        let utility = Utility()
        gconnectionState = "Connected"
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        // Create Entity
        let entity = NSEntityDescription.entityForName("ConsumptionItem", inManagedObjectContext: appDelegate.managedObjectContext)
        
        if (record != nil){
            let aRecord = record as! ConsumptionItem
                
            aRecord.itemId = itemId
            aRecord.chargeNo = itemNumber.text
            aRecord.lotNo = lotNumber.text
            aRecord.dateCode = dateCode.text
            cQty = usedValue.text!
            aRecord.consumedQty = Int(usedValue.text!)
            sQty = wastedValue.text!
            aRecord.requiredQty = Int(wastedValue.text!)

            //Temp Record
            tempRecord.itemId = itemId
            tempRecord.itemNo = itemNumber.text
            tempRecord.lotNumber = lotNumber.text
            tempRecord.dateCode = dateCode.text
            tempRecord.used = Int(usedValue.text!)
            tempRecord.wasted = Int(wastedValue.text!)

        }
        else {
            //Temp Record
            
            tempRecord.itemId = itemId
            tempRecord.itemNo = itemNumber.text
            tempRecord.lotNumber = lotNumber.text
            tempRecord.dateCode = dateCode.text
            tempRecord.used = Int(usedValue.text!)
            tempRecord.wasted = Int(wastedValue.text!)
            
            // Initialize Record
            let consumptionItem = ConsumptionItem(entity: entity!, insertIntoManagedObjectContext: appDelegate.managedObjectContext)
            //record 1
            consumptionItem.consumptionId = consumptionID
            consumptionItem.itemId = itemId
            consumptionItem.lotNo = lotNumber.text
            consumptionItem.dateCode = dateCode.text
            consumptionItem.chargeNo = itemNumber.text

            if usedValue.text?.characters.count > 0 {
                consumptionItem.consumedQty = Int(usedValue.text!)
                cQty = consumptionItem.consumedQty?.stringValue
            }
            else {
                if usedSwitch.on == true  {
                    consumptionItem.consumedQty = 1
                    cQty = consumptionItem.consumedQty?.stringValue
                }
                else {
                    consumptionItem.consumedQty = 0
                    cQty = consumptionItem.consumedQty?.stringValue
                    
                }
            }
            if wastedValue.text?.characters.count > 0 {
                consumptionItem.requiredQty = Int(wastedValue.text!)
                sQty = consumptionItem.requiredQty?.stringValue
            }
            else {
                if wastedSwitch.on == true  {
                    consumptionItem.requiredQty = 1
                    sQty = consumptionItem.requiredQty?.stringValue
                }
                else {
                    consumptionItem.requiredQty = 0
                    sQty = consumptionItem.requiredQty?.stringValue
                }
            }
            
            self.insertConsumption()
            
        }
        let isSaved = utility.addOrUpdateCoreData(appDelegate.managedObjectContext)
        if isSaved {
            if save.titleLabel?.text == "Update" {
                didTapUpdateButton = true

                if itemId != nil{
                let predicate2 = NSPredicate(format: "itemId == %@", itemId!)
                let (_,_) = utility.updateCoreData(predicate2, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext, itemId: itemId!, itemNumber:itemNumber.text!, lotNumber: lotNumber.text!, dateCode: dateCode.text!, used: Int(usedValue.text!)!, wasted: Int(wastedValue.text!)!)
                }
                
                let connectivityStatus = utility.hasConnectivity()
                if connectivityStatus {
                    self.updateConsumption()
                }
                else {
                    self.navigationController?.popViewControllerAnimated(true)
                }
            }
            else {
                resetFields(reset)
            }
        }
    }
    
    func networkChange(notification: NSNotification) {
        
        if let reachability = notification.object as? Reachability {
            let remoteHostStatus: Int = (reachability.currentReachabilityStatus.hashValue)
                
                if  remoteHostStatus != 0 && connectionState == connectedState {
                    
                    connectionState = notConnectedState
                    if didTapSaveButton == true && didTapUpdateButton == false {
                        insertConsumption()
                    }
                    else if didTapSaveButton == true && didTapUpdateButton == true {
                        updateConsumption()
                    }
                } else if remoteHostStatus == 0  && connectionState == notConnectedState {
                    
                    connectionState = connectedState
                    
                    let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
                    alert.show()
            }
        }
    }
    
    @IBAction func updateCompleted(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func scanData(sender: UIButton) {
        updateView(false)
        tag = sender.tag
        scanBarcode(sender)
    }
    
    func updateView(isHidden:Bool) {
        weak var weakSelf = self
        UIView.animateWithDuration(0.5, delay: 1.0, options: .TransitionCrossDissolve, animations: { () -> Void in
            weakSelf?.usedNumber.hidden = !isHidden
            weakSelf?.usedValue.hidden = !isHidden
            weakSelf?.wastedValue.hidden = !isHidden
            weakSelf?.wastedNumber.hidden = !isHidden
            weakSelf?.usedSwitch.hidden = isHidden
            weakSelf?.wastedSwitch.hidden = isHidden
            weakSelf?.wastedSwitchLabel.hidden = isHidden
            weakSelf?.usedSwitchLabel.hidden = isHidden
            weakSelf?.quantityOne.hidden = isHidden
            weakSelf?.quantityLabel.hidden = isHidden
            weakSelf?.itemScan.enabled = !isHidden
            weakSelf?.lotScan.enabled = !isHidden
            weakSelf?.dateScan.enabled = !isHidden
            
            if isHidden {
                weakSelf?.itemScan.setImage(UIImage(named: "barcode disabled"), forState: .Normal)
                weakSelf?.lotScan.setImage(UIImage(named: "barcode disabled"), forState: .Normal)
                weakSelf?.dateScan.setImage(UIImage(named: "barcode disabled"), forState: .Normal)
            } else {
                weakSelf?.itemScan.setImage(UIImage(named: "barcode enabled"), forState: .Normal)
                weakSelf?.lotScan.setImage(UIImage(named: "barcode enabled"), forState: .Normal)
                weakSelf?.dateScan.setImage(UIImage(named: "barcode enabled"), forState: .Normal)
            }
            
            }, completion: nil)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }
    
    @IBAction func usedSwicthChanged(sender: UISwitch) {
        wastedSwitch.on = !sender.on
    }
    
    @IBAction func wastedSwicthChanged(sender: UISwitch) {
        usedSwitch.on = !sender.on
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func insertConsumption() {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()

        let obj = CommonManager()
        if tempRecord.itemNo != nil && tempRecord.lotNumber != nil && tempRecord.dateCode != nil && cQty != nil && sQty != nil{
            
        obj.addLineItem(self.consumptionID!, itemNo: tempRecord.itemNo!, lotNumber: tempRecord.lotNumber!, dateCode: tempRecord.dateCode!, consumedQty: self.cQty!, scrappedQty: self.sQty!, callbackAdd: {(data,error,status) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    do {
                         if status == 200
                         {
                            didTapSaveButton = false

                         }
                         else
                         {
                            didTapSaveButton = false
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                        
                            let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                            alert.show()

                         }
                     }
                     catch {
                      let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                      let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                      alert.show()
                    }
                })
            })
        }
    }
    
    func updateConsumption() {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        if tempRecord.itemNo != nil && tempRecord.lotNumber != nil && tempRecord.dateCode != nil && cQty != nil && sQty != nil {

        obj.updateLineItem(consumptionID!, itemNo: tempRecord.itemNo!, lotNumber: tempRecord.lotNumber!, dateCode: tempRecord.dateCode!, consumedQty: cQty!, scrappedQty: sQty!,itemId:itemId! , callbackUpdate: {(data,error,status) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    do {
                            if status == 200
                            {
                                didTapUpdateButton = false
                                self.navigationController?.popViewControllerAnimated(true)
                            }
                            else
                            {
                                didTapUpdateButton = false
                                let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                let parseJSON = json
                                let  error = parseJSON["message"]
                                let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                                alert.show()
                            }
                        }
                    catch {
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                        }
                    })
                })
            }
        }
    }
