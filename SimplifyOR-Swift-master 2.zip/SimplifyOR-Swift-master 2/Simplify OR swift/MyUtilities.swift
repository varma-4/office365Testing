//
//  MyUtilities.swift
//  SimplifyORCoreData
//
//  Created by Arunava Sanyal on 17/08/16.
//  Copyright © 2016 Arunava Sanyal. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class Utility:NSObject {
    
    // MARK: User-Defined Functions
    func addOrUpdateCoreData(managedContext:NSManagedObjectContext) -> Bool {
        
        var isSaved = true
        do {
            try managedContext.save()
        }
        catch {
            isSaved = false
        }
        
        return isSaved
        
    }
    
    func fetchFromCoreData(predicate:NSPredicate?,entityName2:String,moc:NSManagedObjectContext) -> (results:[NSManagedObject],staus:Bool) {
        
        let fetchRequest = NSFetchRequest(entityName: entityName2)
        fetchRequest.predicate = predicate
        fetchRequest.returnsObjectsAsFaults = false
        var results = [NSManagedObject]()
        var status = true
        
        do {
            results = try moc.executeFetchRequest(fetchRequest) as! [NSManagedObject]
        }
        catch {
            status = false
        }
        
        return (results,status)
        
    }
    
    func updateCoreData(predicate:NSPredicate?,entityName2:String,moc:NSManagedObjectContext,itemId:String,itemNumber:String,lotNumber:String,dateCode:String,used:Int,wasted:Int,isItemValid:NSNumber, isConsumedQtyValid:NSNumber, isDateCodeValid:NSNumber, isScrappedQtyValid:NSNumber, isLotValid:NSNumber) -> (results:[NSManagedObject],staus:Bool) {
        
        let fetchRequest = NSFetchRequest(entityName: entityName2)
        fetchRequest.predicate = predicate
        fetchRequest.returnsObjectsAsFaults = false
        var results = [NSManagedObject]()
        var status = true
        do{
            results = try moc.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            let managedObject = results[0]
            managedObject.setValue(itemId, forKey: "itemId");
            managedObject.setValue(itemNumber, forKey: "chargeNo");
            managedObject.setValue(lotNumber, forKey: "lotNo");
            managedObject.setValue(dateCode, forKey: "dateCode");
            managedObject.setValue(used, forKey: "consumedQty");
            managedObject.setValue(wasted, forKey: "requiredQty");
            managedObject.setValue("true", forKey: "modifiedTime");
            managedObject.setValue(isItemValid, forKey: "isChargeNoValid");
            managedObject.setValue(isConsumedQtyValid, forKey: "isConsumedQtyValid");
            managedObject.setValue(isDateCodeValid, forKey: "isDateValid");
            managedObject.setValue(isScrappedQtyValid, forKey: "isRequiredQtyValid");
            managedObject.setValue(isLotValid, forKey: "isLotValid");

            do {
                try moc.save()
            }
            catch {
            }
        }
        catch {
            status = false
        }
        
        return (results,status)
        
    }
    
    func updateCoreDataWithDeleteStatus(predicate:NSPredicate?,entityName2:String,moc:NSManagedObjectContext) -> (results:[NSManagedObject],staus:Bool) {
        
        let fetchRequest = NSFetchRequest(entityName: entityName2)
        fetchRequest.predicate = predicate
        fetchRequest.returnsObjectsAsFaults = false
        var results = [NSManagedObject]()
        var status = true
        do{
            results = try moc.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            let managedObject = results[0]
            managedObject.setValue("true", forKey: "isItemDeleted");
            do {
                try moc.save()
            }
            catch {
            }
        }
        catch {
            status = false
        }
        return (results,status)
        
    }

    func deleteFromCoreData(managedObject:NSManagedObjectContext, Object:NSManagedObject) -> Bool {
        
        var isDeleted = true
        managedObject.deleteObject(Object)
        do {
            try managedObject.save()
        }
        catch let error as NSError {
            isDeleted = false
            print(error.userInfo)
        }
        
        return isDeleted
    }
    
    func hasConnectivity() -> Bool {
        
        do {
            let reachability: Reachability = try Reachability.reachabilityForInternetConnection()
            let networkStatus: Int = reachability.currentReachabilityStatus.hashValue
            
            return (networkStatus != 0)
        }
        catch {
            // Handle error
            return false
        }
        
    }
    
    func getTime(isoDate:String) -> String {
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        let changedFormat = dateFormatter.dateFromString(isoDate)
        
        let styleDateFormatter = NSDateFormatter()
        styleDateFormatter.timeStyle = .ShortStyle
        styleDateFormatter.dateStyle = .NoStyle
        let changedStyleFormat = styleDateFormatter.stringFromDate(changedFormat!)
        
        return changedStyleFormat
        
    }
    
    func getDate(isoDate:String) -> String {
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        let changedFormat = dateFormatter.dateFromString(isoDate)
        
        let styleDateFormatter = NSDateFormatter()
        styleDateFormatter.timeStyle = .NoStyle
        styleDateFormatter.dateStyle = .MediumStyle
        let changedStyleFormat = styleDateFormatter.stringFromDate(changedFormat!)
        
        return changedStyleFormat
        
    }
    
    func getDateTime() -> String {
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        let finalDate = dateFormatter.stringFromDate(NSDate())
        
        return finalDate
        
    }
    
    func showAlertView(alertTitle:String, alertMessage:String ,delegate:AnyObject?) {
       
        let alertController = UIAlertController(title: alertTitle, message:
            alertMessage, preferredStyle: UIAlertControllerStyle.Alert)
        // Create & Add  actions
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
            UIAlertAction in
        }
        alertController.addAction(okAction)
        
        if delegate != nil {
            delegate!.presentViewController(alertController, animated: true, completion: nil)
        }
    }
    
}
