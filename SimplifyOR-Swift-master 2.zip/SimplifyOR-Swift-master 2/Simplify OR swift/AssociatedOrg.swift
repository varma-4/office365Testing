//
//  AssociatedOrg.swift
//  Simplify OR swift
//
//  Created by Sharanya Puppala on 26/10/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class AssociatedOrg: NSObject {
    var name: String?
    var orgId: String?
}
