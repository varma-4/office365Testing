//
//  SplashViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/19/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class SplashViewController: UIViewController {
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var redCross: UIImageView!
    
    // MARK: View Life Cycle Methods
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        let device = UIScreen.mainScreen().bounds.size.height
        
        if device == Constants.IPHONE_6 {
            redCross.frame = Constants.iPhone6Frame
        } else if device == Constants.IPHONE_6P {
            redCross.frame = Constants.iPhone6PlusFrame
        } else if device == Constants.IPHONE_5 {
            redCross.frame = Constants.iphone5Frame
        }
        else {
           redCross.frame = Constants.iphone4Frame
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        spinWithOptions()
        let time = dispatch_time(DISPATCH_TIME_NOW, Int64(2 * Double(NSEC_PER_SEC)))
        dispatch_after(time, dispatch_get_main_queue(), { [weak self] in
            self?.presentController()
            })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: User-Defined Functions
    private func spinWithOptions() {
        
        weak var weakSelf = self
        UIView.animateWithDuration(0.3, delay: 0.0, options: .CurveLinear, animations: { () -> Void in
            let val : CGFloat = CGFloat((M_PI / Double(2.0)));
            weakSelf?.redCross.transform = CGAffineTransformRotate((weakSelf?.redCross.transform)!, val)
        }) { (finished: Bool) -> Void in
            weakSelf?.spinWithOptions()
        }
    }
    
    private func presentController() {
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let home = storyboard.instantiateViewControllerWithIdentifier("loginVC")
        let appDelegate  = UIApplication.sharedApplication().delegate as! AppDelegate
        appDelegate.window?.rootViewController = home
    }
    
}
