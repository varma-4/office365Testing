//
//  Item.swift
//  Simplify OR swift
//
//  Created by Sharanya Puppala on 02/11/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class Item: NSObject {
    
    var itemNo: String?
    var dateCode: String?
    var lotNumber: String?
    var itemId: String?
    var used: NSNumber?
    var wasted: NSNumber?
    var contractPrice: String?
    var itemDescription: String?
    var isDateCodeValid: NSNumber?
    var isItemValid: NSNumber?
    var isConsumedQtyValid: NSNumber?
    var isScrappedQtyValid: NSNumber?
    var isLotValid: NSNumber?
    
}
