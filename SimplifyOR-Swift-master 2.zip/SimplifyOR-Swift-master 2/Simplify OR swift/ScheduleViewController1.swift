//
//  ScheduleViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/10/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import CoreData

class ScheduleViewController: UIViewController, UITableViewDelegate, UITableViewDataSource ,UIPopoverPresentationControllerDelegate, CurrencySelectedDelegate, UpdatePrefDelegate {
    
    @IBOutlet weak var ConsumptionTableView: UITableView!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var remainingTableView: UITableView!
    @IBOutlet weak var thisWeekTableView: UITableView!
    @IBOutlet weak var immediateTableView: UITableView!
    var selectedTableView: UITableView?
    var immediateheight : NSLayoutConstraint?
    var thisweekheight : NSLayoutConstraint?
    var remainingheight : NSLayoutConstraint?
    var selectedTableViewHeight : CGFloat?
    var arrowChange:Int = 0
    var selectrow : NSInteger? = -1
    let value = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String

    func currencySelected(currName: NSInteger, hospitalName: NSString) {
        selectrow = currName
        NSUserDefaults.standardUserDefaults().setObject(hospitalName, forKey: Constants.KDHospital)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    func updateLoggedinSession() {
        self.viewWillAppear(true)
    }

    @IBOutlet weak var consumptionView: UIView!
    @IBOutlet weak var status: UISegmentedControl!
    var result = [Schedules]()
    var statusCode: String?
    var timeFormatter: NSDateFormatter?
    var dateformatter: NSDateFormatter?
    var records = [Schedules]()
    var recordsNew = [Schedules]()
    let utility = Utility()
    let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    //API Call sets this Variable
    var completedRecords = [Schedules]()
    var immediateCount : String!
    var thisWeekCount : String!
    var nextWeekCount : String!
    var comsumptionResult = [Schedules]()

    var records1 = [Schedules]()
    var todayDateg: String?
    var tomorrowDateg: String?
    var endDateOfWeekg: String?
    var endDateNextOfWeekg: String?

    var thisWeekResult = [Schedules]()
    var nextWeekResult = [Schedules]()
    let itemsPerBatch = 10
    var objSchedules = [Schedules]()
    var objSchedulesThisWeek = [Schedules]()
    var objSchedulesRemainWeek = [Schedules]()

    // Where to start fetching items (database OFFSET)
    var offset = 0
    var offsetThisWeek = 0
    var offsetRemainWeek = 0

    
    // a flag for when all database items have already been loaded
    var reachedEndOfItems = false
    var reachedThisWeekEndOfItems = false
    var reachedRemainWeekEndOfItems = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
            self.ConsumptionTableView.hidden = false
            self.consumptionView.hidden = true
            timeFormatter = NSDateFormatter()
            dateformatter = NSDateFormatter()
            timeFormatter!.dateFormat = Constants.timeFormat
            dateformatter!.dateFormat = Constants.dateFormat
            ConsumptionTableView.tableFooterView = UIView()
        
        if value == Constants.kNurse {
            status.selectedSegmentIndex = 2
        }
        else {
            status.selectedSegmentIndex = 0
            changeHeight()
        }
        
        // Do any additional setup after loading the view.
        let screenSize: CGRect = UIScreen.mainScreen().bounds
        for constraint in immediateTableView.constraints as [NSLayoutConstraint]  {
            if constraint.identifier == "immediateheight" {
                let screenHeight = screenSize.height;
                immediateheight = constraint
                if screenHeight == Constants.IPHONE_5{
                    selectedTableViewHeight = 345
                }
                else  if screenHeight == Constants.IPHONE_6 {
                    selectedTableViewHeight = 445
                }
                else  if screenHeight == Constants.IPHONE_6P {
                    selectedTableViewHeight = 517
                }
            }
        }
        
        for constraint in thisWeekTableView.constraints as [NSLayoutConstraint]  {
            if constraint.identifier == "thisweekheight" {
                thisweekheight = constraint
            }
        }
        
        for constraint in remainingTableView.constraints as [NSLayoutConstraint]  {
            if constraint.identifier == "remainingheight" {
                remainingheight = constraint
            }
        }
        
        let (todayDate, tomorrowDate, endDateOfWeek) = self.getDate()
        todayDateg = todayDate
        tomorrowDateg = tomorrowDate
        endDateOfWeekg = endDateOfWeek
        
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        comsumptionResult = [Schedules]()
        records1 = [Schedules]()
        thisWeekResult = [Schedules]()
        nextWeekResult = [Schedules]()
        objSchedules = [Schedules]()
        objSchedulesThisWeek = [Schedules]()
        objSchedulesRemainWeek = [Schedules]()
        completedRecords = [Schedules]()
        records = [Schedules]()
        recordsNew = [Schedules]()

        //Should have API call to fetch records
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        
        self.getSummaryCount()
        
        //spinner.startAnimating()
        //UIApplication.sharedApplication().beginIgnoringInteractionEvents()

        obj.getSummaryList("schedule?Main=SCHEDULES&EndTime=\(tomorrowDateg!)&offset=\(0)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()

                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String

                            self.objSchedules.append(sch)
                        }
                        
                        self.comsumptionResult = self.objSchedules
                        
                        self.immediateTableView.reloadData()

                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                        
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()

                }
                
            })
        })
        
      
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()

        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(todayDateg!)&offset=0&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String

                            self.objSchedulesThisWeek.append(sch)
                        }
                        self.thisWeekResult = self.objSchedulesThisWeek

                        self.thisWeekTableView.reloadData()

                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
       
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()

        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(endDateOfWeekg!)&offset=0&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String

                            self.objSchedulesRemainWeek.append(sch)
                        }
                        
                        self.nextWeekResult = self.objSchedulesRemainWeek

                        self.remainingTableView.reloadData()

                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
        
        self.getCompletedList()
        
        makeTableViewReadOnly()
        self.getConsumptions()
            if status.selectedSegmentIndex == 0 {
                records1 =  self.comsumptionResult
            }
            else if status.selectedSegmentIndex == 2 {
                records =  completedRecords
            }
            else if status.selectedSegmentIndex == 1{
                recordsNew =  result
            }
            
            ConsumptionTableView.reloadData()
    }
    
    
    func makeTableViewReadOnly(){
        if value == Constants.kNurse {
            immediateTableView.allowsSelection = false
            thisWeekTableView.allowsSelection = false
            remainingTableView.allowsSelection = false
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if status.selectedSegmentIndex == 0 {
            return Constants.standardCellHeight
        }
        else {
            return 0
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if status.selectedSegmentIndex == 0 && tableView != ConsumptionTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("headerCell") as! ConsumptionTableViewCell
            if (self.thisWeekCount != nil){
                
                cell.immmediateCountLabel?.text = "(\(self.immediateCount))"
                cell.thisWeekCountLbl?.text = "(\(self.thisWeekCount))"
                cell.nextWeekLable?.text = "(\(self.nextWeekCount))"
                
            }
            if arrowChange == 1 {
                if cell.label.text == "Immediate"
                {
                    cell.contentView.backgroundColor = UIColor.darkGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
                }
                else if cell.label.text == "This week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "Next week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
            }
            else if arrowChange == 2 {
                if cell.label.text == "Immediate"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "This week"
                {
                    cell.contentView.backgroundColor = UIColor.darkGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
                }
                else if cell.label.text == "Next week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
            }
            else if arrowChange == 3 {
                if cell.label.text == "Immediate"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "This week"
                {
                    cell.contentView.backgroundColor = UIColor.lightGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
                }
                else if cell.label.text == "Next week"
                {
                    cell.contentView.backgroundColor = UIColor.darkGrayColor()
                    cell.tab.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
                }
            }
            cell.tab.addTarget(self, action: #selector(ScheduleViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
            return cell.contentView
        }
        else {
            return nil
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var rows = 0
        
        if status.selectedSegmentIndex == 0 {
            if tableView == immediateTableView {
                rows = self.comsumptionResult.count
            }
            if tableView == thisWeekTableView {
                rows = self.thisWeekResult.count
            }
            if tableView == remainingTableView {
                rows = self.nextWeekResult.count
            }

        }
        else if status.selectedSegmentIndex == 1 {
            rows = recordsNew.count
        }
        else if status.selectedSegmentIndex == 2{
            rows = records.count
        }
        
        return rows
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if status.selectedSegmentIndex == 0 {
        let cell = tableView.dequeueReusableCellWithIdentifier("scheduleCell") as! ScheduleTableViewCell
            var sch = Schedules()
            if tableView == immediateTableView {
                
            if (self.comsumptionResult.count != 0){
                sch = comsumptionResult[indexPath.row]
                
                
                
                let utility = Utility()
                let date = sch.startTime
                cell.time.text = utility.getTime(date!)
                cell.date.text = utility.getDate(date!)
                let scheduleType = sch.surgeryType
                if scheduleType == nil
                {
                    cell.surgeryName.text = "No Value"
                    
                }
                else{
                    cell.surgeryName.text = sch.surgeryType
                }
                cell.patientID.text = sch.patientId
                cell.doctorName.text = sch.doctorId
                cell.status.text = " "
                cell.statusImage.hidden = true
            }
            
            if arrowChange == 1 {
                if (self.comsumptionResult.count != 0){
                    
                    sch = comsumptionResult[indexPath.row]
                    
                    let utility = Utility()
                    let date = sch.startTime
                    cell.time.text = utility.getTime(date!)
                    cell.date.text = utility.getDate(date!)
                    let scheduleType = sch.surgeryType
                    if scheduleType == nil
                    {
                        cell.surgeryName.text = "No Value"
                        
                    }
                    else{
                        cell.surgeryName.text = sch.surgeryType
                    }
                    cell.patientID.text = sch.patientId
                    cell.doctorName.text = sch.doctorId
                    cell.status.text = " "
                    cell.statusImage.hidden = true

                    
                }
            }
            }
              if tableView == thisWeekTableView {
               if arrowChange == 2 {
                
                print("count print \(self.thisWeekResult.count)")
                if (self.thisWeekResult.count != 0){
                    
                    sch = thisWeekResult[indexPath.row]
                    
                    let utility = Utility()
                    let date = sch.startTime
                    cell.time.text = utility.getTime(date!)
                    cell.date.text = utility.getDate(date!)
                    let scheduleType = sch.surgeryType
                    if scheduleType == nil
                    {
                        cell.surgeryName.text = "No Value"
                        
                    }
                    else{
                        cell.surgeryName.text = sch.surgeryType
                    }
                    cell.patientID.text = sch.patientId
                    cell.doctorName.text = sch.doctorId
                    cell.status.text = " "
                    cell.statusImage.hidden = true

                }
                }
            }
            
             if tableView == remainingTableView {
             if arrowChange == 3 {
                if (self.nextWeekResult.count != 0){
                    
                    sch = self.nextWeekResult[indexPath.row]
                
                let utility = Utility()
                let date = sch.startTime
                cell.time.text = utility.getTime(date!)
                cell.date.text = utility.getDate(date!)
                let scheduleType = sch.surgeryType
                if scheduleType == nil
                {
                    cell.surgeryName.text = "No Value"
                    
                }
                else{
                    cell.surgeryName.text = sch.surgeryType
                }
                cell.patientID.text = sch.patientId
                cell.doctorName.text = sch.doctorId
                cell.status.text = " "
                cell.statusImage.hidden = true
                }
            }
        }
            return cell
        }
        else  {
            let cell = tableView.dequeueReusableCellWithIdentifier("scheduleCell") as! ScheduleTableViewCell
            cell.statusImage.hidden = false
            
            var sch = Schedules()
            if status.selectedSegmentIndex == 1 {
                sch = self.recordsNew[indexPath.row]
            }
            else if status.selectedSegmentIndex == 2 {
                sch = self.records[indexPath.row]
            }

            let utility = Utility()
            let date = sch.startTime
            cell.time.text = utility.getTime(date!)
            cell.date.text = utility.getDate(date!)
            let scheduleType = sch.surgeryType
            if scheduleType == nil
            {
                cell.surgeryName.text = "No Value"
                
            }
            else{
                cell.surgeryName.text = sch.surgeryType
            }
            cell.patientID.text = sch.patientId
            cell.doctorName.text = sch.doctorId
            cell.status.text = sch.statusCode

            
            if sch.statusCode == Constants.kRejected {
                
                cell.statusImage.image = UIImage(named: "alert red")
                return cell
            }
            else{
                
                cell.statusImage.image = nil
                return cell
            }
            
        }
    }
    
    func expandOrCollapse (sender:UIButton) {
        selectedTableView = sender.superview?.superview as? UITableView
        immediateheight?.constant = Constants.standardCellHeight
        thisweekheight?.constant = Constants.standardCellHeight
        remainingheight?.constant = Constants.standardCellHeight
        
        if selectedTableView == immediateTableView {
            arrowChange = 1;
            immediateheight?.constant = selectedTableViewHeight!
        }
        else if selectedTableView == thisWeekTableView {
            arrowChange = 2;
            thisweekheight?.constant = selectedTableViewHeight!
        }
        else if selectedTableView == remainingTableView {
            arrowChange = 3;
            remainingheight?.constant = selectedTableViewHeight!
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if status.selectedSegmentIndex == 0 {
            if value == Constants.kVendor {
                performSegueWithIdentifier("toMail", sender: selectedTableView!.cellForRowAtIndexPath(indexPath))
            }
            
        }
        else if status.selectedSegmentIndex == 1{
            performSegueWithIdentifier("toConsumptionItems", sender: tableView.cellForRowAtIndexPath(indexPath))
        }
        else if status.selectedSegmentIndex == 2{
            let status = records[indexPath.row].statusCode
            if status == Constants.kRejected {
                performSegueWithIdentifier("toConsumptionItems", sender: tableView.cellForRowAtIndexPath(indexPath))
            }
            else{
                performSegueWithIdentifier("toApprove", sender: tableView.cellForRowAtIndexPath(indexPath))
            }
        }
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.

         let cell = sender as! ScheduleTableViewCell
            if segue.identifier == "toConsumptionItems" {
            let indexpath = ConsumptionTableView.indexPathForCell(cell)
            let surgeryController = segue.destinationViewController as! SurgeryDetailsViewController
            surgeryController.status = cell.status.text
            let utility = Utility()
            let date = recordsNew[(indexpath?.row)!].startTime
            let aScheduleId = recordsNew[(indexpath?.row)!].scheduleId
            surgeryController.scheduleID = aScheduleId
            surgeryController.patientID = records[(indexpath?.row)!].patientId
            surgeryController.doctor = records[(indexpath?.row)!].doctorId
            surgeryController.date = utility.getDate(date!)
            surgeryController.time = utility.getTime(date!)
            surgeryController.surgery = records[(indexpath?.row)!].surgeryType
            surgeryController.contractExpDate = records[(indexpath?.row)!].contractExpiryDate

        }
        else if segue.identifier == "toMail" {
            let mailController = segue.destinationViewController as! MailViewController
            mailController.patientID = cell.patientID.text
            mailController.doctor = cell.doctorName.text
            mailController.date = cell.date.text
            mailController.time = cell.time.text
            mailController.surgery = cell.surgeryName.text
        }
        else if segue.identifier == "toApprove"{
            let indexpath = ConsumptionTableView.indexPathForCell(cell)
            let surgeryController = segue.destinationViewController as! NurseSurgeryDetailsViewController
            surgeryController.status = cell.status.text
            let utility = Utility()
            let date = records[(indexpath?.row)!].startTime
            surgeryController.consumptionID = records[(indexpath?.row)!].scheduleId
            surgeryController.patientID = records[(indexpath?.row)!].patientId
            surgeryController.doctor = records[(indexpath?.row)!].doctorId
            surgeryController.date = utility.getDate(date!)
            surgeryController.time = utility.getTime(date!)
            surgeryController.surgery = records[(indexpath?.row)!].surgeryType
            surgeryController.contractExpDate = records[(indexpath?.row)!].contractExpiryDate
        }
    }
    
    @IBAction func settingButtonClicked(sender: AnyObject) {
       
        let vc = storyboard?.instantiateViewControllerWithIdentifier("settingsSegue") as! SettingTableViewController
        vc.delegate = self
        vc.prefUpdateDelegate = self
        
        let navController = UINavigationController(rootViewController: vc)
        navController.modalPresentationStyle = UIModalPresentationStyle.Popover
        navController.popoverPresentationController?.sourceView = self.view
        navController.popoverPresentationController?.sourceRect = CGRectMake(13, 20, 50, 30)
        let popover = navController.popoverPresentationController
        popover?.delegate = self
        popover?.barButtonItem = sender as? UIBarButtonItem
        
        vc.selectedIndex = self.selectrow
        self.presentViewController(navController, animated: true, completion: nil)
 
       
        
    }
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }
    
    func changeHeight() {
        if status.selectedSegmentIndex == 0 {
            self.ConsumptionTableView.hidden = true
            self.consumptionView.hidden = false
            thisWeekTableView.hidden = false
            immediateTableView.hidden = false
            remainingTableView.hidden = false
            selectedTableView = immediateTableView
        }
        else {
            self.ConsumptionTableView.hidden = false
            self.consumptionView.hidden = true
        }
    }
    
    
    @IBAction func changedSegementControllerValue(sender: AnyObject) {
        if status.selectedSegmentIndex == 0 {
            self.ConsumptionTableView.hidden = true
            changeHeight()
            self.immediateTableView.reloadData()
            self.thisWeekTableView.reloadData()
            self.remainingTableView.reloadData()
        }
        else if status.selectedSegmentIndex == 1 {
            self.consumptionView.hidden = true
            self.getConsumptions()
            recordsNew = result
            changeHeight()
            ConsumptionTableView.reloadData()
        }
        else if status.selectedSegmentIndex == 2{
            self.consumptionView.hidden = true
            records = completedRecords
            changeHeight()
            ConsumptionTableView.reloadData()
        }
        else {
            self.consumptionView.hidden = true
            changeHeight()
            ConsumptionTableView.reloadData()
        }
    }
    
    func rangeOfPeriod(period: NSCalendarUnit) -> (NSDate, NSDate) {
        
        let date = NSDate()
        let calendar = NSCalendar.currentCalendar()
        
        var startDate: NSDate? = nil
        
        calendar.rangeOfUnit(period, startDate: &startDate, interval: nil, forDate: date)
        
        let endDate = calendar.dateByAddingUnit(period, value: 1, toDate: startDate!, options: [])
        
        return (startDate!, endDate!)
    }
    
    func getDate() -> (String, String, String) {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let todayDate = dateFormatter.stringFromDate(NSDate())
        
        let startOfDay = NSCalendar.currentCalendar().startOfDayForDate(NSDate())
        
        let calendar = NSCalendar.currentCalendar()
        let aDayFromNow = calendar.dateByAddingUnit(.Day, value: 1, toDate: startOfDay, options: [])
        
        let comps = calendar.components([.Year, .Month, .Day, .Hour, .Minute, .Second], fromDate:aDayFromNow!)
        comps.hour = 23
        comps.minute = 59
        comps.second = 59
        
        let midnightOfToday = calendar.dateFromComponents(comps)!
        let tomrwDate = dateFormatter.stringFromDate(midnightOfToday)
        
        let (startOfWeek, endOfWeek) = rangeOfPeriod(.WeekOfYear)
        _ = dateFormatter.stringFromDate(startOfWeek)
        let endDateOfWeek = dateFormatter.stringFromDate(endOfWeek)
        
        return (todayDate,tomrwDate,endDateOfWeek)
        
    }

    
    // adding Editing Styles here.
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let confirm = UITableViewRowAction(style: .Normal, title: "Confirm") { action, index in

            //coredata modification needs to be done here...
            if tableView == self.immediateTableView {
                let consumptionObject = self.comsumptionResult[indexPath.row].scheduleId
                let obj = CommonManager()
                
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = self.view.center
                self.view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.confirmSchedule(consumptionObject!, callback: {(data,error,status) in
                    dispatch_async(dispatch_get_main_queue(), {
                        spinner.stopAnimating();
                        spinner.removeFromSuperview()
                        UIApplication.sharedApplication().endIgnoringInteractionEvents()
                        do{
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            if status == 200
                            {
                                
                                self.comsumptionResult.removeAtIndex(indexPath.row)
                                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation:UITableViewRowAnimation.Left)
                                self.getSummaryCount()
                                self.getConsumptions()
                                
                            }
                            else
                            {
                                
                                let  error = parseJSON["error"]
                                let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                                alert.show()
                                
                            }
                            
                            
                        }
                        catch{
                            let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                            let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                            alert.show()
                        }
                        
                    })
                })
            }
            if tableView == self.thisWeekTableView {
                let consumptionThisWeekObject = self.thisWeekResult[indexPath.row].scheduleId
                let obj = CommonManager()
                
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = self.view.center
                self.view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.confirmSchedule(consumptionThisWeekObject!, callback: {(data,error,status) in
                    dispatch_async(dispatch_get_main_queue(), {
                        spinner.stopAnimating();
                        spinner.removeFromSuperview()
                        UIApplication.sharedApplication().endIgnoringInteractionEvents()
                        do{
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            if status == 200
                            {
                                
                                self.thisWeekResult.removeAtIndex(indexPath.row)
                                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation:UITableViewRowAnimation.Left)
                                self.getSummaryCount()
                                self.getConsumptions()
                                
                            }
                            else
                            {
                                
                                let  error = parseJSON["error"]
                                
                                let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                                alert.show()
                                
                            }
                            
                            
                        }
                        catch{
                            let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                            let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                            alert.show()
                        }
                        
                    })
                })
            }
            if tableView == self.remainingTableView {
                let consumptionRemainWeekObject = self.nextWeekResult[indexPath.row].scheduleId
                let obj = CommonManager()
                
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = self.view.center
                self.view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.confirmSchedule(consumptionRemainWeekObject!, callback: {(data,error,status) in
                    dispatch_async(dispatch_get_main_queue(), {
                        spinner.stopAnimating();
                        spinner.removeFromSuperview()
                        UIApplication.sharedApplication().endIgnoringInteractionEvents()
                        do{
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            if status == 200
                            {
                                
                                self.nextWeekResult.removeAtIndex(indexPath.row)
                                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation:UITableViewRowAnimation.Left)
                                self.getSummaryCount()
                                self.getConsumptions()
                                
                            }
                            else
                            {
                                
                                let  error = parseJSON["error"]
                                let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                                alert.show()
                                
                            }
                            
                            
                        }
                        catch{
                            let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                            let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                            alert.show()
                        }
                        
                    })
                })
            }
        }
        confirm.backgroundColor = UIColor.lightGrayColor()
        
        
        
        return [confirm]
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // the cells you would like the actions to appear needs to be editable
        if status.selectedSegmentIndex == 0 && value == Constants.kVendor{
        return true
        }
        else{
        return false
        }
        
    }
    
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        // UITableView only moves in one direction, y axis
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        // Change 10.0 to adjust the distance from bottom
        if maximumOffset - currentOffset <= 10.0 {
            
            if scrollView == immediateTableView {
                self.loadMoreItems()
            }
            if scrollView == thisWeekTableView {
                self.loadThisWeekMoreItems()
            }
            if scrollView == remainingTableView {
                self.loadMoreRemainWeekItems()
            }
        }
    }
    func loadMoreItems() {

        guard !self.reachedEndOfItems else {
            return
        }
        
        // determine the range of data items to fetch
        var thisBatchOfItems = [Schedules]()
        let end = self.offset + self.itemsPerBatch
        
        // query the database
        do {
            thisBatchOfItems = self.aPageofItems(end, dateFilter: tomorrowDateg!)
        } catch _ {
//            print("query failed")
        }
        
        // update UITableView with new batch of items on main thread after query finishes
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItems = [Schedules]()
            if  self.comsumptionResult == thisBatchOfItems {
                
//                print("same")
            }
            else{
                newItems = thisBatchOfItems
//                print("load more check1 \(newItems.count)")
                
                // append the new items to the data source for the table view
                self.comsumptionResult.appendContentsOf(newItems)
                
                // reload the table view
                self.immediateTableView.reloadData()
                
                // check if this was the last of the data
                if newItems.count < self.itemsPerBatch {
                    self.reachedEndOfItems = true
//                    print("reached end of data. Batch count: \(newItems.count)")
                }
            }
            self.offset += self.itemsPerBatch
        })
    }
    
    func loadThisWeekMoreItems() {
        
        guard !self.reachedThisWeekEndOfItems else {
            return
        }
        
        var thisBatchOfItemsThisWeek = [Schedules]()
        let endThisWeek = self.offsetThisWeek + self.itemsPerBatch
        
        do {
            thisBatchOfItemsThisWeek = self.aPageofItemsThisWeek(endThisWeek, dateFilter: todayDateg!)
        } catch _ {
        }
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItems = [Schedules]()
            if  self.thisWeekResult == thisBatchOfItemsThisWeek {
                
            }
            else{
                newItems = thisBatchOfItemsThisWeek
                
                self.thisWeekResult.appendContentsOf(newItems)
                
                self.thisWeekTableView.reloadData()
                
                if newItems.count < self.itemsPerBatch {
                    self.reachedThisWeekEndOfItems = true
                }
            }
            self.offsetThisWeek += self.itemsPerBatch
        })
    }

    func loadMoreRemainWeekItems() {
        guard !self.reachedRemainWeekEndOfItems else {
            return
        }
        
        var thisBatchOfItemsRemainWeek = [Schedules]()
        let endRemainWeek = self.offsetRemainWeek + self.itemsPerBatch
        
        do {
            thisBatchOfItemsRemainWeek = self.aPageofItemsRemainWeek(endRemainWeek, dateFilter: endDateOfWeekg!)
        } catch _ {
        }
        
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            var newItemsRemainWeek = [Schedules]()
            if  self.nextWeekResult == thisBatchOfItemsRemainWeek {
                
            }
            else{
                newItemsRemainWeek = thisBatchOfItemsRemainWeek
                
                self.nextWeekResult.appendContentsOf(newItemsRemainWeek)
                
                self.remainingTableView.reloadData()
                
                if newItemsRemainWeek.count < self.itemsPerBatch {
                    self.reachedRemainWeekEndOfItems = true
                }
            }
            self.offsetRemainWeek += self.itemsPerBatch
        })
    }

    
    func aPageofItems(start: Int,dateFilter: String) -> [Schedules]{
        
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getSummaryList("schedule?Main=SCHEDULES&EndTime=\(dateFilter)&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        self.objSchedules = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String

                            self.objSchedules.append(sch)
                        }
                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
        return objSchedules
    }

    func aPageofItemsThisWeek(start: Int,dateFilter: String) -> [Schedules]{
        
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(dateFilter)&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        self.objSchedulesThisWeek = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String

                            self.objSchedulesThisWeek.append(sch)
                        }
                        
                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
        return objSchedulesThisWeek
    }
    func aPageofItemsRemainWeek(start: Int,dateFilter: String) -> [Schedules]{
        
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getSummaryList("schedule?Main=SCHEDULES&StartTime=\(dateFilter)&offset=\(start)&limit=10", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        self.objSchedulesRemainWeek = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String

                            self.objSchedulesRemainWeek.append(sch)
                        }
                        
                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
        return objSchedulesRemainWeek
    }

    func getConsumptions()  {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()

        obj.getSummaryList("schedule?Main=CONSUMPTIONS", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSON = json
                    if statusSummary == 200
                    {
                        self.result = [Schedules]()
                        let JSON = parseJSON as! NSArray
                        print(JSON)
                        for aSch in JSON{
                            let obj = aSch as! NSDictionary
                            let  sch = Schedules()
                            
                            sch.startTime = obj["startTime"] as? String
                            sch.surgeryType = obj["scheduleType"] as? String
                            sch.statusCode = obj["statusCode"] as? String
                            sch.doctorId = obj["doctorID"] as? String
                            sch.patientId = obj["patientID"] as? String
                            sch.scheduleId = obj["id"] as? String
                            sch.contractExpiryDate = obj["contractExpiryDate"] as? String
                            
                            self.result.append(sch)
                        }
                        self.recordsNew = self.result

                        self.ConsumptionTableView.reloadData()
                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })

    }
    
    func getSummaryCount()  {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        
        obj.getSummaryList("schedulesummary?Main=SCHEDULES", callbackSummary: {(dataSummary,errorSummary,statusSummary) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do{
                    let jsonn = try NSJSONSerialization.JSONObjectWithData(dataSummary, options:[])
                    let parseJSONN = jsonn
                    if statusSummary == 200
                    {
                        
                        if let immediate = parseJSONN["immediate"] as? NSNumber{
                            self.immediateCount = immediate.stringValue
                        }
                        if let thisWeek = parseJSONN["thisWeek"] as? NSNumber{
                            self.thisWeekCount = thisWeek.stringValue
                        }
                        if let nextWeek = parseJSONN["nextWeek"] as? NSNumber{
                            self.nextWeekCount = nextWeek.stringValue
                        }
                        
                        self.immediateTableView.reloadData()
                        self.thisWeekTableView.reloadData()
                        self.remainingTableView.reloadData()
                    }
                    else{
                        let  error = parseJSONN["error"]
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                }
                catch{
                    let jsonStr = NSString(data: dataSummary, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })

    }
    
    func getCompletedList()  {
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.getCompletedList("", callbackCompleted: {(dataCompleted,errorCompleted,statusCompleted) in
            dispatch_async(dispatch_get_main_queue(), {
            spinner.stopAnimating();
            spinner.removeFromSuperview()
            UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    let json = try NSJSONSerialization.JSONObjectWithData(dataCompleted, options:[])
                    var parseJSON = json
                    if statusCompleted == 200
                    {
                        print("its success")
                        parseJSON = parseJSON as! NSArray
                        for aSch in parseJSON as! [AnyObject]{
                            
                            let schedule = aSch["schedule"]
                            let statusCode = aSch["statusCode"]
                            let id = aSch["id"]

                            let  sch = Schedules()
                            sch.startTime = schedule!!["startTime"] as? String
                            sch.surgeryType = schedule!!["scheduleType"] as? String
                            sch.statusCode = statusCode as? String
                            sch.doctorId = schedule!!["doctorID"] as? String
                            sch.patientId = schedule!!["patientID"] as? String
                            sch.scheduleId = id as? String
                            
                            self.completedRecords.append(sch)
                        }
                        self.records = self.completedRecords
                        self.ConsumptionTableView.reloadData()
                        
                    }
                    else{
                        
                        let  error = parseJSON["error"]
                        
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: dataCompleted, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
        

    }
    
    }
