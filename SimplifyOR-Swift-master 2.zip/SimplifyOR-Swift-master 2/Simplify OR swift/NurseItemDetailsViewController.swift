//
//  NurseItemDetailsViewController.swift
//  Simplify OR swift
//
//  Created by manikanta on 13/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

protocol flagStatusDelegate {
    func flagsInformation(flagDictionary:NSDictionary,itemsToBeChanged:[String],allDictionaryItems:[NSDictionary])
}

class NurseItemDetailsViewController: UIViewController {
    
    // MARK: Constants Declaration
    let value = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
    let alertViewObject = Utility()
    
    // MARK: IBOutlets Declaration
    //outlets for Custom Checkbox Buttons
    @IBOutlet weak var itemCheckBoxButton: CustomCheckBoxButton!
    @IBOutlet weak var itemDescCheckBoxButton: CustomCheckBoxButton!
    @IBOutlet weak var lotCheckBoxButton: CustomCheckBoxButton!
    @IBOutlet weak var dCodeCheckBoxButton: CustomCheckBoxButton!
    @IBOutlet weak var usedCheckBoxButton: CustomCheckBoxButton!
    @IBOutlet weak var wastedCheckBoxButton: CustomCheckBoxButton!
    @IBOutlet weak var contractPriceCheckBoxButton: CustomCheckBoxButton!
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var contractPrice: UILabel!
    @IBOutlet weak var wastedValue: UILabel!
    @IBOutlet weak var usedValue: UILabel!
    @IBOutlet weak var dateCode: UILabel!
    @IBOutlet weak var lotNumber: UILabel!
    @IBOutlet weak var itemDescription: UILabel!
    @IBOutlet weak var itemNumber: UILabel!
    
    // MARK: Var Properties Declaration
    //Dictionary Objects created for
    var objectsCreatedForItems = [String]()
    // All Dictionary Objects
    var dictionaryObjectsOfCells = [NSDictionary]()
    var itemIdOfConsumption:String = String()
    //ConsumptionItem
    var consumptionItem:Item!
    var currentCellBeingEdited:SurgeryTableViewCell!
    var itemNtInContractFlag:Bool!
    var delegate:flagStatusDelegate? = nil
    var dictItemFlag:NSDictionary!
    var consumptionID: String?
    var status:String!
    var lineItemId : String?
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(NurseItemDetailsViewController.checkForButtonChange(_:)), name:"buttonTitleChange", object: nil)

        backButton.layer.cornerRadius = 5
        backButton.layer.masksToBounds = true
        rejectButton.layer.cornerRadius = 5
        rejectButton.layer.masksToBounds = true
        if status == Constants.kApproved  || value == Constants.kVendor{
            rejectButton.enabled = false
            itemCheckBoxButton.hidden = true
            itemDescCheckBoxButton.hidden = true
            lotCheckBoxButton.hidden = true
            dCodeCheckBoxButton.hidden = true
            usedCheckBoxButton.hidden = true
            wastedCheckBoxButton.hidden = true
            contractPriceCheckBoxButton.hidden = true
        }
        if status == Constants.kRejected  && value == Constants.kNurse{
            rejectButton.enabled = false

            itemCheckBoxButton.enabled = false
            itemDescCheckBoxButton.enabled = false
            lotCheckBoxButton.enabled = false
            dCodeCheckBoxButton.enabled = false
            usedCheckBoxButton.enabled = false
            wastedCheckBoxButton.enabled = false
            contractPriceCheckBoxButton.enabled = false

        }
        updateCheckBoxesAndLabels()
        checkForTitleChange()
    }
    
        // MARK: User-Defined Functions
    func checkForButtonChange(notification: NSNotification) {
        if status == Constants.KPending  && value == Constants.kNurse {
            if usedCheckBoxButton.isChecked == false && wastedCheckBoxButton.isChecked == false && lotCheckBoxButton.isChecked == false && dCodeCheckBoxButton.isChecked == false {
                rejectButton.setTitle("Continue", forState: UIControlState.Normal)
            }
            else {
                rejectButton.setTitle("Reject", forState: UIControlState.Normal)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: User-Defined Functions
    private func updateCheckBoxesAndLabels() {
        
        contractPriceCheckBoxButton.enabled = false
        itemDescCheckBoxButton.enabled = false
        if itemNtInContractFlag == true {
            itemCheckBoxButton.isChecked = true
            itemCheckBoxButton.enabled = false
        }
        else {
            itemCheckBoxButton.isChecked = false
            itemCheckBoxButton.enabled = false
        }
        if(consumptionItem != nil) {
            itemIdOfConsumption = (consumptionItem.itemId!)
            if(itemNtInContractFlag == true) {
                let attributedString = NSMutableAttributedString(string:consumptionItem.itemNo!)
                attributedString.addAttribute(NSForegroundColorAttributeName, value: UIColor.redColor(), range: NSMakeRange(0, attributedString.length))
                itemNumber.attributedText = attributedString
            }
            else {
                itemNumber.text = consumptionItem.itemNo
            }
            lineItemId = consumptionItem.itemId!
            itemDescription.text = consumptionItem.itemDescription
            lotNumber.text = consumptionItem.lotNumber
            dateCode.text = consumptionItem.dateCode
            
            usedValue.text = (consumptionItem.used?.stringValue)
            wastedValue.text = (consumptionItem.wasted?.stringValue)
            contractPrice.text = consumptionItem.contractPrice
            
            if let usedVal = consumptionItem.isConsumedQtyValid  {
                usedCheckBoxButton.isChecked = !usedVal.boolValue
            }
            if let wasteVal = consumptionItem.isScrappedQtyValid  {
                wastedCheckBoxButton.isChecked = !wasteVal.boolValue
            }
            if let dateCodeVal = consumptionItem.isDateCodeValid  {
            dCodeCheckBoxButton.isChecked = !dateCodeVal.boolValue
            }
            if let lotNoVal = consumptionItem.isLotValid  {
                lotCheckBoxButton.isChecked = !lotNoVal.boolValue
            }
        }
    }
    
    private func checkForTitleChange() {
        if status == Constants.KPending  && value == Constants.kNurse {
            if usedCheckBoxButton.isChecked == false && wastedCheckBoxButton.isChecked == false && lotCheckBoxButton.isChecked == false && dCodeCheckBoxButton.isChecked == false {
                rejectButton.setTitle("Continue", forState: UIControlState.Normal)
            }
            else {
                rejectButton.setTitle("Reject", forState: UIControlState.Normal)
            }
        }
    }
    
    @IBAction func rejectButtonPressed(sender: UIButton) {
        //Save the Status of the Checkboxes buttons and pass back to the Table view
        self.rejectConsumption()
    }
    
    private func rejectConsumption() {
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
//        obj.rejectLineItem(consumptionID!, isItemValid:(itemCheckBoxButton.isChecked ? 0 : 1), isConsumedQtyValid: (usedCheckBoxButton.isChecked ? 0 : 1), isDateCodeValid:(dCodeCheckBoxButton.isChecked ? 0 : 1), isScrappedQtyValid: (wastedCheckBoxButton.isChecked ? 0 : 1), isLotValid: (lotCheckBoxButton.isChecked ? 0 : 1), itemId: lineItemId!, callbackReject: {(data,error,status,connectivityFlag) in
//            dispatch_async(dispatch_get_main_queue(), {
        let isItemvalidFlag = (itemCheckBoxButton.isChecked ? 0 : ((consumptionItem?.isItemValid == 0) ? 1 : (((consumptionItem?.isItemValid == 1) || (consumptionItem?.isItemValid == nil)) ? 1 : 2)))
        let isConsumedQuantityvalidFlag = (usedCheckBoxButton.isChecked ? 0 : ((consumptionItem?.isConsumedQtyValid == 0) ? 1 : (((consumptionItem?.isConsumedQtyValid == 1) || (consumptionItem?.isConsumedQtyValid == nil)) ? 1 : 2)))
        let isScrappedQuantityvalidFlag = (wastedCheckBoxButton.isChecked ? 0 : ((consumptionItem?.isScrappedQtyValid == 0) ? 1 : (((consumptionItem?.isScrappedQtyValid == 1) || (consumptionItem?.isScrappedQtyValid == nil)) ? 1 : 2)))
        
        let isDateCodeFlag = (dCodeCheckBoxButton.isChecked ? 0 : ((consumptionItem?.isDateCodeValid == 0) ? 1 : (((consumptionItem?.isDateCodeValid == 1) || (consumptionItem?.isDateCodeValid == nil)) ? 1 : 2)))
        let isLotCodeFlag = (lotCheckBoxButton.isChecked ? 0 : ((consumptionItem?.isLotValid == 0) ? 1 : (((consumptionItem?.isLotValid == 1) || (consumptionItem?.isLotValid == nil)) ? 1 : 2)))
        
        

        obj.rejectLineItem(consumptionID!, isItemValid: isItemvalidFlag, isConsumedQtyValid: isConsumedQuantityvalidFlag, isDateCodeValid: isDateCodeFlag, isScrappedQtyValid: isScrappedQuantityvalidFlag, isLotValid: isLotCodeFlag, itemId: lineItemId!, callbackReject: {(data,error,status,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                do {
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if status == 200
                    {
                        self.navigationController?.popViewControllerAnimated(true)
                    }
                    else
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                        let parseJSON = json
                        let  error = parseJSON["message"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch {
                    let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    // MARK: - Navigation
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func backButtonPressed(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }

}

    
    
    
    
       

