//
//  SurgeryTableViewCell.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/2/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class SurgeryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var quantityValue: UILabel!
    @IBOutlet weak var dateStatus: UIImageView!
    @IBOutlet weak var lotStatus: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
