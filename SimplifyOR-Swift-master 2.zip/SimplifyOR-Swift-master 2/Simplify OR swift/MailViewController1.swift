//
//  MailViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 9/14/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import MessageUI

class MailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {
    
    @IBOutlet weak var detailsTableView: UITableView!
    
    var isExpanded:Bool = false;
    var patientID: String?
    var doctor: String?
    var date: String?
    var time: String?
    var surgery:String?
    let mailComposer = MFMailComposeViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        

    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        // Do any additional setup after loading the view.
        sendMail()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return Constants.expandedCellHeight
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return Constants.standardCellHeight
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("expandHeader")! as! HeaderTableViewCell
        
        cell.surgeryDate.text = date
        cell.surgeryTime.text = time
        cell.surgerlyName.text =  surgery!
        
        if isExpanded {
            cell.toggle.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
        }
        else {
            cell.toggle.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
        }
        
        cell.toggle.addTarget(self, action: #selector(SurgeryDetailsViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
        return cell.contentView
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isExpanded {
            return 1
        }
        else {
            return 0
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("detailsCell") as! DetailsTableViewCell
        cell.doctor.text = doctor
        cell.patientID.text = patientID
        return cell
    }
    
    
    func expandOrCollapse (sender:UIButton) {
        //var frame = mailComposer.view.frame
        var frame = CGRectMake(0, 110, view.frame.size.width, 500)
        
        if isExpanded {
            isExpanded = false
            frame.origin.y = 110
        }
        else {
            isExpanded = true
            frame.origin.y = 170
        }
        if MFMailComposeViewController.canSendMail() {
        mailComposer.view.frame = frame
        }
        
        UIView.transitionWithView(detailsTableView, duration: 0.8, options: .TransitionFlipFromTop, animations: {self.detailsTableView.reloadData()
            }, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func homeButtonPressed(sender: UIButton) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backButtonPressed(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    func sendMail() {
        if MFMailComposeViewController.canSendMail() {
            let messageBody = "-----Please do not delete the below header information……….. \n" + "Schedule Date: " + "\n Hospital Name: " + "\n Doctor: " + doctor!
            let message = messageBody + "\n--------End of Header information ------------------------------------"
            let emailTitle = (NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital) as! String) + "-\(surgery!)-\(date!)-\(time!)"
            mailComposer.mailComposeDelegate = self;
            mailComposer.setSubject(emailTitle)
            mailComposer.setMessageBody(message, isHTML: true)
            self.addChildViewController(mailComposer)
            mailComposer.navigationBar.barTintColor = Constants.orangeColor
            mailComposer.navigationBar.tintColor = UIColor.darkGrayColor()
            mailComposer.view.frame = CGRectMake(0, 110, view.frame.size.width, 500)
            view.addSubview(mailComposer.view)
        }
    }
    
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        switch (result.rawValue)
        {
        case MFMailComposeResult.Cancelled.rawValue:
            break;
        case MFMailComposeResult.Saved.rawValue:
            break;
        case MFMailComposeResult.Sent.rawValue:
            break;
        case MFMailComposeResult.Failed.rawValue:
            break;
        default:
            break;
        }
        self.navigationController?.popViewControllerAnimated(true)
    }
}

