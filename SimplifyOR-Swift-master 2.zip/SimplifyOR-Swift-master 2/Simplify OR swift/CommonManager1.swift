//
//  CommonManager.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/2/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class CommonManager: NSObject {
    
    func login(username:String,password:String, callback: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "username=\(username)&password=\(password)"
            let url = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/dologin?" + postString
            let request = NSMutableURLRequest(URL: NSURL(string: url)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    let fields = responsecode.allHeaderFields as? [String : String]
                    
                    if statuscode == 200
                    {
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        let cookies = NSHTTPCookie.cookiesWithResponseHeaderFields(fields!, forURL: response!.URL!)
                        NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookies(cookies, forURL: response!.URL!, mainDocumentURL: nil)
                        print(cookies)
                        //NSHTTPCookieStorage.sharedHTTPCookieStorage().getCookiesForTask(<#T##task: NSURLSessionTask##NSURLSessionTask#>, completionHandler:
                        callback(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callback(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }
    
    func updatePreferences(loggedInOrgId:String, callback: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/session/{id}"
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let body = ["loggedInOrgId": loggedInOrgId]
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    let fields = responsecode.allHeaderFields as? [String : String]
                    
                    if statuscode == 200
                    {
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        let cookies = NSHTTPCookie.cookiesWithResponseHeaderFields(fields!, forURL: response!.URL!)
                        NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookies(cookies, forURL: response!.URL!, mainDocumentURL: nil)
                        print(cookies)
                        
                        callback(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callback(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }
    
    
    func confirmSchedule(scheduleId:String, callback: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(scheduleId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/schedule/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            //request.HTTPShouldHandleCookies = true
            
            let body = ["statusCode": "CONFIRMED"]
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callback(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callback(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }


    
    func getAssociatedOrgs(userId:String, callbackOrgs: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(userId)/orgs?companyType=HOSPITAL"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/user/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackOrgs(data!,"", statuscode)
                    }
                    else
                    {
                        if data != nil {
                            callbackOrgs(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callbackOrgs(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }


    func getSummaryList(main:String,callbackSummary: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            
            let postString = main
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackSummary(data!,"", statuscode)
                    }
                    else
                    {
                        if data != nil {
                            callbackSummary(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callbackSummary(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Invalid", message:"No internet", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
    }
    
    
    func createConsumption(postString:String, consumptionTime:String, scheduleId:String, orgId:String, vendorId:String,callback2: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            
          
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "POST"
            let body = ["consumptionTime": consumptionTime,"scheduleId":scheduleId,"orgId":orgId,"vendorId":vendorId]
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }

            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    //let fields = responsecode.allHeaderFields as? [String : String]
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callback2(data!,"", statuscode)
                    }
                    else
                    {
                        if data != nil {
                            callback2(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callback2(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Invalid", message:"No internet", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
    }
    

   //consumption detail
    func getConsumptionDetail(main:String,callbackDetail: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            
            let postString = main
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    //let fields = responsecode.allHeaderFields as? [String : String]
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackDetail(data!,"", statuscode)
                    }
                    else
                    {
                        if data != nil {
                            callbackDetail(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callbackDetail(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Invalid", message:"No internet", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
    }
    
    
    func getSingleConsumptionDetail(consumptionId:String,callback: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            
            let postString = consumptionId
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callback(data!,"", statuscode)
                    }
                    else
                    {
                        if data != nil {
                            callback(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                    
                else
                {   if data != nil {
                        callback(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else {
            let alert = UIAlertView(title:"Invalid", message:"No internet", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
    }

    func addLineItem(consumptionId:String,itemNo:String,lotNumber:String,dateCode:String,consumedQty:String,scrappedQty:String, callbackAdd: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let subBody = [["consumedQty":consumedQty,"dateCode":dateCode,"itemNo":itemNo,"lotNumber":lotNumber,"scrappedQty":scrappedQty]]

            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackAdd(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackAdd(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackAdd(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else {
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:nil, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }

    func updateLineItem(consumptionId:String,itemNo:String,lotNumber:String,dateCode:String,consumedQty:String,scrappedQty:String,itemId:String, callbackUpdate: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let subBody = [["consumedQty":consumedQty,"dateCode":dateCode,"itemNo":itemNo,"lotNumber":lotNumber,"scrappedQty":scrappedQty,"id":itemId]]
            
            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackUpdate(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackUpdate(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackUpdate(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }
    
    
    func submitForReview(consumptionId:String, callbackSubmit: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let body = ["notes":"test insert","statusCode":"REVIEW_PENDING"]
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackSubmit(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackSubmit(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackSubmit(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }

    func getCompletedList(main:String,callbackCompleted: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com//services/data/v1.0/consumption"
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackCompleted(data!,"", statuscode)
                    }
                    else
                    {
                        if data != nil {
                            callbackCompleted(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                    
                else
                {
                    if data != nil {
                        callbackCompleted(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Invalid", message:"No internet", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
    }

    func rejectLineItem(consumptionId:String, isItemValid:Int, isConsumedQtyValid:Int, isDateCodeValid:Int, isScrappedQtyValid:Int, isLotValid:Int,itemId:String, callbackReject: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let subBody = [["isItemValid":isItemValid,"isConsumedQtyValid":isConsumedQtyValid,"isDateCodeValid":isDateCodeValid,"isScrappedQtyValid":isScrappedQtyValid,"isLotValid":isLotValid,"id":itemId]]
            
            let body = ["details":subBody,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            }
            catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackReject(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackReject(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackReject(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }

    func approveConsumption(consumptionId:String, callbackApprove: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let body = ["notes":"test insert","statusCode":"APPROVED"]
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackApprove(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackApprove(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackApprove(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }
    
    func rejectConsumption(consumptionId:String,reason1:Int, reason2:Int, otherReason:Int, callbackReject: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            
            let body = ["isRejectedForReason1":reason1,"isRejectedForReason2":reason2,"isRejectedForOthers": otherReason,"notes":"test insert","statusCode":"REJECTED"]
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: [])
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            //
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackReject(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackReject(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil {
                        callbackReject(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else {
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }

    func addMultipleLineItems(consumptionId:String,lineItems:[[String:AnyObject]], callbackAddMultiple: (NSData, String, Int) -> Void) {
        
        let utility = Utility()
        
        let connectivityStatus = utility.hasConnectivity()
        
        if connectivityStatus {
            
            let postString = "\(consumptionId)"
            let originalUrl = "http://simplifyor-env.us-west-2.elasticbeanstalk.com/services/data/v1.0/consumption/" + postString
            let url = originalUrl.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())
            let request = NSMutableURLRequest(URL: NSURL(string: url!)!)
            let session = NSURLSession.sharedSession()
            
            request.HTTPMethod = "PATCH"
            let body:[String:AnyObject] = ["details":lineItems,"notes":"test insert","statusCode":"UPDATE_LINE_ITEMS"]
            
            let jsonBody: NSData
            do {
                jsonBody = try NSJSONSerialization.dataWithJSONObject(body, options: NSJSONWritingOptions.PrettyPrinted)
                request.HTTPBody = jsonBody
            } catch {
                #if DEBUG
                    print("Error: cannot create JSON from body")
                #endif
                return
            }
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let task = session.dataTaskWithRequest(request)
            {
                data, response, error in
                if error == nil
                {
                    let responsecode = response as! NSHTTPURLResponse
                    let statuscode = responsecode.statusCode
                    
                    if statuscode == 200
                    {
                        
                        #if DEBUG
                            print("Response: \(response)")
                        #endif
                        callbackAddMultiple(data!,"", statuscode)
                        
                    }
                    else
                    {
                        if data != nil {
                            callbackAddMultiple(data!,"Connection interrupted", statuscode)
                        }
                    }
                }
                else
                {
                    if data != nil  {
                        callbackAddMultiple(data!,error!.localizedDescription, 0)
                    }
                }
            }
            
            task.resume()
        }
            
        else{
            let alert = UIAlertView(title:"Error", message:"No internet connectivity", delegate:self, cancelButtonTitle:"OK")
            alert.show()
        }
        
    }
}
