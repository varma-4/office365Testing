//
//  CustomCheckBoxButton.swift
//  Simplify OR swift
//
//  Created by manikanta on 09/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class CustomCheckBoxButton: UIButton {
    
    // MARK: Constants Declaration
    let checkedImage = UIImage(named: "checkedBoxButton")
    let unCheckedImage = UIImage(named: "uncheckBoxButton")
    
    //bool propety
    @IBInspectable var isChecked:Bool = false {
        didSet {
            self.updateImage()
        }
    }
    
    // MARK: View Life Cycle Methods
    override func awakeFromNib() {
        self.addTarget(self, action: #selector(CustomCheckBoxButton.buttonClicked(_:)), forControlEvents: UIControlEvents.TouchUpInside)
        self.updateImage()
    }
    
    // MARK: User-Defined Functions
    private func updateImage() {
        if isChecked == true {
            self.setImage(checkedImage, forState: .Normal)
        } else {
            self.setImage(unCheckedImage, forState: .Normal)
        }
    }
    
    func buttonClicked(sender:UIButton) {
        if(sender == self) {
            isChecked = !isChecked
            NSNotificationCenter.defaultCenter().postNotificationName("buttonTitleChange", object: nil)
        }
    }
}

