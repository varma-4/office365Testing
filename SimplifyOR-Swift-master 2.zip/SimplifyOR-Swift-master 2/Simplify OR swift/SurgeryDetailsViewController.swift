 //
 //  SurgeryDetailsViewController.swift
 //  Simplify OR swift
 //
 //  Created by Nayana Chikkanayakan Hally Sudarshan on 8/2/16.
 //  Copyright © 2016 Nayana Sudarshan. All rights reserved.
 //
 
 import UIKit
 import CoreData
 
 var gconnectionState = "Connected"
 var gconnectedState = "Connected"
 var gnotConnectedState = "notConnected"
 var didTapDeleteButton = false
 
 class SurgeryDetailsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: Constants Declaration
    let loggedInOrgId = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KLoggedInOrgId) as! String
    let orgId = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KOrgId) as! String
    let alertViewObject = Utility()
    let value = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
    
    // MARK: IBOutlets Declaration
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var rejectMessage: UILabel!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var listTableView: UITableView!
    @IBOutlet weak var detailsTableView: UITableView!
    
    // MARK: Var Properties Declaration
    var isExpanded:Bool = false;
    var constraint : NSLayoutConstraint?
    var status: String?
    var scheduleID: String?
    var consumptionID: String?
    var vendorID: String?
    var result = [AnyObject]()
    var coreDataResult = [AnyObject]()
    var coreDataDeletedResult = [AnyObject]()
    var newResult = [AnyObject]()
    let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let utility = Utility()
    var patientID: String?
    var doctor: String?
    var date: String?
    var time: String?
    var surgery:String?
    var flagTemp:Bool!
    var rConsumptionId: String?
    var contractExpDate: String?
    var itemsArray = [AnyObject]()
    var cIdGlobal: String?
    var networkReachability: Reachability?
    var tempRecord = Item()
    var toDict = [[String:AnyObject]]()
    var isItemValid: NSNumber?
    var isRejectedForReason1: NSNumber?
    var didTapLostInternetSave:Bool = false
    var didTapLostInternetDelete:Bool = false
    var isSubmitEnabled: Bool = false
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        
        super.viewDidLoad()
        addButton.layer.cornerRadius = 5.0
        addButton.layer.masksToBounds = true
        backButton.layer.cornerRadius = 5.0
        backButton.layer.masksToBounds = true
        submitButton.layer.cornerRadius = 5.0
        submitButton.layer.masksToBounds = true
        listTableView.tableFooterView = UIView()
        navigationController?.navigationItem.hidesBackButton = true
        
        for tabelConstraint in view.constraints as [NSLayoutConstraint]  {
            if tabelConstraint.identifier == "$ListTableConstraintIdentifier$" {
                constraint = tabelConstraint
            }
        }
        
        //        let value = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
        
        if value == Constants.kNurse {
            //sharanya
            if status == Constants.kRejected {
                submitButton.setTitle("Record", forState: .Normal)
                addButton.setTitle("Back", forState: .Normal)
            }
            else {
                submitButton.setTitle("Record", forState: .Normal)
                addButton.setTitle("Back", forState: .Normal)
            }
        }
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.networkChange(_:)), name:ReachabilityChangedNotification, object: networkReachability)
        
        do {
            networkReachability = try Reachability.reachabilityForInternetConnection()
            
            try networkReachability?.startNotifier()
        }
        catch {
            print("Network rechability try failed")
        }
        
    }
    
    override func viewWillAppear (animated: Bool) {
        super.viewWillAppear(animated)
        
        let utility = Utility()
        itemsArray = [AnyObject]()
        if didTapSaveButton == true && consumptionID == nil {
            didTapLostInternetSave = true
            didTapSaveButton = false
        }
        if didTapDeleteButton == true && consumptionID == nil {
            didTapLostInternetDelete = true
            didTapDeleteButton = false
        }
        
        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            if status == Constants.kRejected {
                consumptionDetail(scheduleID)
            }
            else {
                createConsumption()
            }
        }
        else {
            //Fetch Data
            if consumptionID != nil {
                let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
                let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                result = results as! [ConsumptionItem]
                listTableView.reloadData()
                updateButtonStatuses()
            }
            else {
                addButton.enabled = false
                submitButton.enabled = false
                let alertController = UIAlertController(title: Constants.errorTitle, message:
                    "Cannot retrive Consumption, Check internet connectivity", preferredStyle: UIAlertControllerStyle.Alert)
                // Create & Add  actions
                let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) {
                    UIAlertAction in
                    self.navigationController?.popViewControllerAnimated(true)
                }
                alertController.addAction(okAction)
                self.presentViewController(alertController, animated: true, completion: nil)
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func networkChange(notification: NSNotification) {
        if let reachability = notification.object as? Reachability {
            let remoteHostStatus: Int = (reachability.currentReachabilityStatus.hashValue)
            
            if  remoteHostStatus != 0 && gconnectionState == gconnectedState {
                gconnectionState = gnotConnectedState
                result = [AnyObject]()
                let obj = CommonManager()
                if didTapDeleteButton {
                    createConsumption()
                    if self.consumptionID != nil {
                        let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
                        let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                        coreDataDeletedResult = results as! [ConsumptionItem]
                        var sub : [String : AnyObject] = [:]
                        var toDeletedDictCoreData = [[String:AnyObject]]()
                        
                        for i in 0..<coreDataDeletedResult.count {
                            let res = coreDataDeletedResult[i] as? ConsumptionItem
                            if res?.itemId != nil {
                                if res?.isItemDeleted == "true" {
                                    sub = ["id":res!.itemId!]
                                    toDeletedDictCoreData.append(sub)
                                }
                            }
                        }
                        
                        if toDeletedDictCoreData.count != 0 {
                            let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                            spinner.center = view.center
                            view.addSubview(spinner)
                            spinner.color = UIColor.blackColor()
                            spinner.startAnimating()
                            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                            obj.deleteLineItems(self.consumptionID!, deltedlineItems: toDeletedDictCoreData, callbackDelete: {(data,error,status,connectivityFlag) in
                                spinner.stopAnimating();
                                spinner.removeFromSuperview()
                                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                                
                                do {
                                    if connectivityFlag == false {
                                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                                    }
                                    else if status == 200
                                    {
                                        didTapDeleteButton = false
                                        self.listTableView.reloadData()
                                    }
                                    else
                                    {
                                        didTapDeleteButton = false
                                        let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                        let parseJSON = json
                                        let  error = parseJSON["message"]
                                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                                    }
                                    
                                }
                                catch{
                                    let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                                }
                                
                            })
                        }
                    }
                }
                if didTapSaveButton {
                    if self.consumptionID != nil {
                        let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
                        let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                        coreDataResult = results as! [ConsumptionItem]
                        var sub : [String : AnyObject] = [:]
                        var toDictCoreData = [[String:AnyObject]]()
                        
                        for i in 0..<coreDataResult.count {
                            let res = coreDataResult[i] as? ConsumptionItem
                            if res?.itemId == nil {
                                sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!]
                                toDictCoreData.append(sub)
                                
                            }
                            else if res?.modifiedTime == "true" {
                                sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!,"id":res!.itemId!]
                                toDictCoreData.append(sub)
                            }
                        }
                        
                        if toDictCoreData.count != 0 {
                            let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                            spinner.center = view.center
                            view.addSubview(spinner)
                            spinner.color = UIColor.blackColor()
                            spinner.startAnimating()
                            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                            obj.addMultipleLineItems(self.consumptionID!, lineItems: toDictCoreData, callbackAddMultiple: {(data,error,status,connectivityFlag) in
                                spinner.stopAnimating();
                                spinner.removeFromSuperview()
                                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                                
                                do {
                                    if connectivityFlag == false {
                                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                                    }
                                    else if status == 200
                                    {
                                        didTapSaveButton = false
                                        didTapUpdateButton = false
                                        self.listTableView.reloadData()
                                    }
                                    else
                                    {
                                        didTapSaveButton = false
                                        didTapUpdateButton = false
                                        let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                        let parseJSON = json
                                        let  error = parseJSON["message"]
                                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                                    }
                                    
                                }
                                catch{
                                    let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                                }
                                
                            })
                        }
                    }
                }
            } else if remoteHostStatus == 0 && gconnectionState == gnotConnectedState {
                gconnectionState = gconnectedState
                if consumptionID != nil {
                    let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
                    let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                    result = results as! [ConsumptionItem]
                    listTableView.reloadData()
                    updateButtonStatuses()
                }
            }
        }
    }

    // MARK: - Table view data source&Delegate Methods
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if tableView == detailsTableView {
            return Constants.expandedCellHeight
        }
        else {
            return Constants.standardCellHeight
        }
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == detailsTableView {
            return Constants.standardCellHeight
        }
        else {
            return 40;
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if tableView == listTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("sectionHeader")! as UITableViewCell
            return cell.contentView
        }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier("expandHeader")! as! HeaderTableViewCell
            
            cell.surgeryDate.text = date
            cell.surgeryTime.text = time
            cell.surgerlyName.text =  surgery
            if isExpanded {
                cell.toggle.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
            }
            else {
                cell.toggle.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
            }
            
            cell.toggle.addTarget(self, action: #selector(SurgeryDetailsViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
            return cell.contentView
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == listTableView {
            let rowsCount: Int = result.count
            if  rowsCount != 0 {
                return result.count
            }
            return rowsCount
        }
        else {
            if isExpanded {
                return 1
            }
            else {
                return 0
            }
        }
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        if tableView == listTableView {
            return true
        }
        else {
            return false
        }
        
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        if editingStyle == .Delete {
            let aItemObj = result[indexPath.row] as? ConsumptionItem
            let itemId = aItemObj!.itemId! as String
            
            let connectivityStatus = utility.hasConnectivity()
            if connectivityStatus {
                let isSucces = utility.deleteFromCoreData(appDelegate.managedObjectContext, Object: result[indexPath.row] as! NSManagedObject)
                if isSucces {
                    deleteLineItem(consumptionID!, itemId:itemId, indexpath: indexPath.row)
                }
            }
            else {
                didTapDeleteButton = true
                let predicate = NSPredicate(format: "itemId == %@", itemId)
                let (_,_) = utility.updateCoreDataWithDeleteStatus(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                self.result.removeAtIndex(indexPath.row)
                self.updateButtonStatuses()
                self.listTableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
            }
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if tableView == listTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("SurgeyTableViewCell") as! SurgeryTableViewCell
            if result.count != 0 {
                if self.isRejectedForReason1 == 0{
                    cell.userInteractionEnabled = false
                } else {
                    let aItem = result[indexPath.row] as? ConsumptionItem
                    
                    if aItem != nil {
                        //ItemNO
                        if aItem?.isChargeNoValid == 0 || aItem?.isChargeNoValid == 2 {
                            var colorToBeUsed = UIColor.blackColor()
                            if aItem?.isChargeNoValid == 0 {
                                colorToBeUsed = UIColor.redColor()
                            }else if aItem?.isChargeNoValid == 1 {
                                colorToBeUsed = UIColor.blackColor()
                            }else if aItem?.isChargeNoValid == 2 {
                                colorToBeUsed = Constants.blueColor
                            }
                            let attributedString = NSMutableAttributedString(string:aItem!.chargeNo!)
                            attributedString.addAttribute(NSForegroundColorAttributeName, value: colorToBeUsed, range: NSMakeRange(0, attributedString.length))
                            cell.itemName.attributedText = attributedString
                            submitButton.enabled = false
                            submitButton.backgroundColor = UIColor.lightGrayColor()
                            addButton.enabled = false
                            addButton.backgroundColor = UIColor.lightGrayColor()
                            isItemValid = aItem?.isChargeNoValid
                            cell.userInteractionEnabled = false
                            
                        }
                        else {
                            cell.itemName.text = aItem!.chargeNo
                            cell.userInteractionEnabled = true
                        }
                        
                        let usedColor = self.getUsedColor(aItem?.isConsumedQtyValid)
                        let wastedColor = self.getUsedColor(aItem?.isRequiredQtyValid)
                        let separatorLineColor = UIColor.blackColor()
                        
                        let separatorString = "|"
                        let separatorAttributedString = NSMutableAttributedString(string:separatorString)
                        separatorAttributedString.addAttribute(NSForegroundColorAttributeName, value: separatorLineColor, range: NSMakeRange(0, separatorAttributedString.length))
                        
                        var usedQuantity:String?
                        var usedAttributedString:NSMutableAttributedString?
                        if aItem?.consumedQty?.stringValue == nil || aItem?.consumedQty?.stringValue == "" {
                            usedQuantity = "-"
                            usedAttributedString = NSMutableAttributedString(string:usedQuantity!)
                            usedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: usedColor, range: NSMakeRange(0, usedAttributedString!.length))
                        }
                        else {
                            usedQuantity = (aItem!.consumedQty?.stringValue)!
                            usedAttributedString = NSMutableAttributedString(string:usedQuantity!)
                            usedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: usedColor, range: NSMakeRange(0, usedAttributedString!.length))
                        }
                        
                        var wastedQuantity:String?
                        var wastedAttributedString:NSMutableAttributedString?
                        if aItem?.requiredQty?.stringValue == nil || aItem?.requiredQty?.stringValue == "" {
                            wastedQuantity = "-"
                            wastedAttributedString = NSMutableAttributedString(string:wastedQuantity!)
                            wastedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: wastedColor, range: NSMakeRange(0, wastedAttributedString!.length))
                        }
                        else {
                            wastedQuantity = aItem?.requiredQty?.stringValue
                            wastedAttributedString = NSMutableAttributedString(string:wastedQuantity!)
                            wastedAttributedString!.addAttribute(NSForegroundColorAttributeName, value: wastedColor, range: NSMakeRange(0, wastedAttributedString!.length))
                        }
                        
                        usedAttributedString?.appendAttributedString(separatorAttributedString)
                        usedAttributedString?.appendAttributedString(wastedAttributedString!)
                        
                        cell.quantityValue.attributedText = usedAttributedString
                        // for Dcode
                        if aItem!.dateCode == "" || aItem!.dateCode == nil {
                            cell.dateStatus.image = UIImage(named:"tick dash")
                        }
                        else if aItem!.isDateValid == 1 {
                            cell.dateStatus.image = UIImage(named:"tick green")
                        }
                        else if aItem!.isDateValid == 0 {
                            cell.dateStatus.image = UIImage(named:"tick red")
                        }
                        else if aItem!.isDateValid == 2 {
                            cell.dateStatus.image = UIImage(named:"tick blue")
                        }
                        else {
                            cell.dateStatus.image = UIImage(named:"tick green")
                        }

                        // for lot
                        if aItem!.lotNo == "" || aItem!.lotNo == nil {
                            cell.lotStatus.image = UIImage(named: "tick dash")
                        }
                        else if aItem!.isLotValid == 1 {
                            cell.lotStatus.image = UIImage(named: "tick green")
                        }
                        else if aItem!.isLotValid == 0 {
                            cell.lotStatus.image = UIImage(named: "tick red")
                        }
                        else if aItem!.isLotValid == 2 {
                            cell.lotStatus.image = UIImage(named: "tick blue")
                        }
                        else {
                            cell.lotStatus.image = UIImage(named: "tick green")
                        }
                        
                    }
                }
            }
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier("detailsCell") as! DetailsTableViewCell
            cell.doctor.text = doctor
            cell.patientID.text = surgery
            cell.contractExp.text = contractExpDate
            return cell
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if submitButton.titleLabel?.text == "Submit" {
            let aItem = result[indexPath.row] as? ConsumptionItem
            if aItem != nil {
                if (aItem?.isConsumedQtyValid == 0 || aItem?.isLotValid == 0 || aItem?.isDateValid == 0 || aItem?.isRequiredQtyValid == 0 || aItem?.isChargeNoValid == 0) || (status != Constants.kRejected){
                    self.performSegueWithIdentifier("toEditFlow", sender: indexPath)
                }
            }
        }
    }
    
    // MARK: User-Defined Functions
    
    func updateButtonStatuses() {
        var dateAndLotFlag:Bool = false
        for item in result {
            let aItem = item as? ConsumptionItem
            if (aItem?.dateCode == "" || aItem?.dateCode == nil) || (aItem?.lotNo == "" || aItem?.lotNo == nil) {
                dateAndLotFlag = true
                break
            }
        }
        
        if status == Constants.kRejected {
            if value == Constants.kVendor {
                if isSubmitEnabled == true {
                    submitButton.enabled = true
                    submitButton.backgroundColor = Constants.orangeColor
                }
                else  {
                    submitButton.enabled = false
                    submitButton.backgroundColor = UIColor.lightGrayColor()
                }
                addButton.enabled = false
                addButton.backgroundColor = UIColor.lightGrayColor()
            }
            else {
                if submitButton.titleLabel?.text == "Record" {
                    submitButton.enabled = true
                    submitButton.backgroundColor = Constants.orangeColor
                }
                else {
                    if isSubmitEnabled == true {
                        submitButton.enabled = true
                        submitButton.backgroundColor = UIColor.orangeColor()
                    }
                    else  {
                        submitButton.enabled = false
                        submitButton.backgroundColor = UIColor.lightGrayColor()
                    }
                }
                if addButton.titleLabel?.text == "Back" {
                    addButton.enabled = true
                    addButton.backgroundColor = Constants.greenColor
                }
                else {
                    addButton.enabled = false
                    addButton.backgroundColor = UIColor.lightGrayColor()
                }
            }
        }
        else {
            if result.count == 0 && submitButton.titleLabel?.text == "Submit"{
                submitButton.enabled = false
                addButton.enabled = true
                submitButton.backgroundColor = UIColor.lightGrayColor()
            }
            else {
                submitButton.enabled = true
                addButton.enabled = true
                submitButton.backgroundColor = Constants.orangeColor
            }
        }
        
        if (result.count > 0 && submitButton.titleLabel?.text == "Submit") {
            if dateAndLotFlag == true {
                submitButton.enabled = false
                submitButton.backgroundColor = UIColor.lightGrayColor()
            }
            else {
                submitButton.enabled = true
                submitButton.backgroundColor = Constants.orangeColor
            }
        }
    }
    
    
    func getUsedColor(isValidField:NSNumber?) -> UIColor {
        if isValidField != nil {
            if isValidField == 0 {
                return UIColor.redColor()
            }
            else if isValidField == 2 {
                return Constants.blueColor
            }
            else {
                return UIColor.blackColor()
            }
        }
        else {
            return UIColor.blackColor()
        }
    }
    
    func expandOrCollapse (sender:UIButton) {
        
        if isExpanded {
            isExpanded = false
            constraint?.constant = Constants.collapsedViewHeight
        }
        else {
            isExpanded = true
            constraint?.constant = Constants.expandViewHeight
        }
        UIView.transitionWithView(detailsTableView, duration: 0.8, options: .TransitionFlipFromTop, animations: {self.detailsTableView.reloadData()
            }, completion: nil)
    }
    
    @IBAction func backButton(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func addButtonTapped(sender: UIButton) {
        if addButton.titleLabel?.text == "Back" {
            self.navigationController?.popViewControllerAnimated(true)
        }
        else if addButton.titleLabel?.text == "Add" {
            performSegueWithIdentifier("toScanning", sender: self)
        }
    }
    
    @IBAction func submitReport(sender: AnyObject) {
        if submitButton.titleLabel?.text == "Record" {
            submitButton.setTitle("Submit", forState: .Normal)
            if status == Constants.kRejected {
                addButton.enabled = false
                addButton.backgroundColor = UIColor.lightGrayColor()
                if isSubmitEnabled == true {
                    submitButton.enabled = true
                    submitButton.backgroundColor = Constants.orangeColor
                }
                else  {
                    submitButton.enabled = false
                    submitButton.backgroundColor = UIColor.lightGrayColor()
                }
            }
            else {
                addButton.enabled = true
                addButton.backgroundColor = Constants.greenColor
            }
            addButton.setTitle("Add", forState: .Normal)
            if result.count == 0 {
                submitButton.enabled = false
                submitButton.backgroundColor = UIColor.lightGrayColor()
            }
        }
        else if submitButton.titleLabel?.text == "Submit" {
            
            let utility = Utility()
            let connectivityStatus = utility.hasConnectivity()
            
            if connectivityStatus {
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = view.center
                view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                let obj = CommonManager()
                obj.submitForReview(consumptionID!, callbackSubmit: {(dataSubmit,errorSubmit,statusSubmit,connectivityFlag) in
                    dispatch_async(dispatch_get_main_queue(), {
                        spinner.stopAnimating();
                        spinner.removeFromSuperview()
                        UIApplication.sharedApplication().endIgnoringInteractionEvents()
                        
                        do{
                            if connectivityFlag == false {
                                self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                            }
                            else if statusSubmit == 200
                            {
                                let message = "\n Awaiting Approval \n" +
                                "This order can be reviewed in \"Completed\" tab"
                                
                                let actionSheet = UIAlertController(title: "Consumption Report Submitted", message: message, preferredStyle: .ActionSheet)
                                let cancel = UIAlertAction(title: "Ok", style: .Cancel, handler: { Void in
                                    
                                    self.navigationController?.popViewControllerAnimated(true)
                                })
                                
                                actionSheet.addAction(cancel)
                                self.presentViewController(actionSheet, animated: true, completion: nil)
                            }
                            else
                            {
                                let json = try NSJSONSerialization.JSONObjectWithData(dataSubmit, options:[])
                                let parseJSON = json
                                let  error = parseJSON["error"]
                                self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)                        }
                        }
                        catch{
                            let jsonStr = NSString(data: dataSubmit, encoding: NSUTF8StringEncoding)
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                        }
                    })
                })
            }
            else {
                self.alertViewObject.showAlertView(Constants.noInternetMessage, alertMessage: "Please submit consumption once internet is available", delegate: self)
            }
        }
    }
    
    private func createConsumptionReport() {
        let utility = Utility()
        let currentTime = utility.getDateTime()
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.createConsumption("consumption", consumptionTime: currentTime, scheduleId: scheduleID!, orgId: loggedInOrgId, vendorId: vendorID!, callback2: {(data2,error2,status2,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if status2 == 200
                    {
                        let json2 = try NSJSONSerialization.JSONObjectWithData(data2, options:[])
                        let parseJSON2 = json2
                        let newConsumptionId = parseJSON2["id"]
                        self.rConsumptionId = newConsumptionId as? String
                        self.consumptionID = self.rConsumptionId
                        if self.submitButton.titleLabel?.text == "Submit" {
                            self.submitButton.enabled = false
                            self.submitButton.backgroundColor = UIColor.lightGrayColor()
                        }
                    }
                    else
                    {
                        let json2 = try NSJSONSerialization.JSONObjectWithData(data2, options:[])
                        let parseJSON2 = json2
                        let  error = parseJSON2["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: data2, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    private func deleteAndSaveConsumptionLostInternetData() {
        let obj = CommonManager()
        if self.consumptionID != nil {
            let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
            let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
            coreDataDeletedResult = results as! [ConsumptionItem]
            var sub : [String : AnyObject] = [:]
            var toDeletedDictCoreData = [[String:AnyObject]]()
            
            for i in 0..<coreDataDeletedResult.count {
                let res = coreDataDeletedResult[i] as? ConsumptionItem
                if res?.itemId != nil {
                    if res?.isItemDeleted == "true" {
                        sub = ["id":res!.itemId!]
                        toDeletedDictCoreData.append(sub)
                    }
                }
            }
            
            if toDeletedDictCoreData.count != 0 {
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = view.center
                view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.deleteLineItems(self.consumptionID!, deltedlineItems: toDeletedDictCoreData, callbackDelete: {(data,error,status,connectivityFlag) in
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        }
                        else if status == 200
                        {
                            self.didTapLostInternetDelete = false
                            self.listTableView.reloadData()
                        }
                        else
                        {
                            self.didTapLostInternetDelete = false
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                        
                    }
                    catch{
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                    
                })
            }
        }
        
        // For Saving
        if self.consumptionID != nil {
            let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
            let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
            coreDataResult = results as! [ConsumptionItem]
            var sub : [String : AnyObject] = [:]
            var toDictCoreData = [[String:AnyObject]]()
            
            for i in 0..<coreDataResult.count {
                let res = coreDataResult[i] as? ConsumptionItem
                if res?.itemId == nil {
                    sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!]
                    toDictCoreData.append(sub)
                    
                }
                else if res?.modifiedTime == "true" {
                    sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!,"id":res!.itemId!]
                    toDictCoreData.append(sub)
                }
            }
            
            if toDictCoreData.count != 0 {
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = view.center
                view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.addMultipleLineItems(self.consumptionID!, lineItems: toDictCoreData, callbackAddMultiple: {(data,error,status,connectivityFlag) in
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        }
                        else if status == 200
                        {
                            self.didTapLostInternetSave = false
                            self.consumptionDetail(self.consumptionID)
                            self.listTableView.reloadData()
                        }
                        else
                        {
                            self.didTapLostInternetSave = false
                            self.consumptionDetail(self.consumptionID)
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                        
                    }
                    catch{
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                    
                })
            }
        }
    }
    
    private func deleteConsumptionOfNoInternetData() {
        let obj = CommonManager()
        if self.consumptionID != nil {
            let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
            let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
            coreDataDeletedResult = results as! [ConsumptionItem]
            var sub : [String : AnyObject] = [:]
            var toDeletedDictCoreData = [[String:AnyObject]]()
            
            for i in 0..<coreDataDeletedResult.count {
                let res = coreDataDeletedResult[i] as? ConsumptionItem
                if res?.itemId != nil {
                    if res?.isItemDeleted == "true" {
                        sub = ["id":res!.itemId!]
                        toDeletedDictCoreData.append(sub)
                    }
                }
            }
            
            if toDeletedDictCoreData.count != 0 {
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = view.center
                view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.deleteLineItems(self.consumptionID!, deltedlineItems: toDeletedDictCoreData, callbackDelete: {(data,error,status,connectivityFlag) in
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        }
                        else if status == 200
                        {
                            self.didTapLostInternetDelete = false
                            self.consumptionDetail(self.consumptionID)
                            self.listTableView.reloadData()
                        }
                        else
                        {
                            self.didTapLostInternetDelete = false
                            self.consumptionDetail(self.consumptionID)
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                        
                    }
                    catch{
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                    
                })
            }
        }
    }
    
    private func saveConsumptionOfNoInternetData() {
        let obj = CommonManager()
        if self.consumptionID != nil {
            let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
            let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
            coreDataResult = results as! [ConsumptionItem]
            var sub : [String : AnyObject] = [:]
            var toDictCoreData = [[String:AnyObject]]()
            
            for i in 0..<coreDataResult.count {
                let res = coreDataResult[i] as? ConsumptionItem
                if res?.itemId == nil {
                    sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!]
                    toDictCoreData.append(sub)
                    
                }
                else if res?.modifiedTime == "true" {
                    sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!,"id":res!.itemId!]
                    toDictCoreData.append(sub)
                }
            }
            
            if toDictCoreData.count != 0 {
                let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                spinner.center = view.center
                view.addSubview(spinner)
                spinner.color = UIColor.blackColor()
                spinner.startAnimating()
                UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                obj.addMultipleLineItems(self.consumptionID!, lineItems: toDictCoreData, callbackAddMultiple: {(data,error,status,connectivityFlag) in
                    spinner.stopAnimating();
                    spinner.removeFromSuperview()
                    UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        }
                        else if status == 200
                        {
                            self.didTapLostInternetSave = false
                            self.consumptionDetail(self.consumptionID)
                            self.listTableView.reloadData()
                        }
                        else
                        {
                            self.didTapLostInternetSave = false
                            self.consumptionDetail(self.consumptionID)
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["message"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                        
                    }
                    catch{
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                    
                })
            }
        }
        
    }
    
    private func createConsumption(){
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        //Returns a consumption object created against given schedule id
        obj.getConsumptionDetail("schedule/\(scheduleID!)/consumption", callbackDetail: {(dataDetail,errorDetail,statusDetail,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusDetail == 200
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataDetail, options:[])
                        let parseJSON = json
                        let cId = parseJSON["id"]
                        self.consumptionID = cId!! as? String
                        if self.didTapLostInternetSave == true && self.didTapLostInternetDelete == false {
                            self.saveConsumptionOfNoInternetData()
                        }
                        else if self.didTapLostInternetDelete == true && self.didTapLostInternetSave == false {
                            self.deleteConsumptionOfNoInternetData()
                        }
                        else if self.didTapLostInternetDelete == true && self.didTapLostInternetSave == true {
                            self.deleteAndSaveConsumptionLostInternetData()
                        }
                        else{
                            self.consumptionDetail(cId)
                        }
                    }
                    else {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataDetail, options:[])
                        let parseJSON = json
                        _ = parseJSON["error"]
                        self.createConsumptionReport()
                    }
                }
                catch{
                    _ = NSString(data: dataDetail, encoding: NSUTF8StringEncoding)
                    
                    self.createConsumptionReport()
                }
            })
        })
    }
    
    private func consumptionDetail(conId:AnyObject?) {
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = self.view.center
        self.view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        consumptionID = conId as? String
        obj.getSingleConsumptionDetail("consumption/\(consumptionID!)", callback: {(data,error,status,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if status == 200
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                        let parseJSON = json
                        let details = parseJSON["details"]
                        let JSON = details as! NSArray
                        self.isRejectedForReason1 = parseJSON["isRejectedForReason1"] as? NSNumber
                        if self.isRejectedForReason1 == 0 {
                            self.rejectMessage.hidden = false;
                            self.submitButton.enabled = false
                            self.submitButton.backgroundColor = UIColor.lightGrayColor()
                        } else {
                            self.rejectMessage.hidden = true;
                        }
                        
                        self.itemsArray = [AnyObject]()
                        
                        for aSch in JSON {
                            let obj = aSch as! NSDictionary
                            let aItem = Item()
                            aItem.itemNo = obj["itemNo"] as? String
                            aItem.dateCode = obj["dateCode"] as? String
                            aItem.lotNumber = obj["lotNumber"] as? String
                            aItem.itemId = obj["id"] as? String
                            aItem.used = obj["consumedQty"] as? NSNumber
                            aItem.wasted = obj["scrappedQty"] as? NSNumber
                            aItem.itemDescription = obj["itemDescription"] as? String
                            aItem.isDateCodeValid = obj["isDateCodeValid"] as? NSNumber
                            aItem.isLotValid = obj["isLotValid"] as? NSNumber
                            aItem.isConsumedQtyValid = obj["isConsumedQtyValid"] as? NSNumber
                            aItem.isScrappedQtyValid = obj["isScrappedQtyValid"] as? NSNumber
                            aItem.isItemValid = obj["isItemValid"] as? NSNumber
                            
                            self.itemsArray.append(aItem)
                        }
                        
                        let utility = Utility()
                        let predicate = NSPredicate(format: "consumptionId == %@", self.consumptionID!)
                        
                        let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: self.appDelegate.managedObjectContext)
                        
                        
                        self.newResult = results as! [ConsumptionItem]
                        
                        for  i1 in 0..<self.newResult.count {
                            let atem = self.newResult[i1] as? ConsumptionItem
                            _ = utility.deleteFromCoreData(self.appDelegate.managedObjectContext, Object: atem!)
                        }
                        
                        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
                        // Create Entity
                        let entity = NSEntityDescription.entityForName("ConsumptionItem", inManagedObjectContext: appDelegate.managedObjectContext)
                        for i2 in 0..<self.itemsArray.count{
                            
                            // Initialize Record
                            let consumptionItem = ConsumptionItem(entity: entity!, insertIntoManagedObjectContext: appDelegate.managedObjectContext)
                            let aConsumption = self.itemsArray[i2] as? Item
                            //record 1
                            consumptionItem.consumptionId = self.consumptionID
                            consumptionItem.itemId = aConsumption?.itemId
                            consumptionItem.lotNo = aConsumption?.lotNumber
                            consumptionItem.dateCode = aConsumption?.dateCode
                            consumptionItem.chargeNo = aConsumption?.itemNo
                            consumptionItem.consumedQty = aConsumption?.used
                            consumptionItem.requiredQty = aConsumption?.wasted
                            consumptionItem.isChargeNoValid = aConsumption?.isItemValid
                            consumptionItem.isDateValid = aConsumption?.isDateCodeValid
                            consumptionItem.isLotValid = aConsumption?.isLotValid
                            consumptionItem.isConsumedQtyValid = aConsumption?.isConsumedQtyValid
                            consumptionItem.isRequiredQtyValid = aConsumption?.isScrappedQtyValid
                            
                        }
                        _ = utility.addOrUpdateCoreData(self.appDelegate.managedObjectContext)
                        let (resultsCoreData,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: self.appDelegate.managedObjectContext)
                        self.result = resultsCoreData as! [ConsumptionItem]
                        for i2 in 0..<self.result.count {
                            let aItem = self.result[i2] as? ConsumptionItem
                            
                            if aItem?.isChargeNoValid == 0 ||  aItem?.isRequiredQtyValid == 0 || aItem?.isConsumedQtyValid == 0 || aItem?.isDateValid == 0 || aItem?.isLotValid == 0 || self.isRejectedForReason1 == 0{
                                self.isSubmitEnabled = false
                                break
                            }
                            else {
                                self.isSubmitEnabled = true
                            }
                        }
                        self.listTableView.reloadData()
                        self.updateButtonStatuses()
                    }
                    else
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                        let parseJSON = json
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
        
    }
    
    // MARK: - Navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "toScanning" {
            let scanController = segue.destinationViewController as! ItemsAdditionViewController
            scanController.consumptionID = consumptionID
        }
        else if segue.identifier == "toEditFlow" {
            let scanController = segue.destinationViewController as! ItemsAdditionViewController
            scanController.consumptionID = consumptionID
            scanController.record = result[(sender?.row)!]
        }
    }
    
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func deleteLineItem(consumptionId:String, itemId:String, indexpath:Int) {
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = self.view.center
        self.view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.deleteLineItem(consumptionId, itemId:itemId, callbackDelete: {(data,error,status, connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        
                    }
                    else if status == 200 {
                        didTapDeleteButton = false
                        self.result.removeAtIndex(indexpath)
                        self.updateButtonStatuses()
                        self.listTableView.deleteRowsAtIndexPaths([NSIndexPath(forRow: indexpath, inSection: 0)], withRowAnimation: .Fade)
                    }
                    else {
                        let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                        let parseJSON = json
                        didTapDeleteButton = false
                        let  error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch{
                    let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
 }
