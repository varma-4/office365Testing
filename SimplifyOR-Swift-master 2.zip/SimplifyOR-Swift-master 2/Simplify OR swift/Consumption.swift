//
//  Consumption.swift
//  Simplify OR swift
//
//  Created by Arunava Sanyal on 17/08/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import Foundation
import CoreData


class Consumption: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}

extension Consumption {
    
    @NSManaged var consumptionId: String?
    @NSManaged var consumptionTime: NSDate?
    @NSManaged var createdTime: NSDate?
    @NSManaged var doctorId: String?
    @NSManaged var locationOrgId: String?
    @NSManaged var modifiedTime: NSDate?
    @NSManaged var orInCharge: String?
    @NSManaged var patientId: String?
    @NSManaged var rejectRemarks: String?
    @NSManaged var statusCode: String?
    @NSManaged var statusTime: NSDate?
    @NSManaged var surgeryType: String?
    @NSManaged var userId: String?
    @NSManaged var version: NSNumber?
    @NSManaged var consumptionItems: NSManagedObject?
    
}
