//
//  SettingTableViewCell.swift
//  Simplify OR swift
//
//  Created by CHDSEZ301972DADM on 16/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class SettingTableViewCell: UITableViewCell {

    @IBOutlet weak var imageAttached: UIImageView!
    @IBOutlet weak var hospitalNames: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
