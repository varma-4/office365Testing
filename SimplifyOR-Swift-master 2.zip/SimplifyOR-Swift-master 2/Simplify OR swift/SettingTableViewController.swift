//
//  SettingTableViewController.swift
//  Simplify OR swift
//
//  Created by CHDSEZ301972DADM on 18/09/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

@objc protocol CurrencySelectedDelegate {
    func currencySelected(currName: NSInteger,hospitalName:NSString)
}

@objc protocol UpdatePrefDelegate  {
    func updateLoggedinSession()
}

class SettingTableViewController: UITableViewController {
    
    // MARK: IBOutlets Declaration
    @IBOutlet var logoutAndHospitalNamesTableView: UITableView!
    let alertViewObject = Utility()
    let loggedInOrgName = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital)
    
    // MARK: Var Properties Declaration
    private var hArray = ["Indian River", "South Lake Center", "Aero Hospital", "Aventura", "Baptist Hospital", "Cape Coral","Florida Med Center"]
    var index = NSInteger()
    var selectedIndex : NSInteger!
    let vc = ScheduleViewController()
    var showHospitalNamesFlag = false
    var widthOfTableView:CGFloat!
    var storedIndexPath:NSIndexPath!
    weak var delegate: CurrencySelectedDelegate?
    weak var prefUpdateDelegate: UpdatePrefDelegate?
    var userId = String()
    var hListArray = [AssociatedOrg]()
    
    // MARK: View Life Cycle Methods
    override func viewDidLoad() {
        
        setWidthAndHeightOfTableView()
        super.viewDidLoad()
        userId = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KUserId) as! String
        let loggedInOrgName = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital)
        hArray = [loggedInOrgName! as! String, "South Lake Center", "Aero Hospital", "Aventura", "Baptist Hospital", "Cape Coral","Florida Med Center"]

        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = tableView.center
        tableView.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        obj.getAssociatedOrgs(userId, callbackOrgs:{(dataOrgs,errorOrgs,statusOrgs,connectivityFlag) in
            dispatch_async(dispatch_get_main_queue(), {
            spinner.stopAnimating();
            spinner.removeFromSuperview()
            UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do {
                    if connectivityFlag == false {
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                    }
                    else if statusOrgs == 200 {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataOrgs, options:[])
                        let parseJSON = json
                        let JSON = parseJSON as! NSArray
                        
                        for aOrg in JSON {
                            let obj = aOrg as! NSDictionary
                            let  org = AssociatedOrg()
                           
                            org.name = obj["name"] as? String
                            org.orgId = obj["id"] as? String

                            self.hListArray.append(org)
                        }
                        
                    }
                    else {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataOrgs, options:[])
                        let parseJSON = json
                        let error = parseJSON["error"]
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                    }
                }
                catch {
                    let jsonStr = NSString(data: dataOrgs, encoding: NSUTF8StringEncoding)
                    self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                }
            })
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: User-Defined Functions
    private func setWidthAndHeightOfTableView() {
        
        logoutAndHospitalNamesTableView.scrollEnabled = false
        var  largestLabelWidth:CGFloat = 0
        var  popoverWidth:CGFloat = 0
        
        for i in 0...(hArray.count-1){
            let name = hArray[i]
            let myString: NSString = name as NSString
            let labelSize: CGSize = myString.sizeWithAttributes([NSFontAttributeName: UIFont.systemFontOfSize(20.0)])
            if (labelSize.width > largestLabelWidth) {
                largestLabelWidth = labelSize.width;
            }
        }
        
        let totalRowsHeight:NSInteger!
        
        if showHospitalNamesFlag == true {
         totalRowsHeight = hListArray.count * 40
        }
        else {
            totalRowsHeight = 2 * 40
        }
        
        popoverWidth = largestLabelWidth + 80;
        self.preferredContentSize =  CGSizeMake(popoverWidth, CGFloat(totalRowsHeight))
        widthOfTableView = popoverWidth
        logoutAndHospitalNamesTableView.tableFooterView = UIView()
    }

    private func changeHeightOfTableView() {
        
        let totalRowsHeight:NSInteger!
        if showHospitalNamesFlag == true {
             totalRowsHeight = hListArray.count * 40
        }
        else {
            totalRowsHeight = 80
        }
        self.preferredContentSize =  CGSizeMake(widthOfTableView, CGFloat(totalRowsHeight))
        logoutAndHospitalNamesTableView.tableFooterView = UIView()
        
    }

    // MARK: - Table view data source
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 40
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if showHospitalNamesFlag == true{
            return hListArray.count
        }
        else{
            return 2
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("settingBtnCell")! as! SettingTableViewCell
        if showHospitalNamesFlag == true {
            cell.accessoryType = UITableViewCellAccessoryType.None
            cell.selectionStyle = UITableViewCellSelectionStyle.None
            
            if ((indexPath.row == selectedIndex) && (index == 0)) {
                cell.hospitalNames.textColor = UIColor.orangeColor()
                cell.imageAttached.image = UIImage(named:"tick green")
            }
            else {
                cell.hospitalNames.textColor = UIColor.blackColor()
                cell.imageAttached.image = nil
            }
            if selectedIndex == indexPath.row
            {
                storedIndexPath = indexPath
                cell.hospitalNames.textColor = UIColor.orangeColor()
                cell.imageAttached.image = UIImage(named:"tick green")
            }
            
            cell.hospitalNames.text = hListArray[indexPath.row].name
        }
        else {
            //Loaded for FirstTime Show Logout Button changed here..
            if selectedIndex == -1 && indexPath.row == 0{
                self.selectedIndex = indexPath.row
                delegate?.currencySelected(indexPath.row,hospitalName: self.hArray[indexPath.row])
                cell.hospitalNames.text = hArray[indexPath.row]
                cell.hospitalNames.textColor = UIColor.orangeColor()
                cell.imageAttached.image = UIImage(named: "tick green")
            }
            else if selectedIndex != -1 && indexPath.row == 0{
                cell.hospitalNames.text = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KDHospital) as? String
                cell.hospitalNames.textColor = UIColor.orangeColor()
                cell.imageAttached.image = UIImage(named: "tick green")
            }
            else if indexPath.row == 1 && showHospitalNamesFlag == false{
                cell.hospitalNames.text = "Logout"
                cell.imageAttached.image = UIImage(named: "logout")
            }
            else{
                cell.hospitalNames.text = hArray[indexPath.row]
                cell.hospitalNames.textColor = UIColor.blackColor()
                cell.imageAttached.image = nil
            }
            if indexPath.row == 0 {
                cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
            }
        }
        return cell
    }

    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        delegate?.currencySelected(indexPath.row,hospitalName: self.hArray[indexPath.row])
        
        if index == 0 {
                    index = 1
        }
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! SettingTableViewCell
        if cell.hospitalNames.text == "Logout" {
            let storage = NSHTTPCookieStorage.sharedHTTPCookieStorage()
            for cookie in storage.cookies! {
                storage.deleteCookie(cookie)
            }
            NSUserDefaults.standardUserDefaults().setObject(nil, forKey: Constants.kCookie)
            NSUserDefaults.standardUserDefaults().synchronize()
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let loginPage = storyboard.instantiateViewControllerWithIdentifier("loginVC")
            let appDelegate  = UIApplication.sharedApplication().delegate as! AppDelegate
            appDelegate.window?.rootViewController = loginPage
        }
        else if (indexPath.row == 0 || selectedIndex == -1) && showHospitalNamesFlag == false{
            showHospitalNamesFlag = true
            changeHeightOfTableView()
            logoutAndHospitalNamesTableView.reloadData()
        }
        else {
            if selectedIndex != -1 {
            let cell1 = tableView.cellForRowAtIndexPath(storedIndexPath) as! SettingTableViewCell
            cell1.hospitalNames.textColor = UIColor.blackColor()
            cell1.imageAttached.image = nil
            }
            cell.hospitalNames.textColor = UIColor.orangeColor()
            cell.imageAttached.image = UIImage(named:"tick green")
            let obj = CommonManager()
            let orgId = hListArray[indexPath.row].orgId
            let spinner = UIActivityIndicatorView(activityIndicatorStyle:.White)
            spinner.center = CGPointMake(tableView.frame.size.width/2, tableView.frame.size.height/2 - 40)
            tableView.addSubview(spinner)
            spinner.color = UIColor.blackColor()
            spinner.startAnimating()
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
            obj.updatePreferences(orgId!, callback: {(data,error,status,connectivityFlag) in
                dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    do {
                        if connectivityFlag == false {
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: Constants.noInternetMessage, delegate: self)
                        }
                        else if status == 200 {
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let updatedLoggedInOrgName = parseJSON["loggedInOrgName"]
                            let userId = parseJSON["userId"]
                            NSUserDefaults.standardUserDefaults().setObject(updatedLoggedInOrgName, forKey: Constants.KDHospital)
                            NSUserDefaults.standardUserDefaults().synchronize()
                            NSUserDefaults.standardUserDefaults().setObject(userId, forKey: Constants.KUserId)
                            NSUserDefaults.standardUserDefaults().synchronize()
                            self.prefUpdateDelegate?.updateLoggedinSession()
                            self.dismissViewControllerAnimated(true, completion: nil)
                        }
                        else
                        {
                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                            let parseJSON = json
                            let  error = parseJSON["error"]
                            self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (error as? String)!, delegate: self)
                        }
                    }
                    catch {
                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                        self.alertViewObject.showAlertView(Constants.errorTitle, alertMessage: (jsonStr as? String)!, delegate: self)
                    }
                })
            })
        }
    }
    
    override func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = tableView.cellForRowAtIndexPath(indexPath) as! SettingTableViewCell
        cell.imageAttached.image = nil
        cell.hospitalNames.textColor = UIColor.blackColor()
    }
    
}
