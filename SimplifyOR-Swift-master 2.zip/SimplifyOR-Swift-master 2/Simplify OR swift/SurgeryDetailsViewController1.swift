//
//  SurgeryDetailsViewController.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/2/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit
import CoreData
var gconnectionState = "Connected"
var gconnectedState = "Connected"
var gnotConnectedState = "notConnected"

class SurgeryDetailsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var rejectMessage: UILabel!
    var value: String?
    var isExpanded:Bool = false;
    var constraint : NSLayoutConstraint?
    var status: String?
    var scheduleID: String?
    var consumptionID: String?
    var result = [AnyObject]()
    var coreDataResult = [AnyObject]()
    var newResult = [AnyObject]()
    let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    let utility = Utility()
    var patientID: String?
    var doctor: String?
    var date: String?
    var time: String?
    var surgery:String?
    var flagTemp:Bool!
    var rConsumptionId: String?
    var contractExpDate: String?
    let loggedInOrgId = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KLoggedInOrgId) as! String
    let orgId = NSUserDefaults.standardUserDefaults().valueForKey(Constants.KOrgId) as! String
    var itemsArray = [AnyObject]()
    var cIdGlobal: String?
    var networkReachability: Reachability?

    var tempRecord = Item()
    var toDict = [[String:AnyObject]]()

    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var listTableView: UITableView!
    @IBOutlet weak var detailsTableView: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addButton.layer.cornerRadius = 5.0
        addButton.layer.masksToBounds = true
        backButton.layer.cornerRadius = 5.0
        backButton.layer.masksToBounds = true
        submitButton.layer.cornerRadius = 5.0
        submitButton.layer.masksToBounds = true
        listTableView.tableFooterView = UIView()
        navigationController?.navigationItem.hidesBackButton = true
        
        for tabelConstraint in view.constraints as [NSLayoutConstraint]  {
            if tabelConstraint.identifier == "$ListTableConstraintIdentifier$" {
                constraint = tabelConstraint
            }
        }
        
        let value = NSUserDefaults.standardUserDefaults().valueForKey(Constants.kUser) as! String
        
        if value == Constants.kNurse {
            if status == Constants.kRejected {
                backButton.hidden = false
                submitButton.hidden = true
                addButton.hidden = true
            }
            else {
                submitButton.setTitle("Record", forState: .Normal)
                addButton.setTitle("Back", forState: .Normal)
            }
        }

        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.networkChange(_:)), name:ReachabilityChangedNotification, object: networkReachability)
        do {
            networkReachability = try Reachability.reachabilityForInternetConnection()
            
            try networkReachability?.startNotifier()
        }
        catch {
            print("Network rechability try failed")
        }

    }

    func networkChange(notification: NSNotification) {
            if let reachability = notification.object as? Reachability {
            let remoteHostStatus: Int = (reachability.currentReachabilityStatus.hashValue)
            
            if  remoteHostStatus != 0 && gconnectionState == gconnectedState {
                
                gconnectionState = gnotConnectedState
                print("State Changed  Connected")
                result = [AnyObject]()
                if didTapSaveButton{
                    createConsumption()
                    let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
                    let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                    coreDataResult = results as! [ConsumptionItem]

                    var sub : [String : AnyObject] = [:]
                    var toDictCoreData = [[String:AnyObject]]()
                    for i in 0..<coreDataResult.count
                    {
                        let res = coreDataResult[i] as? ConsumptionItem
                        if res?.itemId == nil {
                            sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!]
                            toDictCoreData.append(sub)

                        }
                        else if res?.modifiedTime == "true"{
                            sub = ["consumedQty":res!.consumedQty!,"dateCode":res!.dateCode!,"itemNo":"\(res!.chargeNo!)","lotNumber":"\(res!.lotNo!)","scrappedQty":res!.requiredQty!,"id":res!.itemId!]
                            toDictCoreData.append(sub)

                        }
                    }
                    let obj = CommonManager()
                    if toDictCoreData.count != 0 {
                        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                        spinner.center = view.center
                        view.addSubview(spinner)
                        spinner.color = UIColor.blackColor()
                        spinner.startAnimating()
                        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                        obj.addMultipleLineItems(self.consumptionID!, lineItems: toDictCoreData, callbackAddMultiple: {(data,error,status) in
                            spinner.stopAnimating();
                            spinner.removeFromSuperview()
                            UIApplication.sharedApplication().endIgnoringInteractionEvents()
                                    do{
                                        if status == 200
                                        {
                                            print("success for multiple")
                                            didTapSaveButton = false
                                            didTapUpdateButton = false
                                            self.listTableView.reloadData()
                                        }
                                        else
                                        {
                                            let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                            let parseJSON = json
                                            let  error = parseJSON["message"]
                                                                                        
                                            let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                                            alert.show()
                                        }
                                        
                                    }
                                    catch{
                                        let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                                        let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                                        alert.show()
                                    }
                                    
                                })
                            }
                        }
                
            } else if remoteHostStatus == 0 && gconnectionState == gnotConnectedState{
                
                gconnectionState = gconnectedState
                
                let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
                let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
                result = results as! [ConsumptionItem]

                listTableView.reloadData()
                updateButtonStatuses()

            }
            
        }
    }

    
    override func viewWillAppear (animated: Bool) {
        super.viewWillAppear(animated)
        
        let utility = Utility()
        itemsArray = [AnyObject]()

        let connectivityStatus = utility.hasConnectivity()
        if connectivityStatus {
            createConsumption()
        }
        else {
        //Fetch Data
            let predicate = NSPredicate(format: "consumptionId == %@", consumptionID!)
            let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: appDelegate.managedObjectContext)
            result = results as! [ConsumptionItem]
            listTableView.reloadData()
            updateButtonStatuses()
        }
    }
    
    
    
    func updateButtonStatuses() {
        
        if status == Constants.kRejected {
            
            rejectMessage.hidden = false;
            submitButton.enabled = false
            submitButton.backgroundColor = UIColor.lightGrayColor()
            addButton.enabled = false
            addButton.backgroundColor = UIColor.lightGrayColor()
        }
        else {
            
            // Changing here
            if result.count == 0 && submitButton.titleLabel?.text == "Submit"{
                
                submitButton.enabled = false
                submitButton.backgroundColor = UIColor.lightGrayColor()
            }
                
            else {
                submitButton.enabled = true
                submitButton.backgroundColor = Constants.orangeColor
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if tableView == detailsTableView {
            return Constants.expandedCellHeight
        }
        else {
            return Constants.standardCellHeight
        }
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == detailsTableView {
            return Constants.standardCellHeight
        }
        else {
            return 40;
        }
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if tableView == listTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("sectionHeader")! as UITableViewCell
            return cell.contentView
        }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier("expandHeader")! as! HeaderTableViewCell
            
            cell.surgeryDate.text = date
            cell.surgeryTime.text = time
            cell.surgerlyName.text =  surgery
            if isExpanded {
                cell.toggle.setImage(UIImage(named: "arrow collapse.png"), forState: .Normal)
            }
            else {
                cell.toggle.setImage(UIImage(named: "arrow expanded.png"), forState: .Normal)
            }
            
            cell.toggle.addTarget(self, action: #selector(SurgeryDetailsViewController.expandOrCollapse(_:)), forControlEvents: .TouchUpInside)
            return cell.contentView
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView == listTableView {
            return result.count
        }
        else {
            if isExpanded {
                return 1
            }
            else {
                return 0
            }
        }
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        if tableView == listTableView {
            return false
        }
        else {
            return false
        }
        
    }
    
//    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
//        
//        if editingStyle == .Delete {
//                        let isSucces = utility.deleteFromCoreData(appDelegate.managedObjectContext, Object: result[indexPath.row] as! NSManagedObject)
//                        if isSucces {
//                            result.removeAtIndex(indexPath.row)
//                            updateButtonStatuses()
//                            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
//                        }
//                    }
//    }
    
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        if tableView.editing {
            return .None
        }
        
        return .None
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if tableView == listTableView {
            let cell = tableView.dequeueReusableCellWithIdentifier("SurgeyTableViewCell") as! SurgeryTableViewCell
         
            let aItem = result[indexPath.row] as? ConsumptionItem

            if aItem != nil {
            cell.itemName.text = aItem!.chargeNo
            
            let used = aItem!.consumedQty
            let wasted = aItem!.requiredQty
            print(used)
            print(wasted)
            if (wasted != nil)
            {
                let quantity = (aItem!.consumedQty?.stringValue)! + "|" + (aItem!.requiredQty?.stringValue)!
                cell.quantityValue.text = quantity
            }
            
            // For Dcode and Lot Code
            let dateCode = aItem!.dateCode
            print(dateCode)
            if aItem!.dateCode == nil{
                cell.dateStatus.image = UIImage(named:"tick dash")
            }
            else{
                cell.dateStatus.image = UIImage(named:"tick green")
            }
            
            if aItem!.lotNo == nil{
                cell.lotStatus.image = UIImage(named: "tick dash")
            }
            else{
                cell.lotStatus.image = UIImage(named: "tick green")
              }
            }
            return cell
            
        }
        else {
            let cell = tableView.dequeueReusableCellWithIdentifier("detailsCell") as! DetailsTableViewCell
            cell.doctor.text = doctor
            cell.patientID.text = patientID
            cell.contractExp.text = contractExpDate
            return cell
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if submitButton.titleLabel?.text == "Submit" {
            self.performSegueWithIdentifier("toEditFlow", sender: indexPath)
        }
        
    }
    
    func expandOrCollapse (sender:UIButton) {
        
        if isExpanded {
            isExpanded = false
            constraint?.constant = Constants.collapsedViewHeight
        }
        else {
            isExpanded = true
            constraint?.constant = Constants.expandViewHeight
        }
        
        UIView.transitionWithView(detailsTableView, duration: 0.8, options: .TransitionFlipFromTop, animations: {self.detailsTableView.reloadData()
            }, completion: nil)
    }
    
    @IBAction func backButton(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func addButtonTapped(sender: UIButton) {
        if addButton.titleLabel?.text == "Back" {
            self.navigationController?.popViewControllerAnimated(true)
        }
        else if addButton.titleLabel?.text == "Add" {
            performSegueWithIdentifier("toScanning", sender: self)
        }
    }
    
    @IBAction func submitReport(sender: AnyObject) {
        if submitButton.titleLabel?.text == "Record" {
            submitButton.setTitle("Submit", forState: .Normal)
            addButton.setTitle("Add", forState: .Normal)
            
            if result.count == 0 {
                submitButton.enabled = false
                submitButton.backgroundColor = UIColor.lightGrayColor()
            }
        }
        else if submitButton.titleLabel?.text == "Submit" {
            
            let utility = Utility()
            
            let connectivityStatus = utility.hasConnectivity()
            
            if connectivityStatus {
            let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
            spinner.center = view.center
            view.addSubview(spinner)
            spinner.color = UIColor.blackColor()
            spinner.startAnimating()
            UIApplication.sharedApplication().beginIgnoringInteractionEvents()
            let obj = CommonManager()
            obj.submitForReview(consumptionID!, callbackSubmit: {(dataSubmit,errorSubmit,statusSubmit) in
                dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                    
                    do{
                        
                        if statusSubmit == 200
                        {
                            let message = "\n Awaiting Approval \n" +
                            "This order can be reviewed in \"Completed\" tab"
                            
                            let actionSheet = UIAlertController(title: "Consumption Report Submitted", message: message, preferredStyle: .ActionSheet)
                            let cancel = UIAlertAction(title: "Ok", style: .Cancel, handler: { Void in
                                
                                self.navigationController?.popViewControllerAnimated(true)
                            })
                            
                            actionSheet.addAction(cancel)
                            self.presentViewController(actionSheet, animated: true, completion: nil)
                        }
                        else
                        {
                            let json = try NSJSONSerialization.JSONObjectWithData(dataSubmit, options:[])
                            let parseJSON = json
                            let  error = parseJSON["error"]
                            let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                            alert.show()
                        }
                        
                        
                    }
                    catch{
                        let jsonStr = NSString(data: dataSubmit, encoding: NSUTF8StringEncoding)
                        let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                })
            })
            }
            else {
                let alert = UIAlertView(title:"No internet connectivity", message:"Please submit consumption once internet is available", delegate:nil, cancelButtonTitle:"OK")
                alert.show()
            }

            
        }
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "toScanning" {
            let scanController = segue.destinationViewController as! ItemsAdditionViewController
            scanController.consumptionID = consumptionID
        }
        else if segue.identifier == "toEditFlow" {
            let scanController = segue.destinationViewController as! ItemsAdditionViewController
            scanController.consumptionID = consumptionID
            scanController.record = result[(sender?.row)!]
        }
    }
    
    @IBAction func home(sender: AnyObject) {
        self.navigationController?.popToRootViewControllerAnimated(true)
    }
    
    @IBAction func backBarButtonPressed(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func createConsumptionReport() {
        let utility = Utility()
        let currentTime = utility.getDateTime()
        let obj = CommonManager()
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        obj.createConsumption("consumption", consumptionTime: currentTime, scheduleId: scheduleID!, orgId: loggedInOrgId, vendorId: orgId, callback2: {(data2,error2,status2) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    let json2 = try NSJSONSerialization.JSONObjectWithData(data2, options:[])
                    let parseJSON2 = json2
                    if status2 == 200
                    {
                        let newConsumptionId = parseJSON2["id"]
                        self.rConsumptionId = newConsumptionId as? String
                        
                        self.consumptionID = self.rConsumptionId
                        self.submitButton.enabled = false
                        self.submitButton.backgroundColor = UIColor.lightGrayColor()

                    }
                    else
                    {
                        let  error = parseJSON2["error"]
                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                        alert.show()
                    }
                    
                    
                }
                catch{
                    let jsonStr = NSString(data: data2, encoding: NSUTF8StringEncoding)
                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                    alert.show()
                }
                
            })
        })
        
    }
    
    func createConsumption(){
        
        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
        spinner.center = view.center
        view.addSubview(spinner)
        spinner.color = UIColor.blackColor()
        spinner.startAnimating()
        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
        let obj = CommonManager()
        
        //Returns a consumption object created against given schedule id
        obj.getConsumptionDetail("schedule/\(scheduleID!)/consumption", callbackDetail: {(dataDetail,errorDetail,statusDetail) in
            dispatch_async(dispatch_get_main_queue(), {
                spinner.stopAnimating();
                spinner.removeFromSuperview()
                UIApplication.sharedApplication().endIgnoringInteractionEvents()
                
                do{
                    if statusDetail == 200
                    {
                        let json = try NSJSONSerialization.JSONObjectWithData(dataDetail, options:[])
                        let parseJSON = json

                        
                        let cId = parseJSON["id"]
                        self.consumptionID = cId!! as? String
                        
                        let spinner = UIActivityIndicatorView(activityIndicatorStyle: .WhiteLarge)
                        spinner.center = self.view.center
                        self.view.addSubview(spinner)
                        spinner.color = UIColor.blackColor()
                        spinner.startAnimating()
                        UIApplication.sharedApplication().beginIgnoringInteractionEvents()
                        obj.getSingleConsumptionDetail("consumption/\(cId!!)", callback: {(data,error,status) in
                            dispatch_async(dispatch_get_main_queue(), {
                            spinner.stopAnimating();
                            spinner.removeFromSuperview()
                            UIApplication.sharedApplication().endIgnoringInteractionEvents()
                                
                                do{
                                    let json = try NSJSONSerialization.JSONObjectWithData(data, options:[])
                                    let parseJSON = json
                                    if status == 200
                                    {
                                        let details = parseJSON["details"]
                                        
                                        let JSON = details as! NSArray
                                        print(JSON)
                                        
                                        self.itemsArray = [AnyObject]()
                                        
                                        for aSch in JSON{
                                            let obj = aSch as! NSDictionary
                                            let aItem = Item()
                                            aItem.itemNo = obj["itemNo"] as? String
                                            aItem.dateCode = obj["dateCode"] as? String
                                            aItem.lotNumber = obj["lotNumber"] as? String
                                            aItem.itemId = obj["id"] as? String
                                            aItem.used = obj["consumedQty"] as? NSNumber
                                            aItem.wasted = obj["scrappedQty"] as? NSNumber
                                            
                                            self.itemsArray.append(aItem)
                                        }
                                        
                                        let utility = Utility()
                                        
                                        let predicate = NSPredicate(format: "consumptionId == %@", self.consumptionID!)
                                        let (results,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: self.appDelegate.managedObjectContext)
                                        self.newResult = results as! [ConsumptionItem]
                                        
                                        for  i1 in 0..<self.newResult.count{
                                        let atem = self.newResult[i1] as? ConsumptionItem
    
                                        _ = utility.deleteFromCoreData(self.appDelegate.managedObjectContext, Object: atem!)
                                        }
                                        
                                        
                                        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
                                        // Create Entity
                                        let entity = NSEntityDescription.entityForName("ConsumptionItem", inManagedObjectContext: appDelegate.managedObjectContext)
                                        for i2 in 0..<self.itemsArray.count{
                                        
                                        // Initialize Record
                                        let consumptionItem = ConsumptionItem(entity: entity!, insertIntoManagedObjectContext: appDelegate.managedObjectContext)
                                        
                                        let aConsumption = self.itemsArray[i2] as? Item
    
                                        //record 1
                                        consumptionItem.consumptionId = self.consumptionID
                                        consumptionItem.itemId = aConsumption?.itemId
                                        consumptionItem.lotNo = aConsumption?.lotNumber
                                        consumptionItem.dateCode = aConsumption?.dateCode
                                        consumptionItem.chargeNo = aConsumption?.itemNo
                                        consumptionItem.consumedQty = aConsumption?.used
                                        consumptionItem.requiredQty = aConsumption?.wasted
    
                                        }
                                        _ = utility.addOrUpdateCoreData(self.appDelegate.managedObjectContext)
                                        let (resultsCoreData,_) = utility.fetchFromCoreData(predicate, entityName2: "ConsumptionItem", moc: self.appDelegate.managedObjectContext)
                                        self.result = resultsCoreData as! [ConsumptionItem]

                                        
                                        self.listTableView.reloadData()
                                        self.updateButtonStatuses()
                                    }
                                    else
                                    {
                                        let  error = parseJSON["error"]
                                        let alert = UIAlertView(title:"Error", message:error as? String, delegate:self, cancelButtonTitle:"OK")
                                        alert.show()
                                    }
                                    
                                    
                                }
                                catch{
                                    let jsonStr = NSString(data: data, encoding: NSUTF8StringEncoding)
                                    let alert = UIAlertView(title:"Error", message:jsonStr as? String, delegate:self, cancelButtonTitle:"OK")
                                    alert.show()

                                }
                                
                            })
                        })
                    
                        
                    }
                        
                    else{
                        
                        let json = try NSJSONSerialization.JSONObjectWithData(dataDetail, options:[])
                        let parseJSON = json

                        
                        _ = parseJSON["error"]
                        
                        
                        self.createConsumptionReport()
                    }
                    
                    
                }
                catch{
                    _ = NSString(data: dataDetail, encoding: NSUTF8StringEncoding)
                    
                    self.createConsumptionReport()
                }
                
            })
        })

    }
}
