//
//  ScheduleTableViewCell.swift
//  Simplify OR swift
//
//  Created by Nayana Chikkanayakan Hally Sudarshan on 8/10/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import UIKit

class ScheduleTableViewCell: UITableViewCell {

    @IBOutlet weak var statusImage: UIImageView!
    @IBOutlet weak var alertImage: UIImageView!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var doctorName: UILabel!
    @IBOutlet weak var surgeryName: UILabel!
    @IBOutlet weak var patientID: UILabel!
    @IBOutlet weak var time: UILabel!
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
