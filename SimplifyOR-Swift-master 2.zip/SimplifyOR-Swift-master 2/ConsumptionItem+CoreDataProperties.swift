//
//  ConsumptionItem+CoreDataProperties.swift
//  Simplify OR swift
//
//  Created by Arunava Sanyal on 17/08/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension ConsumptionItem {

    @NSManaged var chargeNo: String?
    @NSManaged var consumedQty: NSNumber?
    @NSManaged var consumptionId: String?
    @NSManaged var createdTime: NSDate?
    @NSManaged var dateCode: String?
    @NSManaged var itemId: String?
    @NSManaged var lotNo: String?
    @NSManaged var modifiedTime: NSDate?
    @NSManaged var requiredQty: NSNumber?
    @NSManaged var consumptionItems: Consumption?

}
