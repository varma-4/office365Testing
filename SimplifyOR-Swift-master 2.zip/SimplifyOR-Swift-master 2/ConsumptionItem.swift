//
//  ConsumptionItem.swift
//  Simplify OR swift
//
//  Created by Arunava Sanyal on 17/08/16.
//  Copyright © 2016 Nayana Sudarshan. All rights reserved.
//

import Foundation
import CoreData


class ConsumptionItem: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
